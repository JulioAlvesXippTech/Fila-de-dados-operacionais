"""
Upload e download no SharePoint (site Dados / Dados Operacionais).

Autenticação por certificado lido do Azure Key Vault, sem rpa_commons.
A chave privada fica só em memória.

.env em %APPDATA%\\.env:
    RPA_AZURE_TENANT_ID=...
    RPA_AZURE_CLIENT_ID=...
    RPA_AZURE_CLIENT_SECRET=...
    RPA_KEY_VAULT_URL=https://<vault>.vault.azure.net/
    SHAREPOINT_SITE_URL=https://xippseguros.sharepoint.com/sites/Dados
    # opcional, se precisar do outro site também:
    # SHAREPOINT_SITE_URL_INTERNO=https://xippseguros.sharepoint.com/sites/xipp

pip install Office365-REST-Python-Client azure-identity azure-keyvault-secrets cryptography
"""

import base64
import io
import os
from pathlib import Path

from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    pkcs12,
)
from office365.sharepoint.client_context import ClientContext

TENANT_SHAREPOINT = "xippseguros.onmicrosoft.com"

# Raiz da pasta Dados Operacionais (caminho relativo ao servidor)
PASTA_DADOS_OPERACIONAIS = "/sites/Dados/Documentos Compartilhados/Dados Operacionais"


# ---------------------------------------------------------------- .env

def carregar_env(env_path: str | None = None) -> dict:
    env_path = env_path or os.path.expandvars(r"%APPDATA%/.env")
    env_vars = {}
    with open(env_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            env_vars[key.strip()] = value
    return env_vars


# ---------------------------------------------------------------- conexão

def _segredos_certificado(env_vars: dict) -> tuple[str, str, str]:
    """Retorna (client_id, thumbprint, chave privada PEM) do Key Vault."""
    kv = SecretClient(
        vault_url=env_vars["RPA_KEY_VAULT_URL"],
        credential=ClientSecretCredential(
            env_vars["RPA_AZURE_TENANT_ID"],
            env_vars["RPA_AZURE_CLIENT_ID"],
            env_vars["RPA_AZURE_CLIENT_SECRET"],
        ),
    )
    pfx = base64.b64decode(kv.get_secret("rpa-app-private-key").value)
    chave, _, _ = pkcs12.load_key_and_certificates(pfx, None)
    pem = chave.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()).decode()
    client_id = kv.get_secret("rpa-app-client-id").value
    thumbprint = kv.get_secret("rpa-app-thumbprint").value
    return client_id, thumbprint, pem


def conectar_sharepoint(env_vars: dict, site_url: str | None = None) -> ClientContext:
    """Conecta em um site. Sem site_url, usa SHAREPOINT_SITE_URL do .env."""
    site_url = site_url or env_vars["SHAREPOINT_SITE_URL"]
    client_id, thumbprint, pem = _segredos_certificado(env_vars)
    return ClientContext(site_url).with_client_certificate(
        TENANT_SHAREPOINT, client_id=client_id, thumbprint=thumbprint, private_key=pem
    )


# ---------------------------------------------------------------- operações

def listar(ctx: ClientContext, pasta: str) -> tuple[list[str], list[str]]:
    """Retorna (subpastas, arquivos) de uma pasta."""
    alvo = (
        ctx.web.get_folder_by_server_relative_path(pasta)
        .expand(["Folders", "Files"])
        .get()
        .execute_query()
    )
    return [f.name for f in alvo.folders], [f.name for f in alvo.files]


def baixar(ctx: ClientContext, caminho_arquivo: str, destino_local: str | None = None) -> bytes:
    """
    Baixa um arquivo. Retorna os bytes e, se destino_local for informado,
    grava também em disco.
    Ex.: baixar(ctx, f"{PASTA_DADOS_OPERACIONAIS}/relatorio.xlsx", "relatorio.xlsx")
    """
    buffer = io.BytesIO()
    ctx.web.get_file_by_server_relative_path(caminho_arquivo).download(buffer).execute_query()
    conteudo = buffer.getvalue()
    if destino_local:
        Path(destino_local).write_bytes(conteudo)
    return conteudo


def enviar(ctx: ClientContext, pasta: str, nome_arquivo: str, conteudo: bytes | str | Path) -> str:
    """
    Envia um arquivo para uma pasta existente (sobrescreve se já existir).
    `conteudo` pode ser bytes ou o caminho de um arquivo local.
    Retorna o caminho do arquivo no SharePoint.
    """
    if isinstance(conteudo, (str, Path)):
        conteudo = Path(conteudo).read_bytes()
    arquivo = (
        ctx.web.get_folder_by_server_relative_path(pasta)
        .files.upload(io.BytesIO(conteudo), nome_arquivo)
        .execute_query()
    )
    return arquivo.server_relative_url


def criar_pasta(ctx: ClientContext, pasta_pai: str, nome: str) -> str:
    """Cria uma subpasta dentro de pasta_pai. Retorna o caminho criado."""
    nova = (
        ctx.web.get_folder_by_server_relative_path(pasta_pai)
        .folders.add(nome)
        .execute_query()
    )
    return nova.server_relative_url


# ---------------------------------------------------------------- teste

if __name__ == "__main__":
    env = carregar_env()
    print("Site:", env["SHAREPOINT_SITE_URL"])
    ctx = conectar_sharepoint(env)

    # 1) Leitura
    subpastas, arquivos = listar(ctx, PASTA_DADOS_OPERACIONAIS)
    print(f"Leitura OK: {len(subpastas)} subpastas, {len(arquivos)} arquivos")
    print("  subpastas:", subpastas[:10])

    # 2) Escrita (ainda não testada neste site): envia e baixa de volta um arquivo pequeno
    nome_teste = "_teste_conexao.txt"
    dados = b"teste de escrita via sharepoint_client.py"
    try:
        caminho = enviar(ctx, PASTA_DADOS_OPERACIONAIS, nome_teste, dados)
        assert baixar(ctx, caminho) == dados
        print("Escrita OK:", caminho)
        ctx.web.get_file_by_server_relative_path(caminho).delete_object().execute_query()
        print("Arquivo de teste removido.")
    except Exception as e:
        print("Escrita FALHOU (provável falta de permissão de escrita no site):", e)
