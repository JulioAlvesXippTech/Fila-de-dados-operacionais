# Setup: Upload e Download no SharePoint (Dados Operacionais)

Guia para configurar e rodar o `sharepoint_client.py`, que faz upload e download de arquivos no site **Dados** do SharePoint da Xipp, na pasta **Dados Operacionais**. Não usa a biblioteca `rpa_commons`.

## Como a autenticação funciona

1. O `.env` tem as credenciais de um service principal que só serve para ler o **Azure Key Vault**.
2. Do Key Vault saem 3 segredos do App Registration que tem permissão no SharePoint:
   - `rpa-app-private-key`: certificado PFX em base64, sem senha
   - `rpa-app-client-id`: Client ID do App Registration
   - `rpa-app-thumbprint`: thumbprint do certificado
3. O `Office365-REST-Python-Client` se autentica por certificado no tenant `xippseguros.onmicrosoft.com`. A chave privada fica **só em memória**: nada é gravado em disco.

Não existe login com usuário e senha.

## Passo 1: instalar os pacotes

```
pip install Office365-REST-Python-Client azure-identity azure-keyvault-secrets cryptography
```

## Passo 2: configurar o `.env`

O `.env` fica em **`%APPDATA%\.env`** (`C:\Users\<usuario>\AppData\Roaming\.env`), fora da pasta do projeto. Assim ele nunca vai parar no Git.

```
RPA_AZURE_TENANT_ID=...
RPA_AZURE_CLIENT_ID=...
RPA_AZURE_CLIENT_SECRET=...
RPA_KEY_VAULT_URL=https://<nome-do-vault>.vault.azure.net/
SHAREPOINT_SITE_URL=https://xippseguros.sharepoint.com/sites/Dados

# Opcional, se precisar acessar também o site "interno":
# SHAREPOINT_SITE_URL_INTERNO=https://xippseguros.sharepoint.com/sites/xipp
```

- Os valores `RPA_*` ficam com quem administra o Azure/Key Vault e não estão em nenhum repositório.
- `SHAREPOINT_SITE_URL` é a URL do **site**, não a de uma pasta.
- Cada conexão vale para **um site só**. Para usar dois sites, passe a URL na conexão: `conectar_sharepoint(env, env["SHAREPOINT_SITE_URL_INTERNO"])`.

## Passo 3: testar a conexão

Na pasta onde está o `sharepoint_client.py`:

```
python sharepoint_client.py
```

Saída esperada:

```
Site: https://xippseguros.sharepoint.com/sites/Dados
Leitura OK: N subpastas, M arquivos
  subpastas: [...]
Escrita OK: /sites/Dados/Documentos Compartilhados/Dados Operacionais/_teste_conexao.txt
Arquivo de teste removido.
```

O teste lista a pasta Dados Operacionais, envia um arquivo `_teste_conexao.txt`, baixa de volta para conferir e apaga em seguida. A saída não mostra nenhum segredo.

## Passo 4: usar no seu código

```python
from sharepoint_client import (
    carregar_env, conectar_sharepoint,
    listar, baixar, enviar, criar_pasta,
    PASTA_DADOS_OPERACIONAIS,
)

ctx = conectar_sharepoint(carregar_env())

# Listar
subpastas, arquivos = listar(ctx, PASTA_DADOS_OPERACIONAIS)

# Baixar (retorna bytes; com destino_local também grava em disco)
baixar(ctx, f"{PASTA_DADOS_OPERACIONAIS}/arquivo.xlsx", "arquivo.xlsx")

# Enviar (bytes ou caminho de arquivo local; sobrescreve se já existir)
enviar(ctx, f"{PASTA_DADOS_OPERACIONAIS}/Subpasta", "resultado.xlsx", "resultado.xlsx")

# Criar pasta (enviar não cria pastas sozinho)
criar_pasta(ctx, PASTA_DADOS_OPERACIONAIS, "Nova Pasta")
```

Os caminhos são **relativos ao servidor** e começam em `/sites/<site>/Documentos Compartilhados/...`.

## Funções do `sharepoint_client.py`

| Função | O que faz | Retorno |
|---|---|---|
| `carregar_env(env_path=None)` | Lê `%APPDATA%\.env` | `dict` |
| `conectar_sharepoint(env, site_url=None)` | Conecta no site (padrão: `SHAREPOINT_SITE_URL`) | `ClientContext` |
| `listar(ctx, pasta)` | Subpastas e arquivos de uma pasta | `(subpastas, arquivos)` |
| `baixar(ctx, caminho, destino_local=None)` | Baixa um arquivo | `bytes` |
| `enviar(ctx, pasta, nome, conteudo)` | Envia bytes ou arquivo local para pasta existente | caminho no SharePoint |
| `criar_pasta(ctx, pasta_pai, nome)` | Cria subpasta | caminho criado |

Erros **lançam exceção** (diferente da `rpa_commons`, que retornava `None`/`False`).

## Sites conhecidos

| Pasta no OneDrive | `SHAREPOINT_SITE_URL` | Raiz dos arquivos | Acesso do app |
|---|---|---|---|
| `Xipp Seguros - interno` | `https://xippseguros.sharepoint.com/sites/xipp` | `/sites/xipp/Documentos Compartilhados/interno` | Só leitura |
| `DadosOperacionais - Documentos` | `https://xippseguros.sharepoint.com/sites/Dados` | `/sites/Dados/Documentos Compartilhados` (Automacao, Dados Operacionais) | Leitura e escrita OK (2026-10-29) |

## Erros comuns

| Erro | Causa provável | O que fazer |
|---|---|---|
| `404` em `/_api/contextInfo` | URL do site errada | Conferir `SHAREPOINT_SITE_URL` (ex.: "DadosOperacionais" fica em `/sites/Dados`) |
| `403 Forbidden` | App Registration sem permissão no site (ou só leitura) | Pedir ao admin do Azure permissão no site (Write, se for gravar) |
| `KeyError: 'SHAREPOINT_SITE_URL'` | Variável faltando no `.env` | Adicionar a linha no `%APPDATA%\.env` |
| `FileNotFoundError` no `.env` | `.env` fora de `%APPDATA%` | Mover para `C:\Users\<usuario>\AppData\Roaming\.env` |
| Erro com acentos, `%` ou `#` no caminho | Uso das funções `..._url` | Usar `get_..._by_server_relative_path` (o módulo já usa) |

## Pontos de atenção

- **Ler não garante gravar**: teste a escrita antes de depender dela.
- **Arquivos grandes** (centenas de MB) precisam de upload em partes; o `enviar` atual faz upload simples.
- **Tenant fixo**: `xippseguros.onmicrosoft.com`.
- **Segredo pendente**: o `RPA_AZURE_CLIENT_SECRET` ainda precisa ser trocado (pendência do `controle-cargas`).
