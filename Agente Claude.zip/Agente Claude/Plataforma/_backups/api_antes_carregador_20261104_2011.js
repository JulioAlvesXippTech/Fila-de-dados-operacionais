async function req(url, opts) {
  const r = await fetch(url, opts)
  const j = await r.json().catch(() => ({}))
  if (!r.ok || j.erro) throw new Error(j.erro || `Erro ${r.status}`)
  return j
}

export const api = {
  casos: (sync = false) => req('/api/casos' + (sync ? '?sync=1' : '')),
  pastas: () => req('/api/pastas'),
  estrutura: () => req('/api/estrutura'),
  preanalise: () => req('/api/preanalise'),
  aprovar: (id, aprovar = true) =>
    req('/api/aprovar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, aprovar }),
    }),
  respostas: (id, pasta, respostas) =>
    req('/api/respostas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, pasta, respostas }),
    }),
  concluir: (id, nota = '') =>
    req('/api/concluir', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, nota }),
    }),
  direcionar: (id, texto, acao) =>
    req('/api/direcionar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, texto, acao }),
    }),
  responder: (id, resposta) =>
    req('/api/responder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, resposta }),
    }),
}

export const TIPOS = {
  carga: { rotulo: 'Carga de arquivo', curto: 'Carga' },
  layout: { rotulo: 'Validação de layout', curto: 'Layout' },
  outros: { rotulo: 'Outros', curto: 'Outros' },
}

export const OPCOES = {
  '1': 'Maninha',
  '2': 'Carregador do Futuro',
  '3': 'Sem ação',
}

export function diasDesde(iso) {
  if (!iso) return null
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000)
}
