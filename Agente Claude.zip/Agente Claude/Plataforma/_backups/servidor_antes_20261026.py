#!/usr/bin/env python3
"""Plataforma do Agente de Atendimentos (Xipp) - servidor local.

Serve a interface Vue 3 (pasta frontend/dist) e uma API local que lê, ao vivo:
  - os TXT Atendimentos_*.txt da pasta "Agente Claude" (casos e respostas "R:")
  - _sistema/_controle_atendimentos.json (encaminhamentos já feitos pelo agente)
  - as pastas Layouts (Maninha) e Carga SDI (Carregador do Futuro)
  - opcionalmente a plataforma Odoo (SOMENTE LEITURA, via _sistema/agente_atendimentos.py)
    para saber quais casos ainda estão abertos no filtro.

A única escrita feita é a linha "R:" no TXT, quando você responde pela tela
(com cópia de segurança do TXT antes, em Plataforma/_backups).

Uso:  python servidor.py            (abre http://localhost:8765 no navegador)
      python servidor.py --porta 9000 --sem-navegador
Só usa a biblioteca padrão do Python 3.8+.
"""
import argparse, json, os, re, shutil, sys, threading, time, unicodedata, webbrowser
from datetime import datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

AQUI = os.path.dirname(os.path.abspath(__file__))
AGENTE = os.path.dirname(AQUI)                      # ...\Claude\Agente Claude
RAIZ = os.path.dirname(AGENTE)                       # ...\Claude
SISTEMA = os.path.join(AGENTE, "_sistema")
PASTAS = {"Layouts": os.path.join(RAIZ, "Layouts"), "Carga SDI": os.path.join(RAIZ, "Carga SDI")}
DIST = os.path.join(AQUI, "frontend", "dist")
BACKUPS = os.path.join(AQUI, "_backups")
TRAVA = threading.Lock()
CACHE_ODOO = {"quando": None, "abertos": None, "erro": None}

IGNORAR = re.compile(r"^(~\$|thumbs\.db$|\.ds_store$|desktop\.ini$)", re.I)


def norm(s):
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower().strip()


def data_br(s):
    try:
        return datetime.strptime(s.strip(), "%d/%m/%Y %H:%M")
    except Exception:
        return None


# ---------------------------------------------------------------- TXT
BLOCO_RE = re.compile(r"\n(?=\[[^\]\n]+\] Protocolo)")


def ler_texto(path):
    raw = open(path, "rb").read()
    bom = raw.startswith(b"\xef\xbb\xbf")
    t = raw.decode("utf-8-sig", errors="replace")
    crlf = "\r\n" in t
    return t.replace("\r\n", "\n"), bom, crlf


def campo(bloco, rotulo):
    m = re.search(r"^\s*" + re.escape(rotulo) + r":\s*(.*)$", bloco, re.M)
    return m.group(1).strip() if m else ""


def parse_bloco(bloco, txt_nome):
    bloco = bloco.strip("\n")
    m = re.match(r"\[([^\]]+)\] Protocolo\s+(\S+)\s+-\s+(.*?)(?:\s{2,}\((NOVO|ATUALIZADO|ATUALIZAÇÃO)\))?\s*$",
                 bloco.split("\n", 1)[0].strip())
    if not m:
        return None
    mid = re.search(r"[#?&]id=(\d+)", bloco)
    if not mid:
        return None
    l2 = re.search(r"^\s*Responsável:(.*)$", bloco, re.M)
    meta = {}
    if l2:
        for parte in ("Responsável:" + l2.group(1)).split("|"):
            if ":" in parte:
                k, v = parte.split(":", 1)
                meta[k.strip()] = v.strip()
    sug = re.search(r"Sugestão do Claude:\s*([123])\s*-?\s*(.*)$", bloco, re.M)
    resp = re.search(r"^\s*R:[ \t]*(.*)$", bloco, re.M)
    contrato = re.search(r"^\s*Contrato:\s*(.*)$", bloco, re.M)
    cinfo = {}
    if contrato:
        for parte in contrato.group(1).split("|"):
            if ":" in parte:
                k, v = parte.split(":", 1)
                cinfo[k.strip()] = v.strip()
            elif "contrato" not in cinfo:
                cinfo["Contrato"] = parte.strip()
        if "Contrato" not in cinfo:
            cinfo["Contrato"] = contrato.group(1).split("|")[0].strip()
    linha_cnpj = re.search(r"^\s*CNPJ:\s*(.*)$", bloco, re.M)
    if linha_cnpj:
        for parte in ("CNPJ:" + linha_cnpj.group(1)).split("|"):
            if ":" in parte:
                k, v = parte.split(":", 1)
                cinfo[k.strip()] = v.strip()
    arquivos = []
    ma = re.search(r"Arquivos mais recentes:\n((?:\s{4}- .*\n?)+)", bloco)
    if ma:
        for l in ma.group(1).splitlines():
            l = l.strip()[2:].strip()
            if l:
                arquivos.append(l)
    planos = [l.strip()[len("Plano:"):].strip() for l in bloco.splitlines() if l.strip().startswith("Plano:")]
    portais = [l.strip()[len("Portal operadora:"):].strip() for l in bloco.splitlines()
               if l.strip().startswith("Portal operadora:")]
    portais = [re.sub(r"\(login [^)]*\)", "", p).strip() for p in portais]  # não exibe logins
    return {
        "chave": m.group(1), "protocolo": m.group(2), "titulo": m.group(3).strip(),
        "marca": (m.group(4) or "").replace("ATUALIZAÇÃO", "ATUALIZADO"),
        "id": int(mid.group(1)),
        "responsavel": meta.get("Responsável", ""), "status": meta.get("Status", ""),
        "solicitante": meta.get("Solicitante", ""), "aberto_em": meta.get("Aberto em", ""),
        "assunto": campo(bloco, "Assunto/Contrato"),
        "link": campo(bloco, "Link"),
        "resumo": campo(bloco, "O que foi solicitado"),
        "contrato": cinfo, "planos": planos, "portais": portais,
        "contrato_pelo_texto": "identificado pelo número citado no texto" in bloco,
        "arquivos": arquivos,
        "sem_arquivo": "nenhum arquivo anexado" in bloco,
        "sugestao": sug.group(1) if sug else "", "sugestao_txt": (sug.group(2).strip() if sug else ""),
        "resposta": resp.group(1).strip() if resp else "",
        "tem_linha_r": bool(resp),
        "txt": txt_nome,
    }


def listar_txts():
    return sorted(f for f in os.listdir(AGENTE) if re.match(r"^Atendimentos_\d{8}_\d{4}\.txt$", f))


LAYOUT_RE = re.compile(r"(criac\w*|cria|criar)\s+(do|de|o|um)?\s*layout|valid\w*\s+(o|do|de)?\s*layout|"
                       r"layout\s+(validador|operadora|implantacao)|validacao\s+(de\s+)?layout|"
                       r"preenchimento\s+de\s+layout|\blayout\b|criticador|bate cadastral")
CARGA_RE = re.compile(r"\bcarga\b|carregar|atualiza\w*\s+(de\s+|da\s+)?base|posicao cadastral|"
                      r"\bmovimenta\w*\s+cadastra|carga sdi")


def classificar(c):
    """carga | layout | outros  (título/assunto pesam mais que o resumo; depois a sugestão)."""
    titulo = norm(c["titulo"] + " " + c["assunto"])
    resumo = norm(c["resumo"])
    if "telemedicina" in titulo or "eu protegido" in titulo:
        return "outros"
    if LAYOUT_RE.search(titulo):
        return "layout"
    if CARGA_RE.search(titulo):
        return "carga"
    if c["sugestao"] == "1":
        return "layout"
    if c["sugestao"] == "2":
        return "carga"
    if LAYOUT_RE.search(resumo):
        return "layout"
    if CARGA_RE.search(resumo):
        return "carga"
    return "outros"


def interpretar(resp, sug):
    r = norm(resp)
    if not r:
        return ""
    if re.match(r"^(ok|sim|de acordo|aceito|concordo|pode)\b", r):
        return {"1": "Maninha", "2": "Carregador do Futuro", "3": "Sem ação"}.get(sug, "ok")
    if re.match(r"^1\b|^maninha", r):
        return "Maninha"
    if re.match(r"^2\b|^carregador", r):
        return "Carregador do Futuro"
    if re.match(r"^3\b|^sem acao", r):
        return "Sem ação"
    return "Outro"


def carregar_controle():
    p = os.path.join(SISTEMA, "_controle_atendimentos.json")
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {}


def montar_casos():
    casos, vistos_em = {}, {}
    for nome in listar_txts():
        t, _, _ = ler_texto(os.path.join(AGENTE, nome))
        for bloco in BLOCO_RE.split(t):
            c = parse_bloco(bloco.strip(), nome)
            if not c:
                continue
            vistos_em.setdefault(c["id"], []).append(nome)
            ant = casos.get(c["id"])
            if ant and ant["resposta"] and not c["resposta"]:
                # TXT mais novo sem resposta: mantém dados novos, mas a resposta anterior continua valendo
                c["resposta"], c["txt_resposta"] = ant["resposta"], ant.get("txt_resposta", ant["txt"])
            elif c["resposta"]:
                c["txt_resposta"] = nome
            if ant and not c["sem_arquivo"] and not c["arquivos"]:
                c["arquivos"] = ant["arquivos"]
            c["primeiro_txt"] = ant["primeiro_txt"] if ant else nome
            casos[c["id"]] = c
    ctl = carregar_controle()
    enc = ctl.get("encaminhados", {})
    abertos = CACHE_ODOO["abertos"]
    saida = []
    for cid, c in casos.items():
        c["txts"] = vistos_em[cid]
        c["tipo"] = classificar(c)
        c["decisao"] = interpretar(c["resposta"], c["sugestao"])
        e = enc.get(str(cid))
        c["encaminhado"] = e or None
        if abertos is not None:
            o = abertos.get(cid)
            c["aberto_na_plataforma"] = bool(o)
            if o:
                c["status"] = o.get("status") or c["status"]
                c["responsavel"] = o.get("responsavel") or c["responsavel"]
        else:
            c["aberto_na_plataforma"] = None
        dt = data_br(c["aberto_em"])
        c["aberto_iso"] = dt.isoformat() if dt else ""
        c["precisa_responder"] = (not c["resposta"]) and not e and c["aberto_na_plataforma"] is not False
        saida.append(c)
    saida.sort(key=lambda c: (c["aberto_iso"] or "9999", c["id"]))
    return saida, ctl


def gravar_resposta(cid, texto):
    texto = re.sub(r"[\r\n]+", " ", texto or "").strip()
    with TRAVA:
        casos, _ = montar_casos()
        c = next((x for x in casos if x["id"] == cid), None)
        if not c:
            raise ValueError("Atendimento não encontrado nos TXT.")
        alvo = c.get("txt_resposta") or c["txt"]  # onde já existe resposta, ou o TXT mais recente
        path = os.path.join(AGENTE, alvo)
        t, bom, crlf = ler_texto(path)
        partes = BLOCO_RE.split(t)
        achou = False
        for i, bloco in enumerate(partes):
            mid = re.search(r"[#?&]id=(\d+)", bloco)
            if not (re.match(r"\s*\[[^\]\n]+\] Protocolo", bloco) and mid and int(mid.group(1)) == cid):
                continue
            if re.search(r"^\s*R:.*$", bloco, re.M):
                partes[i] = re.sub(r"^(\s*)R:.*$", lambda m: m.group(1) + "R: " + texto if texto else m.group(1) + "R:",
                                   bloco, count=1, flags=re.M)
            else:
                partes[i] = bloco.rstrip("\n") + "\n  R: " + texto + "\n"
            achou = True
            break
        if not achou:
            raise ValueError(f"Bloco do atendimento não encontrado em {alvo}.")
        os.makedirs(BACKUPS, exist_ok=True)
        shutil.copy2(path, os.path.join(BACKUPS, f"{alvo[:-4]}_antes_{datetime.now():%Y%m%d_%H%M%S}.txt"))
        novo = "\n".join(partes)
        if crlf:
            novo = novo.replace("\n", "\r\n")
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            f.write((b"\xef\xbb\xbf" if bom else b"") + novo.encode("utf-8"))
        os.replace(tmp, path)
        return {"ok": True, "txt": alvo, "resposta": texto}


# ---------------------------------------------------------------- Odoo (somente leitura)
def sincronizar_odoo():
    cred = os.path.join(SISTEMA, "credenciais.env")
    if not os.path.exists(cred):
        CACHE_ODOO.update(erro="credenciais.env não encontrado em _sistema", quando=datetime.now().isoformat())
        return
    sys.path.insert(0, SISTEMA)
    try:
        import agente_atendimentos as ag  # usa a classe Odoo do agente (bloqueia métodos de escrita)
        o = ag.Odoo(ag.load_env(cred))
        ts = o.call("helpdesk.ticket", "search_read", [ag.dominio_filtro()],
                    {"fields": ["id", "number", "user_id", "stage_id"], "limit": 2000})
        CACHE_ODOO.update(
            abertos={t["id"]: {"status": (t.get("stage_id") or [0, ""])[1],
                               "responsavel": (t.get("user_id") or [0, "Sem responsável"])[1] if t.get("user_id") else "Sem responsável"}
                     for t in ts},
            erro=None, quando=datetime.now().isoformat())
    except SystemExit as e:
        CACHE_ODOO.update(erro=str(e), quando=datetime.now().isoformat())
    except Exception as e:
        CACHE_ODOO.update(erro=f"{type(e).__name__}: {e}", quando=datetime.now().isoformat())


# ---------------------------------------------------------------- Pastas
def arquivos_em(p):
    try:
        return sorted(f for f in os.listdir(p) if os.path.isfile(os.path.join(p, f)) and not IGNORAR.match(f))
    except Exception:
        return []


def perguntas_abertas(path):
    try:
        t, _, _ = ler_texto(path)
    except Exception:
        return None
    rs = re.findall(r"^\s*R:[ \t]*(.*)$", t, re.M)
    return {"total": len(rs), "sem_resposta": sum(1 for r in rs if not r.strip())}


def montar_pastas():
    out = []
    for raiz, base in PASTAS.items():
        if not os.path.isdir(base):
            continue
        for nome in sorted(os.listdir(base)):
            p = os.path.join(base, nome)
            if not os.path.isdir(p) or norm(nome).startswith("-"):
                continue
            m = re.match(r"\(#([^)]+)\)", nome)
            subs = {}
            for s in sorted(os.listdir(p)):
                sp = os.path.join(p, s)
                if os.path.isdir(sp):
                    subs[s] = arquivos_em(sp)
            item = {"raiz": raiz, "nome": nome, "protocolo": m.group(1) if m else "",
                    "subpastas": subs, "na_raiz": arquivos_em(p),
                    "mtime": datetime.fromtimestamp(os.path.getmtime(p)).isoformat(timespec="minutes")}
            origem = subs.get("Arquivo Origem", [])
            if raiz == "Layouts":
                val = subs.get("Arquivo Validado", [])
                crit = [f for f in val if "criticador de layout" in f.lower()]
                lay = [f for f in val if "layout operadora" in f.lower()]
                perg = perguntas_abertas(os.path.join(p, "Arquivo Validado", "Perguntas Pendentes - Layout Operadora.txt"))
                item["situacao"] = ("aguardando base" if not origem else
                                    "perguntas pendentes" if perg and perg["sem_resposta"] else
                                    "layout operadora gerado" if lay else
                                    "criticador gerado" if crit else "a processar")
                item["perguntas"] = perg
            else:
                fin = os.path.join(p, "Arquivo Final")
                duv = perguntas_abertas(os.path.join(fin, "Duvidas.txt"))
                ctl = {}
                try:
                    ctl = json.load(open(os.path.join(fin, "_controle_processamento.json"), encoding="utf-8"))
                except Exception:
                    pass
                st = norm(str(ctl.get("status", "")))
                item["situacao"] = ("aguardando base" if not origem else
                                    "dúvidas pendentes" if duv and duv["sem_resposta"] else
                                    "concluído" if "conclu" in st else
                                    "aguardando respostas" if "aguardando" in st else "a processar")
                item["perguntas"] = duv
                item["status_controle"] = ctl.get("status", "")
            out.append(item)
    return out


def montar_estrutura():
    ctl = carregar_controle()
    scripts = []
    for f in sorted(os.listdir(SISTEMA)) if os.path.isdir(SISTEMA) else []:
        p = os.path.join(SISTEMA, f)
        if os.path.isfile(p) and f != "credenciais.env":
            scripts.append({"nome": f, "kb": round(os.path.getsize(p) / 1024, 1),
                            "mtime": datetime.fromtimestamp(os.path.getmtime(p)).isoformat(timespec="minutes")})
    bk = os.path.join(SISTEMA, "backups")
    backups = sorted(os.listdir(bk)) if os.path.isdir(bk) else []
    return {"agente": AGENTE, "pastas": PASTAS, "ultima_execucao": ctl.get("ultima_execucao", ""),
            "txts": listar_txts(), "scripts": scripts, "backups": backups[-15:], "total_backups": len(backups),
            "credenciais": os.path.exists(os.path.join(SISTEMA, "credenciais.env")),
            "total_controle": len(ctl.get("atendimentos", {})), "total_encaminhados": len(ctl.get("encaminhados", {}))}


# ---------------------------------------------------------------- HTTP
class H(SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=DIST, **k)

    def log_message(self, fmt, *args):
        pass

    def _json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        u = urlparse(self.path)
        try:
            if u.path == "/api/casos":
                if "sync" in parse_qs(u.query) or CACHE_ODOO["quando"] is None:
                    sincronizar_odoo()
                casos, ctl = montar_casos()
                return self._json({"casos": casos, "ultima_execucao": ctl.get("ultima_execucao", ""),
                                   "odoo": {"quando": CACHE_ODOO["quando"], "erro": CACHE_ODOO["erro"],
                                            "abertos": len(CACHE_ODOO["abertos"] or {}) if CACHE_ODOO["abertos"] is not None else None}})
            if u.path == "/api/pastas":
                return self._json({"pastas": montar_pastas()})
            if u.path == "/api/estrutura":
                return self._json(montar_estrutura())
        except Exception as e:
            return self._json({"erro": f"{type(e).__name__}: {e}"}, 500)
        if u.path.startswith("/api/"):
            return self._json({"erro": "rota inexistente"}, 404)
        if not os.path.exists(os.path.join(DIST, u.path.lstrip("/"))) or u.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        u = urlparse(self.path)
        if self.client_address[0] not in ("127.0.0.1", "::1"):
            return self._json({"erro": "somente acesso local"}, 403)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
            if u.path == "/api/responder":
                return self._json(gravar_resposta(int(body["id"]), str(body.get("resposta", ""))))
        except Exception as e:
            return self._json({"erro": str(e)}, 400)
        return self._json({"erro": "rota inexistente"}, 404)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--porta", type=int, default=8765)
    ap.add_argument("--sem-navegador", action="store_true")
    a = ap.parse_args()
    if not os.path.exists(os.path.join(DIST, "index.html")):
        sys.exit("Interface não encontrada em frontend/dist. Rode 'npm install && npm run build' em frontend.")
    srv = ThreadingHTTPServer(("127.0.0.1", a.porta), H)
    url = f"http://localhost:{a.porta}"
    print(f"Plataforma do Agente de Atendimentos em {url}  (Ctrl+C para encerrar)")
    print(f"Pasta do agente: {AGENTE}")
    if not a.sem_navegador:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
