<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { api } from '../api.js'
import MultiFiltro from './MultiFiltro.vue'

const emit = defineEmits(['avisar', 'contagem'])
const dados = ref({ itens: [], gerado_em: '', coletado_em: '', total_aprendizado: 0 })
const carregando = ref(false)
const erro = ref('')

const LS = 'agente-filtros-preanalise'
const salvo = (() => { try { return JSON.parse(localStorage.getItem(LS) || '{}') } catch { return {} } })()
const busca = ref('')
const numero = ref('')
// Filtros de múltipla escolha (array vazio = todos). Aceita o formato antigo salvo (texto único).
const lista0 = (v) => (Array.isArray(v) ? v : v ? [v] : [])
const responsavel = ref(lista0(salvo.responsavel))
const solicitante = ref(lista0(salvo.solicitante))
const tipo = ref(lista0(salvo.tipo))
const acao = ref(lista0(salvo.acao))
const prioridade = ref(lista0(salvo.prioridade))
const etapa = ref(lista0(salvo.etapa))
const filaSol = ref(lista0(salvo.filaSol))
const situacao = ref(salvo.situacao ?? 'pendentes')
const modo = ref(salvo.modo || 'tabela')          // 'tabela' (compacta, como o relatório) ou 'cartoes'
const selecionado = ref(null)                     // id aberto no painel lateral (modo tabela)
const ordenar = ref({ col: '', asc: true })
watch([responsavel, solicitante, filaSol, tipo, acao, prioridade, etapa, situacao, modo], () => {
  try {
    localStorage.setItem(LS, JSON.stringify({ responsavel: responsavel.value, solicitante: solicitante.value, tipo: tipo.value, acao: acao.value,
      prioridade: prioridade.value, etapa: etapa.value, filaSol: filaSol.value, situacao: situacao.value, modo: modo.value }))
  } catch {}
}, { deep: true })

const ACOES = ['Maninha', 'Carregador', 'Baixar/enviar PC', 'Cobrar operadora', 'Cobrar solicitante',
  'Responder solicitante', 'Devolver ao solicitante', 'Repassar responsável', 'Aguardar terceiro', 'Tech/sistema', 'Carga sem arquivo – dados do contrato', 'Avançar para Em andamento', 'Encerrar (Fechado)', 'Outro']

const rascunho = ref({})   // id -> { texto, acao }
const aberto = ref({})     // id -> mostra histórico
const gravando = ref({})

async function carregar() {
  carregando.value = true
  erro.value = ''
  try {
    dados.value = await api.preanalise()
    emit('contagem', pendentes.value)
  } catch (e) {
    erro.value = e.message
  } finally {
    carregando.value = false
  }
}

const itens = computed(() => dados.value.itens || [])
const pendentes = computed(() => itens.value.filter((i) => !i.direcionamento).length)
const opcoes = (campo) => [...new Set(itens.value.map(campo).filter(Boolean))].sort()
// opções com contagem, para os filtros de múltipla escolha
const opcoesN = (campo, ordem) => {
  const c = {}
  itens.value.forEach((i) => { const v = campo(i); if (v) c[v] = (c[v] || 0) + 1 })
  return contar(c, ordem)
}
// mesma coisa para campos com vários valores (ex.: o solicitante pode estar em várias filas)
const opcoesNLista = (campo) => {
  const c = {}
  itens.value.forEach((i) => (campo(i) || []).forEach((v) => { if (v) c[v] = (c[v] || 0) + 1 }))
  return contar(c)
}
function contar(c, ordem) {
  const ks = Object.keys(c)
  ordem ? ks.sort((a, b) => (ordem.indexOf(a) + 1 || 99) - (ordem.indexOf(b) + 1 || 99)) : ks.sort((a, b) => a.localeCompare(b, 'pt-BR'))
  return ks.map((v) => ({ v, n: c[v] }))
}
const algumFiltro = computed(() => [responsavel, solicitante, filaSol, tipo, acao, prioridade, etapa].some((r) => r.value.length))
function limparFiltros() { [responsavel, solicitante, filaSol, tipo, acao, prioridade, etapa].forEach((r) => (r.value = [])); busca.value = '' }

// Filtro por número do atendimento: aceita HT, protocolo ou id, parcial, vários separados por vírgula/espaço.
// Quando preenchido, procura em TODOS os atendimentos (ignora os outros filtros).
const termosNumero = computed(() =>
  numero.value.split(/[\s,;]+/).map((x) => x.trim().toUpperCase().replace(/^#/, '')).filter(Boolean))

function bateNumero(i) {
  const alvos = [i.numero, i.protocolo, String(i.id)].filter(Boolean).map((x) => String(x).toUpperCase())
  return termosNumero.value.some((t) => {
    const so = t.replace(/^HT/, '')
    return alvos.some((a) => a.includes(t) || (so && a.replace(/^HT/, '').includes(so)))
  })
}

const lista = computed(() => {
  if (termosNumero.value.length) return itens.value.filter(bateNumero)
  let l = itens.value
  if (situacao.value === 'pendentes') l = l.filter((i) => !i.direcionamento)
  if (situacao.value === 'direcionados') l = l.filter((i) => i.direcionamento)
  if (situacao.value === 'aprovados') l = l.filter((i) => statusDe(i.direcionamento) === 'aprovado')
  if (situacao.value === 'fila') l = l.filter(pedeFila)
  const em = (sel, v) => !sel.value.length || sel.value.includes(v)
  const emAlgum = (sel, vs) => !sel.value.length || (vs || []).some((v) => sel.value.includes(v))
  l = l.filter((i) => em(responsavel, i.responsavel) && em(solicitante, i.solicitante || '') && emAlgum(filaSol, i.fila_solicitante) && em(tipo, i.tipo) &&
    em(acao, i.pre_analise?.acao) && em(prioridade, i.pre_analise?.prioridade) && em(etapa, i.etapa))
  const q = busca.value.trim().toLowerCase()
  if (q) {
    l = l.filter((i) => [i.numero, i.protocolo, i.titulo, i.solicitante, i.responsavel, i.contrato,
      i.pre_analise?.pedido, i.pre_analise?.situacao, i.pre_analise?.sugestao].join(' ').toLowerCase().includes(q))
  }
  return l
})

// ---- visão compacta (tabela no estilo do relatório Excel)
const COLS = [
  { k: 'prio', t: 'Prior.', v: (i) => ({ Alta: 0, 'Média': 1, Baixa: 2 }[i.pre_analise?.prioridade] ?? 9) },
  { k: 'responsavel', t: 'Responsável', v: (i) => i.responsavel || '' },
  { k: 'numero', t: 'Atendimento', v: (i) => i.numero || '' },
  { k: 'protocolo', t: 'Protocolo', v: (i) => i.protocolo || '' },
  { k: 'tipo', t: 'Tipo', v: (i) => i.tipo || '' },
  { k: 'etapa', t: 'Etapa', v: (i) => i.etapa || '' },
  { k: 'ult', t: 'Última atualização', v: (i) => dataIso(i.ultima_interacao) },
  { k: 'criado', t: 'Criado em', v: (i) => dataIso(i.abertura) },
  { k: 'autor', t: 'Atualizado por', v: (i) => i.ultimo_autor || '' },
  { k: 'solicitante', t: 'Solicitante', v: (i) => i.solicitante || '' },
  { k: 'titulo', t: 'Título', v: (i) => i.titulo || '' },
  { k: 'acao', t: 'Ação sugerida', v: (i) => i.pre_analise?.acao || '' },
  { k: 'dir', t: 'Direcionado', v: (i) => (i.direcionamento ? 0 : 1) },
  { k: 'sem', t: 'Dias úteis sem interação', v: (i) => i.dias_uteis_sem_interacao ?? -1, num: true },
  { k: 'aberto', t: 'Dias úteis desde a abertura', v: (i) => i.dias_uteis_abertura ?? -1, num: true },
]
function dataIso(br) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})(?: (\d{2}):(\d{2}))?/.exec(br || '')
  return m ? `${m[3]}-${m[2]}-${m[1]} ${m[4] || '00'}:${m[5] || '00'}` : ''
}
function clicarCol(c) {
  if (ordenar.value.col === c.k) ordenar.value.asc = !ordenar.value.asc
  else ordenar.value = { col: c.k, asc: !c.num && !['ult', 'criado'].includes(c.k) }
}
const listaTabela = computed(() => {
  const c = COLS.find((x) => x.k === ordenar.value.col)
  if (!c) return lista.value
  const f = ordenar.value.asc ? 1 : -1
  return [...lista.value].sort((a, b) => {
    const x = c.v(a), y = c.v(b)
    return (typeof x === 'number' ? x - y : String(x).localeCompare(String(y), 'pt-BR')) * f
  })
})
const cartoes = computed(() => {
  if (modo.value === 'cartoes') return lista.value
  const i = itens.value.find((x) => x.id === selecionado.value)
  return i ? [i] : []
})
const corDias = (n) => (n > 30 ? 'd30' : n >= 8 ? 'd8' : '')
function abrir(i) { selecionado.value = selecionado.value === i.id ? null : i.id }

function rasc(i) {
  if (!rascunho.value[i.id]) {
    rascunho.value[i.id] = { texto: '', acao: '' }
  }
  return rascunho.value[i.id]
}

function concordar(i) {
  const r = rasc(i)
  r.acao = i.pre_analise?.acao || ''
  if (!r.texto) r.texto = 'De acordo com a sugestão.'
}

async function gravar(i, limpar = false) {
  const r = rasc(i)
  if (!limpar && !r.texto.trim() && !r.acao) return
  gravando.value[i.id] = true
  try {
    await api.direcionar(i.id, limpar ? '' : r.texto, limpar ? '' : r.acao)
    rascunho.value[i.id] = { texto: '', acao: '' }
    await carregar()
    emit('avisar', { texto: limpar ? `${i.numero || i.protocolo}: direcionamento removido`
      : `${i.numero || i.protocolo}: direcionamento gravado — aguardando sua confirmação para executar` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível gravar: ${e.message}`, erro: true })
  } finally {
    gravando.value[i.id] = false
  }
}

const statusDe = (d) => {
  const st = String(d?.status || '')
  if (st.startsWith('executado') || st.startsWith('concluído')) return 'executado'
  if (st.startsWith('aprovado')) return 'aprovado'
  return 'aguardando'
}
const corStatus = { executado: 'ok', aprovado: 'accent', aguardando: 'warn' }

// ---- aprovados que pedem outra fila (o Odoo não deixa o usuário do Julio mudar a fila: ele faz à mão)
const RE_FILA = /\bfila\b|devolv|implanta[cç][aã]o|relacionamento|outra equipe/i
function pedeFila(i) {
  const d = i.direcionamento
  if (!d) return false
  const st = String(d.status || '')
  if (st.startsWith('aguardando') || st.startsWith('removido') || st.startsWith('concluído') || st.startsWith('aprendizado')) return false
  if (d.acao === 'Devolver ao solicitante') return true
  if (d.acao === 'Repassar responsável' && !st.startsWith('executado')) return true
  return RE_FILA.test(d.texto || '') && !st.startsWith('executado')
}
const paraFila = computed(() => itens.value.filter(pedeFila))
function filaSugerida(i) {
  const d = i.direcionamento || {}
  const m = /fila\s+(?:de\s+|da\s+|do\s+)?([A-ZÀ-Úa-zà-ú0-9 ]{3,40})/i.exec(d.texto || '')
  if (m) return m[1].trim()
  if (d.acao === 'Devolver ao solicitante') {
    const fs = (i.fila_solicitante || []).filter((f) => f !== 'Dados Operacionais' && f !== 'Sem fila')
    if (fs.includes('Implantação')) return 'Implantação (fila do solicitante)'
    return fs.length ? fs.slice(0, 3).join(' / ') + (fs.length > 3 ? ` +${fs.length - 3}` : '') : 'solicitante sem fila'
  }
  return '—'
}
const verFila = ref(true)

// ---- dúvidas do Carregador (Duvidas.txt da pasta Carga SDI): o Julio responde aqui e o item volta para execução
const comDuvidas = computed(() => itens.value.filter((i) => (i.duvidas || []).some((d) => d.pendentes > 0)))
const resp = ref({})   // `${id}|${pasta}` -> [respostas]
function respDe(i, d) {
  const k = `${i.id}|${d.pasta}`
  if (!resp.value[k]) resp.value[k] = d.perguntas.map((p) => p.resposta || '')
  return resp.value[k]
}
async function gravarRespostas(i, d) {
  const k = `${i.id}|${d.pasta}`
  gravando.value[k] = true
  try {
    await api.respostas(i.id, d.pasta, respDe(i, d))
    delete resp.value[k]
    await carregar()
    emit('avisar', { texto: `${i.numero || i.protocolo}: respostas gravadas — o Carregador roda de novo na próxima hora (:47)` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível: ${e.message}. Se for "rota inexistente", feche a janela preta e abra o iniciar.bat.`, erro: true })
  } finally {
    gravando.value[k] = false
  }
}
async function concluir(i) {
  gravando.value[i.id] = true
  try {
    await api.concluir(i.id, 'Reatribuído de fila pelo Julio no Odoo')
    await carregar()
    emit('avisar', { texto: `${i.numero || i.protocolo}: marcado como reatribuído` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível: ${e.message}. Feche a janela preta da Plataforma e abra o iniciar.bat de novo.`, erro: true })
  } finally {
    gravando.value[i.id] = false
  }
}

async function aprovar(i, sim = true) {
  gravando.value[i.id] = true
  try {
    await api.aprovar(i.id, sim)
    await carregar()
    emit('avisar', { texto: sim ? `${i.numero || i.protocolo}: execução aprovada — o Executor roda na próxima hora (:47)`
      : `${i.numero || i.protocolo}: aprovação desfeita` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível: ${e.message}`, erro: true })
  } finally {
    gravando.value[i.id] = false
  }
}

function novoDirecionamento(i) {
  // nova rodada no mesmo atendimento (o anterior fica no histórico/aprendizado)
  rascunho.value[i.id] = { texto: '', acao: i.direcionamento?.acao || '' }
  i._editando = true
}

function editar(i) {
  rascunho.value[i.id] = { texto: i.direcionamento?.texto || '', acao: i.direcionamento?.acao || '' }
  i._editando = true
}

const corPrio = { Alta: 'danger', 'Média': 'warn', Baixa: '' }
const corTipo = { Carga: 'carga', Layout: 'layout', Sinistro: 'warn' }
const quando = (iso) => (iso ? new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '')

const esc = (e) => { if (e.key === 'Escape') selecionado.value = null }
onMounted(() => { carregar(); window.addEventListener('keydown', esc) })
onUnmounted(() => window.removeEventListener('keydown', esc))
defineExpose({ carregar })
</script>

<template>
  <section>
    <div class="topo card">
      <div>
        <b>Pré-análise da fila Dados Operacionais</b>
        <div class="muted">
          Gerada pelo Claude em {{ dados.gerado_em || '—' }} (dados do Odoo de {{ dados.coletado_em || '—' }}) ·
          {{ itens.length }} atendimentos · {{ pendentes }} sem direcionamento ·
          {{ dados.total_aprendizado }} direcionamento(s) já registrados para aprendizado
        </div>
      </div>
      <button class="btn" :disabled="carregando" @click="carregar">{{ carregando ? 'Lendo…' : '↻ Recarregar' }}</button>
    </div>

    <div class="filtros card">
      <div class="seg">
        <span class="modo" role="group" aria-label="Visão">
          <button :class="{ on: modo === 'tabela' }" @click="modo = 'tabela'" title="Visão compacta, como o relatório">☰ Compacta</button>
          <button :class="{ on: modo === 'cartoes' }" @click="modo = 'cartoes'" title="Visão com a pré-análise completa">▤ Cartões</button>
        </span>
        <button :class="{ on: situacao === 'pendentes' }" @click="situacao = 'pendentes'">Sem direcionamento</button>
        <button :class="{ on: situacao === 'direcionados' }" @click="situacao = 'direcionados'">Direcionados</button>
        <button :class="{ on: situacao === 'aprovados' }" @click="situacao = 'aprovados'">Aprovados p/ executar</button>
        <button :class="{ on: situacao === 'fila' }" @click="situacao = 'fila'">Reatribuir fila<span v-if="paraFila.length" class="cont-fila">{{ paraFila.length }}</span></button>
        <button :class="{ on: situacao === '' }" @click="situacao = ''">Todos</button>
      </div>
      <div class="linha">
        <input v-model="numero" class="num" type="search" inputmode="text" aria-label="Número do atendimento"
               placeholder="Nº do atendimento (HT, protocolo ou id)" />
        <input v-model="busca" type="search" placeholder="Buscar por cliente, solicitante, texto…" />
        <MultiFiltro v-model="prioridade" rotulo="Prioridade" todos="Toda prioridade" :opcoes="opcoesN((i) => i.pre_analise?.prioridade, ['Alta', 'Média', 'Baixa'])" />
        <MultiFiltro v-model="acao" rotulo="Ação" todos="Toda ação sugerida" :opcoes="opcoesN((i) => i.pre_analise?.acao)" />
        <MultiFiltro v-model="tipo" rotulo="Tipo" todos="Todo tipo" :opcoes="opcoesN((i) => i.tipo)" />
        <MultiFiltro v-model="etapa" rotulo="Etapa" todos="Toda etapa" :opcoes="opcoesN((i) => i.etapa)" />
        <MultiFiltro v-model="responsavel" rotulo="Responsável" todos="Todos os responsáveis" :opcoes="opcoesN((i) => i.responsavel)" />
        <MultiFiltro v-model="solicitante" rotulo="Solicitante" todos="Todos os solicitantes" :opcoes="opcoesN((i) => i.solicitante)" />
        <MultiFiltro v-model="filaSol" rotulo="Fila do solicitante" todos="Toda fila do solicitante" :opcoes="opcoesNLista((i) => i.fila_solicitante)" />
        <button v-if="algumFiltro || busca" type="button" class="btn limpar" @click="limparFiltros">✕ Limpar filtros</button>
      </div>
    </div>

    <div v-if="comDuvidas.length" class="card fila-box duv-box">
      <div class="fila-top">
        <b>Dúvidas do Carregador ({{ comDuvidas.length }})</b>
        <span class="muted">O Carregador parou por falta de informação. Clique no atendimento, responda e grave — ele roda de novo sozinho.</span>
      </div>
      <table class="fila-tab">
        <thead><tr><th>Atendimento</th><th>Protocolo</th><th>Título</th><th>Pendentes</th><th></th></tr></thead>
        <tbody>
          <tr v-for="i in comDuvidas" :key="i.id">
            <td class="nw"><a :href="i.link" target="_blank" rel="noopener">{{ i.numero || i.protocolo }}</a></td>
            <td class="nw">{{ i.protocolo }}</td>
            <td class="tt" :title="i.titulo">{{ i.titulo }}</td>
            <td>{{ i.duvidas.reduce((s, d) => s + d.pendentes, 0) }} pergunta(s)</td>
            <td class="nw"><button class="btn" @click="selecionado = i.id">Responder</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="paraFila.length" class="card fila-box">
      <div class="fila-top">
        <b>Reatribuir para outra fila ({{ paraFila.length }})</b>
        <span class="muted">Aprovados que pedem outra fila — o Odoo não deixa o seu usuário mudar a fila, faça no Odoo e marque aqui.</span>
        <button class="link" @click="verFila = !verFila">{{ verFila ? 'ocultar' : 'mostrar' }}</button>
      </div>
      <table v-if="verFila" class="fila-tab">
        <thead><tr><th>Atendimento</th><th>Protocolo</th><th>Título</th><th>Solicitante</th><th>Atribuído a</th><th>Fila sugerida</th><th>Seu direcionamento</th><th></th></tr></thead>
        <tbody>
          <tr v-for="i in paraFila" :key="i.id">
            <td class="nw"><a :href="i.link" target="_blank" rel="noopener">{{ i.numero || i.protocolo }}</a></td>
            <td class="nw">{{ i.protocolo }}</td>
            <td class="tt" :title="i.titulo">{{ i.titulo }}</td>
            <td>{{ i.solicitante }}</td>
            <td>{{ i.responsavel }}</td>
            <td><b>{{ filaSugerida(i) }}</b></td>
            <td><span class="chip accent">{{ i.direcionamento.acao || '—' }}</span> {{ i.direcionamento.texto }}</td>
            <td class="nw"><button class="btn" :disabled="gravando[i.id]" @click="concluir(i)">✔ Já reatribuí</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="erro" class="card erro">Erro ao ler a pré-análise: {{ erro }}</div>
    <div v-else-if="!carregando && !itens.length" class="card vazio">
      Nenhuma pré-análise ainda. Peça ao Claude: "gera a pré-análise" — ele grava em _sistema\preanalise.json.
    </div>
    <div v-else-if="!lista.length" class="card vazio">
      {{ termosNumero.length ? `Nenhum atendimento aberto com o número "${numero}".` : 'Nenhum atendimento com esses filtros.' }}
    </div>
    <div v-else-if="termosNumero.length" class="muted aviso">
      {{ lista.length }} atendimento(s) encontrado(s) pelo número — os outros filtros estão ignorados enquanto este campo estiver preenchido.
    </div>

    <div v-if="modo === 'tabela' && lista.length" class="card tab-wrap">
      <table class="tab">
        <thead>
          <tr>
            <th v-for="c in COLS" :key="c.k" :class="{ num: c.num, ord: ordenar.col === c.k }" @click="clicarCol(c)"
                :aria-sort="ordenar.col === c.k ? (ordenar.asc ? 'ascending' : 'descending') : 'none'">
              {{ c.t }}<span v-if="ordenar.col === c.k">{{ ordenar.asc ? ' ▲' : ' ▼' }}</span>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="i in listaTabela" :key="i.id" :class="{ sel: selecionado === i.id }" tabindex="0"
              @click="abrir(i)" @keydown.enter="abrir(i)" title="Clique para ver a pré-análise e direcionar">
            <td><span class="chip" :class="corPrio[i.pre_analise?.prioridade]">{{ i.pre_analise?.prioridade }}</span></td>
            <td>{{ i.responsavel }}</td>
            <td><a :href="i.link" target="_blank" rel="noopener" @click.stop>{{ i.numero || '—' }}</a></td>
            <td>{{ i.protocolo }}</td>
            <td><span class="chip" :class="corTipo[i.tipo]">{{ i.tipo }}</span></td>
            <td>{{ i.etapa }}</td>
            <td class="nw">{{ i.ultima_interacao }}</td>
            <td class="nw">{{ i.abertura }}</td>
            <td>{{ i.ultimo_autor }}</td>
            <td>{{ i.solicitante }}</td>
            <td class="tt" :title="i.titulo">{{ i.titulo }}</td>
            <td class="nw">{{ i.pre_analise?.acao }}</td>
            <td class="c">
              <span v-if="i.direcionamento" class="chip" :class="corStatus[statusDe(i.direcionamento)]"
                    :title="i.direcionamento.status + ' — ' + (i.direcionamento.texto || '')">
                {{ { executado: '✓✓', aprovado: '✔', aguardando: '…' }[statusDe(i.direcionamento)] }} {{ i.direcionamento.acao || 'sim' }}
              </span>
              <span v-else class="muted">—</span>
            </td>
            <td class="num" :class="corDias(i.dias_uteis_sem_interacao)">{{ i.dias_uteis_sem_interacao }}</td>
            <td class="num" :class="corDias(i.dias_uteis_abertura)">{{ i.dias_uteis_abertura }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="modo === 'tabela' && cartoes.length" class="fundo" @click="selecionado = null"></div>
    <aside v-if="cartoes.length" :class="{ painel: modo === 'tabela' }">
      <div v-if="modo === 'tabela'" class="painel-topo">
        <b>Pré-análise</b>
        <button class="fechar" aria-label="Fechar" @click="selecionado = null">×</button>
      </div>
    <article v-for="i in cartoes" :key="i.id" class="card item">
      <header>
        <div class="tit">
          <a :href="i.link" target="_blank" rel="noopener">{{ i.numero || '#' + i.protocolo }}</a>
          <span class="muted">({{ i.protocolo }})</span>
          <span class="nome">{{ i.titulo }}</span>
        </div>
        <div class="chips">
          <span class="chip" :class="corPrio[i.pre_analise?.prioridade]">{{ i.pre_analise?.prioridade }}</span>
          <span class="chip" :class="corTipo[i.tipo]">{{ i.tipo }}</span>
          <span class="chip">{{ i.responsavel }}</span>
          <span class="chip" :class="i.dias_uteis_abertura > 30 ? 'danger' : i.dias_uteis_abertura > 7 ? 'warn' : ''"
                title="Dias úteis desde a abertura">{{ i.dias_uteis_abertura }} du aberto</span>
          <span class="chip" :class="i.dias_uteis_sem_interacao > 7 ? 'warn' : ''"
                title="Dias úteis sem interação">{{ i.dias_uteis_sem_interacao }} du sem interação</span>
        </div>
      </header>
      <div class="meta muted">
        Solicitante: <b>{{ i.solicitante || '—' }}</b>
        <span v-if="i.fila_solicitante?.length" :title="i.fila_solicitante.join(', ')"> (fila{{ i.fila_solicitante.length > 1 ? 's' : '' }}: {{ i.fila_solicitante.slice(0, 3).join(', ') }}{{ i.fila_solicitante.length > 3 ? ` +${i.fila_solicitante.length - 3}` : '' }})</span> · Etapa: {{ i.etapa }} · Aberto em {{ i.abertura }} ·
        Última interação {{ i.ultima_interacao }}<span v-if="i.ultimo_autor"> ({{ i.ultimo_autor }})</span>
        <span v-if="i.contrato"> · Contrato {{ i.contrato }}</span>
      </div>

      <dl class="pa">
        <dt>Pedido</dt><dd>{{ i.pre_analise?.pedido }}</dd>
        <dt>Situação</dt><dd>{{ i.pre_analise?.situacao }}</dd>
        <dt>Sugestão do Claude</dt>
        <dd><span class="chip accent">{{ i.pre_analise?.acao }}</span> {{ i.pre_analise?.sugestao }}</dd>
        <template v-if="i.anexos?.length">
          <dt>Anexos</dt><dd class="muted">{{ i.anexos.map((a) => `${a.nome} (${a.data})`).join(' · ') }}</dd>
        </template>
        <template v-if="i.dados_contrato">
          <dt>Contrato (carga sem arquivo)</dt>
          <dd v-if="i.dados_contrato.erro" class="muted">{{ i.dados_contrato.erro }}</dd>
          <dd v-else class="dc">
            <div><b>{{ i.dados_contrato.contrato }}</b> · Apólice {{ i.dados_contrato.apolice || '—' }} · {{ i.dados_contrato.operadora }}
              <span v-if="i.dados_contrato.identificado_pelo_texto || i.dados_contrato.identificado_pelo_nome" class="chip warn">confira o contrato</span>
              <span v-if="i.dados_contrato.status_ok === false" class="chip danger">contrato {{ i.dados_contrato.status }} — não está Ativo nem Em Implantação</span>
              <span v-else-if="i.dados_contrato.status" class="chip ok">{{ i.dados_contrato.status }}</span></div>
            <div class="dc-t">Subempresas ativas/em implantação ({{ i.dados_contrato.subcontratos.length }}<template v-if="i.dados_contrato.subcontratos_ignorados?.length"> · {{ i.dados_contrato.subcontratos_ignorados.length }} fechada(s) ocultada(s)</template>)</div>
            <ul v-if="i.dados_contrato.subcontratos.length"><li v-for="sc in i.dados_contrato.subcontratos" :key="sc.nome"><b>{{ sc.codigo || '—' }}</b> · {{ sc.razao_social || sc.nome }} · {{ sc.cnpj }} · {{ sc.status }}</li></ul>
            <div v-else class="muted">nenhuma</div>
            <div class="dc-t">Planos</div>
            <ul v-if="i.dados_contrato.planos.length"><li v-for="(p, k) in i.dados_contrato.planos" :key="k"><b>{{ p.codigo_plano || p.codigo }}</b> · {{ p.nome }} · {{ p.acomodacao }}</li></ul>
            <div v-else class="muted">nenhum</div>
            <div class="dc-t">Acessos</div>
            <ul v-if="i.dados_contrato.portais.length"><li v-for="pa in i.dados_contrato.portais" :key="pa.codigo">
              <b>{{ pa.portal }}</b> · Entrar: {{ pa.login }} ·
              <a :href="pa.site.startsWith('http') ? pa.site : 'https://' + pa.site" target="_blank" rel="noopener">site</a> ·
              <a :href="pa.link" target="_blank" rel="noopener">senha no Odoo</a></li></ul>
            <div v-else-if="i.dados_contrato.identificado_pelo_texto || i.dados_contrato.identificado_pelo_nome" class="chip warn">Sem acesso cadastrado — mas o contrato foi deduzido do título; vincule o contrato no atendimento para eu postar a nota</div>
            <div v-else class="chip warn">Sem acesso cadastrado no contrato — ao executar, posto nota interna marcando o solicitante</div>
          </dd>
        </template>
      </dl>

      <div v-for="d in (i.duvidas || [])" :key="d.pasta" class="duv">
        <b>Dúvidas do Carregador</b> <span class="muted">— Carga SDI\{{ d.pasta }}\Arquivo Final\Duvidas.txt</span>
        <div v-for="(p, k) in d.perguntas" :key="k" class="duv-q">
          <div class="duv-p">{{ k + 1 }}. {{ p.pergunta }}</div>
          <textarea v-model="respDe(i, d)[k]" rows="2" placeholder="Sua resposta…"></textarea>
        </div>
        <button class="btn small primary" :disabled="gravando[`${i.id}|${d.pasta}`] || !respDe(i, d).some((r) => r && r.trim())"
                @click="gravarRespostas(i, d)">{{ gravando[`${i.id}|${d.pasta}`] ? 'Gravando…' : 'Gravar respostas e reenviar ao Carregador' }}</button>
      </div>

      <button class="link" @click="aberto[i.id] = !aberto[i.id]">
        {{ aberto[i.id] ? '▾ Esconder interações' : `▸ Ver últimas interações (${i.mensagens?.length || 0})` }}
      </button>
      <ul v-if="aberto[i.id]" class="msgs">
        <li v-for="(m, k) in i.mensagens" :key="k"><b>{{ m.data }} · {{ m.autor }}</b><div>{{ m.texto }}</div></li>
      </ul>

      <div v-if="i.direcionamento && !i._editando" class="dir ok">
        <div>
          <b>Seu direcionamento</b> <span class="muted">({{ quando(i.direcionamento.quando) }})</span>
          <span v-if="i.direcionamento.acao" class="chip ok">{{ i.direcionamento.acao }}</span>
          <span class="chip" :class="corStatus[statusDe(i.direcionamento)]">{{ i.direcionamento.status }}</span>
          <div class="txt">{{ i.direcionamento.texto }}</div>
          <div v-if="i.direcionamento.execucao" class="muted exec">↳ {{ i.direcionamento.execucao }}</div>
        </div>
        <div class="acoes">
          <template v-if="statusDe(i.direcionamento) === 'aguardando'">
            <button class="btn small primary" :disabled="gravando[i.id]" @click="aprovar(i)">✔ Aprovar execução</button>
            <button class="btn small" @click="editar(i)">Editar</button>
            <button class="btn small" :disabled="gravando[i.id]" @click="gravar(i, true)">Remover</button>
          </template>
          <button v-else-if="statusDe(i.direcionamento) === 'aprovado'" class="btn small" :disabled="gravando[i.id]"
                  @click="aprovar(i, false)">Desfazer aprovação</button>
          <button v-if="statusDe(i.direcionamento) !== 'aguardando' || /^falhou/.test(i.direcionamento.status || '')"
                  class="btn small" title="Ex.: o solicitante mandou um arquivo novo e o Maninha precisa rodar de novo"
                  @click="novoDirecionamento(i)">+ Novo direcionamento</button>
        </div>
      </div>
      <div v-else class="dir">
        <label :for="'d' + i.id"><b>Seu direcionamento</b></label>
        <textarea :id="'d' + i.id" v-model="rasc(i).texto" rows="2"
                  placeholder="Ex.: concordo; ou: não é com a gente, devolver para o Relacionamento; ou: priorizar hoje…"></textarea>
        <div class="linha">
          <select v-model="rasc(i).acao" aria-label="Ação">
            <option value="">Ação (opcional)</option>
            <option v-for="a in ACOES" :key="a">{{ a }}</option>
          </select>
          <button class="btn small" @click="concordar(i)">Concordo com a sugestão</button>
          <button class="btn small primary" :disabled="gravando[i.id] || (!rasc(i).texto.trim() && !rasc(i).acao)" @click="gravar(i)">
            {{ gravando[i.id] ? 'Gravando…' : 'Gravar direcionamento' }}
          </button>
          <button v-if="i._editando" class="btn small" @click="i._editando = false">Cancelar</button>
        </div>
      </div>
    </article>
    </aside>
  </section>
</template>

<style scoped>
.topo { display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 12px 16px; margin-bottom: 12px; }
.filtros { padding: 12px 16px; margin-bottom: 12px; display: grid; gap: 10px; }
.seg { display: flex; gap: 6px; flex-wrap: wrap; }
.seg button { border: 1px solid var(--border); background: var(--surface); border-radius: 999px; padding: 4px 12px; cursor: pointer; }
.seg button.on { background: var(--accent); border-color: var(--accent); color: #fff; }
.linha { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.linha input { flex: 1 1 260px; min-width: 0; }
.linha input.num { flex: 0 1 260px; }
.linha .mf { flex: 0 1 210px; }
.dc ul { margin: 2px 0 6px; padding-left: 18px; }
.dc li { margin: 1px 0; overflow-wrap: anywhere; }
.dc .chip { white-space: normal; }
.fila-box.duv-box { border-left-color: #7c3aed; }
.duv { margin: 10px 0; padding: 10px 12px; border: 1px solid #ddd6fe; background: #f5f3ff; border-radius: 8px; }
.duv-q { margin: 8px 0; }
.duv-p { white-space: pre-wrap; margin-bottom: 4px; }
.duv textarea { width: 100%; box-sizing: border-box; font: inherit; padding: 6px 8px; border: 1px solid #c4b5fd; border-radius: 6px; }
.fila-box { padding: 12px 16px; margin-bottom: 12px; border-left: 4px solid #d97706; }
.fila-top { display: flex; gap: 12px; align-items: baseline; flex-wrap: wrap; }
.fila-tab { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 13px; }
.fila-tab th { text-align: left; color: var(--muted); font-weight: 600; padding: 4px 6px; border-bottom: 1px solid #e5e7eb; }
.fila-tab td { padding: 5px 6px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
.fila-tab .tt { max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cont-fila { margin-left: 6px; background: #d97706; color: #fff; border-radius: 9px; padding: 0 6px; font-size: 12px; }
.dc-t { margin-top: 6px; font-weight: 600; font-size: 13px; }
.linha .limpar { white-space: nowrap; }
.aviso { margin: 0 4px 10px; font-size: 13px; }
input, select, textarea { border: 1px solid var(--border); background: var(--surface); border-radius: 8px; padding: 6px 10px; }
.item { padding: 14px 16px; margin-bottom: 10px; }
header { display: flex; justify-content: space-between; gap: 10px; flex-wrap: wrap; }
.tit { display: flex; gap: 6px; align-items: baseline; flex-wrap: wrap; min-width: 0; }
.tit a { font-weight: 700; }
.nome { font-weight: 600; }
.chips { display: flex; gap: 4px; flex-wrap: wrap; }
.meta { font-size: 13px; margin-top: 4px; }
.pa { display: grid; grid-template-columns: 150px 1fr; gap: 4px 12px; margin: 10px 0 6px; }
.pa dt { color: var(--muted); font-weight: 600; }
.pa dd { margin: 0; min-width: 0; overflow-wrap: anywhere; }
.link { background: none; border: 0; color: var(--accent); cursor: pointer; padding: 0; font-size: 13px; }
.msgs { list-style: none; padding: 0; margin: 8px 0; display: grid; gap: 6px; }
.msgs li { background: var(--surface-2); border-radius: 8px; padding: 6px 10px; font-size: 13px; }
.dir { margin-top: 10px; padding: 10px; border-radius: 8px; background: var(--surface-2); display: grid; gap: 6px; }
.dir.ok { display: flex; justify-content: space-between; gap: 10px; background: var(--ok-soft); }
.dir textarea { width: 100%; resize: vertical; }
.dir .txt { margin-top: 4px; white-space: pre-wrap; }
.dir .exec { margin-top: 4px; font-size: 13px; }
.acoes { flex-wrap: wrap; justify-content: flex-end; }
.acoes { display: flex; gap: 6px; align-items: flex-start; }
.modo { display: inline-flex; border: 1px solid var(--border); border-radius: 999px; overflow: hidden; margin-right: 6px; }
.modo button { border: 0; border-radius: 0; padding: 4px 12px; background: var(--surface); cursor: pointer; }
.modo button.on { background: var(--text); color: var(--bg); }
.tab-wrap { overflow: auto; max-height: calc(100vh - 290px); padding: 0; }
.tab { width: 100%; border-collapse: collapse; font-size: 13px; }
.tab th { position: sticky; top: 0; z-index: 1; background: #1f4e78; color: #fff; text-align: left; font-weight: 600;
  padding: 7px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.tab th.num { text-align: right; white-space: normal; min-width: 96px; line-height: 1.2; }
.tab td { padding: 4px 8px; border-bottom: 1px solid var(--border); vertical-align: middle; white-space: nowrap; }
.tab tbody tr:nth-child(even) td { background: var(--surface-2); }
.tab tbody tr { cursor: pointer; }
.tab tbody tr:hover td, .tab tbody tr.sel td { background: var(--accent-soft); }
.tab tbody tr:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; }
.tab td.num { text-align: right; font-variant-numeric: tabular-nums; font-weight: 600; }
.tab td.d8 { background: #ffe699 !important; color: #5c4400; }
.tab td.d30 { background: #f8cbad !important; color: #6b2108; }
.tab td.tt { max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tab td.nw { white-space: nowrap; }
.tab td.c { text-align: center; }
.fundo { position: fixed; inset: 0; background: rgba(0, 0, 0, .25); z-index: 20; }
.painel { position: fixed; top: 0; right: 0; bottom: 0; width: min(640px, 100%); z-index: 21; overflow: auto;
  background: var(--bg); padding: 0 14px 20px; box-shadow: -8px 0 24px rgba(0, 0, 0, .18); }
.painel-topo { position: sticky; top: 0; display: flex; justify-content: space-between; align-items: center;
  padding: 12px 2px; background: var(--bg); z-index: 1; }
.painel .item { margin-bottom: 0; }
.fechar { background: none; border: 0; font-size: 22px; cursor: pointer; color: var(--muted); }
.erro { padding: 12px 16px; border-color: var(--danger); color: var(--danger); }
@media (max-width: 640px) {
  .pa { grid-template-columns: 1fr; }
  .dir.ok { flex-direction: column; }
}
</style>
