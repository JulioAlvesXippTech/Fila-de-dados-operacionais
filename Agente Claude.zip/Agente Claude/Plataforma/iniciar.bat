@echo off
title Agente de Atendimentos - Plataforma
cd /d "%~dp0"
where py >NUL 2>NUL
if %errorlevel%==0 (
  py -3 servidor.py
) else (
  python servidor.py
)
pause
