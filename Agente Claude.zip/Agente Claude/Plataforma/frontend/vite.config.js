import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Em desenvolvimento (npm run dev) as chamadas /api vão para o servidor Python (python servidor.py --sem-navegador)
export default defineConfig({
  plugins: [vue()],
  server: { proxy: { '/api': 'http://localhost:8765' } },
})
