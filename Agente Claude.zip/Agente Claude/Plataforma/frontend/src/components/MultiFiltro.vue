<script setup>
// Filtro de múltipla escolha: botão que abre uma lista com caixas de seleção.
// v-model = array de valores escolhidos (vazio = todos).
import { ref, computed, onMounted, onUnmounted } from 'vue'

const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  opcoes: { type: Array, default: () => [] },      // [{ v, n }]  valor e contagem
  rotulo: { type: String, required: true },         // ex.: "Responsável"
  todos: { type: String, required: true },          // ex.: "Todos os responsáveis"
})
const emit = defineEmits(['update:modelValue'])
const aberto = ref(false)
const q = ref('')
const raiz = ref(null)

const visiveis = computed(() => {
  const t = q.value.trim().toLowerCase()
  return t ? props.opcoes.filter((o) => String(o.v).toLowerCase().includes(t)) : props.opcoes
})
const texto = computed(() => {
  const s = props.modelValue
  if (!s.length) return props.todos
  if (s.length === 1) return `${props.rotulo}: ${s[0]}`
  return `${props.rotulo}: ${s.length} selecionados`
})
function alternar(v) {
  const s = new Set(props.modelValue)
  s.has(v) ? s.delete(v) : s.add(v)
  emit('update:modelValue', props.opcoes.map((o) => o.v).filter((x) => s.has(x)).concat([...s].filter((x) => !props.opcoes.some((o) => o.v === x))))
}
function marcarVisiveis() {
  const s = new Set(props.modelValue)
  visiveis.value.forEach((o) => s.add(o.v))
  emit('update:modelValue', [...s])
}
const limpar = () => emit('update:modelValue', [])
const fora = (e) => { if (aberto.value && raiz.value && !raiz.value.contains(e.target)) aberto.value = false }
const esc = (e) => { if (e.key === 'Escape' && aberto.value) { aberto.value = false; e.stopPropagation() } }
onMounted(() => { document.addEventListener('mousedown', fora); document.addEventListener('keydown', esc, true) })
onUnmounted(() => { document.removeEventListener('mousedown', fora); document.removeEventListener('keydown', esc, true) })
</script>

<template>
  <div ref="raiz" class="mf" :class="{ ativo: modelValue.length }">
    <button type="button" class="mf-btn" :aria-expanded="aberto" :title="modelValue.join(', ')" @click="aberto = !aberto">
      <span class="mf-txt">{{ texto }}</span><span class="mf-seta">▾</span>
    </button>
    <div v-if="aberto" class="mf-pop" role="listbox" aria-multiselectable="true">
      <input v-if="opcoes.length > 8" v-model="q" class="mf-q" type="search" placeholder="Procurar…" />
      <div class="mf-acoes">
        <button type="button" @click="marcarVisiveis">Marcar {{ q ? 'encontrados' : 'todos' }}</button>
        <button type="button" :disabled="!modelValue.length" @click="limpar">Limpar</button>
      </div>
      <div class="mf-lista">
        <label v-for="o in visiveis" :key="o.v" class="mf-op">
          <input type="checkbox" :checked="modelValue.includes(o.v)" @change="alternar(o.v)" />
          <span class="mf-v">{{ o.v }}</span><span class="mf-n">{{ o.n }}</span>
        </label>
        <div v-if="!visiveis.length" class="mf-vazio">Nada encontrado</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.mf { position: relative; min-width: 0; }
.mf-btn { width: 100%; display: flex; align-items: center; gap: 6px; justify-content: space-between; text-align: left;
  font: inherit; padding: 8px 10px; border: 1px solid var(--borda, #d0d5dd); border-radius: 8px; background: var(--fundo-campo, #fff);
  color: inherit; cursor: pointer; white-space: nowrap; }
.mf.ativo .mf-btn { border-color: #2563eb; background: #eef4ff; color: #1d4ed8; font-weight: 600; }
.mf-txt { overflow: hidden; text-overflow: ellipsis; }
.mf-seta { opacity: .6; }
.mf-pop { position: absolute; z-index: 50; top: calc(100% + 4px); left: 0; min-width: 100%; width: max-content; max-width: 360px;
  background: #fff; color: #111; border: 1px solid #d0d5dd; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,.15); padding: 8px; }
.mf-q { width: 100%; box-sizing: border-box; margin-bottom: 6px; padding: 6px 8px; border: 1px solid #d0d5dd; border-radius: 6px; font: inherit; }
.mf-acoes { display: flex; gap: 6px; margin-bottom: 6px; }
.mf-acoes button { font: inherit; font-size: 12px; padding: 3px 8px; border: 1px solid #d0d5dd; border-radius: 6px; background: #f8fafc; cursor: pointer; }
.mf-acoes button:disabled { opacity: .5; cursor: default; }
.mf-lista { max-height: 300px; overflow: auto; }
.mf-op { display: flex; align-items: center; gap: 8px; padding: 5px 6px; border-radius: 6px; cursor: pointer; }
.mf-op:hover { background: #f1f5f9; }
.mf-v { flex: 1; }
.mf-n { font-size: 12px; color: #64748b; }
.mf-vazio { padding: 6px; color: #64748b; font-size: 13px; }
</style>
