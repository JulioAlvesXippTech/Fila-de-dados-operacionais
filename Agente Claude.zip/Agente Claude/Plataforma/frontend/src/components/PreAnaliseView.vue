<script setup>
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import { api } from '../api.js'
import MultiFiltro from './MultiFiltro.vue'

const emit = defineEmits(['avisar', 'contagem'])
const dados = ref({ itens: [], gerado_em: '', coletado_em: '', total_aprendizado: 0 })
const carregando = ref(false)
const erro = ref('')

const LS = 'agente-filtros-preanalise'
const salvo = (() => { try { return JSON.parse(localStorage.getItem(LS) || '{}') } catch { return {} } })()
const busca = ref('')
const numero = ref('')
// Filtros de múltipla escolha (array vazio = todos). Aceita o formato antigo salvo (texto único).
const lista0 = (v) => (Array.isArray(v) ? v : v ? [v] : [])
const responsavel = ref(lista0(salvo.responsavel))
const solicitante = ref(lista0(salvo.solicitante))
const tipo = ref(lista0(salvo.tipo))
const acao = ref(lista0(salvo.acao))
const prioridade = ref(lista0(salvo.prioridade))
const etapa = ref(lista0(salvo.etapa))
const filaSol = ref(lista0(salvo.filaSol))
const situacao = ref(salvo.situacao ?? 'pendentes')
const modo = ref(salvo.modo || 'tabela')          // 'tabela' (compacta, como o relatório) ou 'cartoes'
const selecionado = ref(null)                     // id aberto no painel lateral (modo tabela)
const ordenar = ref({ col: '', asc: true })
watch([responsavel, solicitante, filaSol, tipo, acao, prioridade, etapa, situacao, modo], () => {
  try {
    localStorage.setItem(LS, JSON.stringify({ responsavel: responsavel.value, solicitante: solicitante.value, tipo: tipo.value, acao: acao.value,
      prioridade: prioridade.value, etapa: etapa.value, filaSol: filaSol.value, situacao: situacao.value, modo: modo.value }))
  } catch {}
}, { deep: true })

const ACOES = ['Maninha', 'Carregador', 'Baixar/enviar PC', 'Cobrar operadora', 'Cobrar solicitante',
  'Responder solicitante', 'Devolver ao solicitante', 'Repassar responsável', 'Aguardar terceiro', 'Tech/sistema', 'Carga sem arquivo – dados do contrato', 'Avançar para Em andamento', 'Encerrar (Fechado)', 'Reatribuir fila', 'Outro']

const rascunho = ref({})   // id -> { texto, acao }
const aberto = ref({})     // id -> mostra histórico
const gravando = ref({})

async function carregar() {
  carregando.value = true
  erro.value = ''
  try {
    dados.value = await api.preanalise()
    emit('contagem', pendentes.value)
  } catch (e) {
    erro.value = e.message
  } finally {
    carregando.value = false
  }
}

const itens = computed(() => dados.value.itens || [])
const pendentes = computed(() => itens.value.filter((i) => !i.direcionamento).length)
const opcoes = (campo) => [...new Set(itens.value.map(campo).filter(Boolean))].sort()
// opções com contagem, para os filtros de múltipla escolha
const opcoesN = (campo, ordem) => {
  const c = {}
  itens.value.forEach((i) => { const v = campo(i); if (v) c[v] = (c[v] || 0) + 1 })
  return contar(c, ordem)
}
// mesma coisa para campos com vários valores (ex.: o solicitante pode estar em várias filas)
const opcoesNLista = (campo) => {
  const c = {}
  itens.value.forEach((i) => (campo(i) || []).forEach((v) => { if (v) c[v] = (c[v] || 0) + 1 }))
  return contar(c)
}
function contar(c, ordem) {
  const ks = Object.keys(c)
  ordem ? ks.sort((a, b) => (ordem.indexOf(a) + 1 || 99) - (ordem.indexOf(b) + 1 || 99)) : ks.sort((a, b) => a.localeCompare(b, 'pt-BR'))
  return ks.map((v) => ({ v, n: c[v] }))
}
const algumFiltro = computed(() => [responsavel, solicitante, filaSol, tipo, acao, prioridade, etapa].some((r) => r.value.length))
function limparFiltros() { [responsavel, solicitante, filaSol, tipo, acao, prioridade, etapa].forEach((r) => (r.value = [])); busca.value = '' }

// Filtro por número do atendimento: aceita HT, protocolo ou id, parcial, vários separados por vírgula/espaço.
// Quando preenchido, procura em TODOS os atendimentos (ignora os outros filtros).
const termosNumero = computed(() =>
  numero.value.split(/[\s,;]+/).map((x) => x.trim().toUpperCase().replace(/^#/, '')).filter(Boolean))

function bateNumero(i) {
  const alvos = [i.numero, i.protocolo, String(i.id)].filter(Boolean).map((x) => String(x).toUpperCase())
  return termosNumero.value.some((t) => {
    const so = t.replace(/^HT/, '')
    return alvos.some((a) => a.includes(t) || (so && a.replace(/^HT/, '').includes(so)))
  })
}

const lista = computed(() => {
  if (termosNumero.value.length) return itens.value.filter(bateNumero)
  let l = itens.value
  if (situacao.value === 'pendentes') l = l.filter((i) => !i.direcionamento)
  if (situacao.value === 'direcionados') l = l.filter((i) => i.direcionamento)
  if (situacao.value === 'aprovados') l = l.filter((i) => ['aprovado', 'enviado'].includes(statusDe(i.direcionamento)))
  if (situacao.value === 'fila') l = l.filter(pedeFila)
  const em = (sel, v) => !sel.value.length || sel.value.includes(v)
  const emAlgum = (sel, vs) => !sel.value.length || (vs || []).some((v) => sel.value.includes(v))
  l = l.filter((i) => em(responsavel, i.responsavel) && em(solicitante, i.solicitante || '') && emAlgum(filaSol, i.fila_solicitante) && em(tipo, i.tipo) &&
    em(acao, i.pre_analise?.acao) && em(prioridade, i.pre_analise?.prioridade) && em(etapa, i.etapa))
  const q = busca.value.trim().toLowerCase()
  if (q) {
    l = l.filter((i) => [i.numero, i.protocolo, i.titulo, i.solicitante, i.responsavel, i.contrato,
      i.pre_analise?.pedido, i.pre_analise?.situacao, i.pre_analise?.sugestao].join(' ').toLowerCase().includes(q))
  }
  return l
})

// ---- visão compacta (tabela no estilo do relatório Excel)
const COLS = [
  { k: 'prio', t: 'Prior.', v: (i) => ({ Alta: 0, 'Média': 1, Baixa: 2 }[i.pre_analise?.prioridade] ?? 9) },
  { k: 'responsavel', t: 'Responsável', v: (i) => i.responsavel || '' },
  { k: 'numero', t: 'Atendimento', v: (i) => i.numero || '' },
  { k: 'protocolo', t: 'Protocolo', v: (i) => i.protocolo || '' },
  { k: 'tipo', t: 'Tipo', v: (i) => i.tipo || '' },
  { k: 'etapa', t: 'Etapa', v: (i) => i.etapa || '' },
  { k: 'ult', t: 'Última atualização', v: (i) => dataIso(i.ultima_interacao) },
  { k: 'criado', t: 'Criado em', v: (i) => dataIso(i.abertura) },
  { k: 'autor', t: 'Atualizado por', v: (i) => i.ultimo_autor || '' },
  { k: 'solicitante', t: 'Solicitante', v: (i) => i.solicitante || '' },
  { k: 'titulo', t: 'Título', v: (i) => i.titulo || '' },
  { k: 'acao', t: 'Ação sugerida', v: (i) => i.pre_analise?.acao || '' },
  { k: 'dir', t: 'Direcionado', v: (i) => (i.direcionamento ? 0 : 1) },
  { k: 'sem', t: 'Dias úteis sem interação', v: (i) => i.dias_uteis_sem_interacao ?? -1, num: true },
  { k: 'aberto', t: 'Dias úteis desde a abertura', v: (i) => i.dias_uteis_abertura ?? -1, num: true },
]
function dataIso(br) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})(?: (\d{2}):(\d{2}))?/.exec(br || '')
  return m ? `${m[3]}-${m[2]}-${m[1]} ${m[4] || '00'}:${m[5] || '00'}` : ''
}
function clicarCol(c) {
  if (ordenar.value.col === c.k) ordenar.value.asc = !ordenar.value.asc
  else ordenar.value = { col: c.k, asc: !c.num && !['ult', 'criado'].includes(c.k) }
}
const listaTabela = computed(() => {
  const c = COLS.find((x) => x.k === ordenar.value.col)
  if (!c) return lista.value
  const f = ordenar.value.asc ? 1 : -1
  return [...lista.value].sort((a, b) => {
    const x = c.v(a), y = c.v(b)
    return (typeof x === 'number' ? x - y : String(x).localeCompare(String(y), 'pt-BR')) * f
  })
})
const cartoes = computed(() => {
  if (modo.value === 'cartoes') return lista.value
  const i = itens.value.find((x) => x.id === selecionado.value)
  return i ? [i] : []
})
const corDias = (n) => (n > 30 ? 'd30' : n >= 8 ? 'd8' : '')
function abrir(i) { selecionado.value = selecionado.value === i.id ? null : i.id }

// 11/11/2026: "Responder" das Dúvidas do Carregador abre o painel já posicionado nas perguntas
// (antes era preciso rolar o painel inteiro até elas; no modo Cartões o botão não abria nada).
const painelRef = ref(null)
function responderDuvidas(i) {
  modo.value = 'tabela'
  selecionado.value = i.id
  nextTick(() => {
    const el = painelRef.value?.querySelector('.duv')
    if (!el) return
    el.scrollIntoView({ block: 'start' })
    const t = [...el.querySelectorAll('textarea')].find((x) => !x.value) || el.querySelector('textarea')
    t?.focus({ preventScroll: true })
  })
}
// Com o painel aberto, a página de trás não rola: a roda do mouse e a barra de rolagem ficam só no painel.
watch(() => modo.value === 'tabela' && cartoes.value.length > 0, (aberto) => {
  document.body.style.overflow = aberto ? 'hidden' : ''
})
onUnmounted(() => { document.body.style.overflow = '' })

const novoRasc = (texto = '', acao = '', c = null, fila = '') =>
  ({ texto, acao, fila, formato: c?.formato || '', complementar: [...(c?.complementar || [])], postar: c ? c.postar !== false : true })

// ---- Reatribuir fila (12/11/2026): fila de destino escolhida da lista da PX; depois de aprovado, o Vigia transfere
const filasPx = ref([])
api.filas().then((r) => (filasPx.value = r.filas || [])).catch(() => {})
const semAc = (x) => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim()
function filaExata(nome) {
  const a = filasPx.value.filter((f) => semAc(f) === semAc(nome))
  return a.length === 1 ? a[0] : ''
}
function filaDaSugestao(txt) {
  const m = /fila\s+(?:de\s+|da\s+|do\s+)?([A-ZÀ-Úa-zà-ú0-9 ]{3,40}?)(?:\s*[—–(.,;:-]|$)/i.exec(txt || '')
  return m ? filaExata(m[1]) : ''
}
const faltaFila = (r) => r.acao === 'Reatribuir fila' && !filaExata(r.fila)

function rasc(i) {
  if (!rascunho.value[i.id]) {
    rascunho.value[i.id] = novoRasc()
  }
  return rascunho.value[i.id]
}

// ---- Carregador: formato (Layout SDI / PC Genérica) + layout complementar opcional
const FORMATOS = { sdi: 'Layout SDI', pc: 'PC Genérica' }
const enviandoCompl = ref({})
const faltaFormato = (r) => r.acao === 'Carregador' && !r.formato
function lerBase64(arq) {
  return new Promise((ok, falha) => {
    const fr = new FileReader()
    fr.onload = () => ok(String(fr.result).split(',')[1] || '')
    fr.onerror = () => falha(fr.error)
    fr.readAsDataURL(arq)
  })
}
async function enviarComplementar(i, ev) {
  const arqs = [...(ev.target.files || [])]
  ev.target.value = ''
  if (!arqs.length) return
  const r = rasc(i)
  enviandoCompl.value[i.id] = true
  try {
    for (const a of arqs) {
      const j = await api.complementar(i.id, a.name, await lerBase64(a))
      if (!r.complementar.includes(j.nome)) r.complementar.push(j.nome)
    }
  } catch (e) {
    emit('avisar', { texto: `Layout complementar não enviado: ${e.message}`, erro: true })
  } finally {
    enviandoCompl.value[i.id] = false
  }
}

function concordar(i) {
  const r = rasc(i)
  r.acao = i.pre_analise?.acao || ''
  if (!r.texto) r.texto = 'De acordo com a sugestão.'
  if (r.acao === 'Reatribuir fila' && !r.fila) r.fila = filaDaSugestao(i.pre_analise?.sugestao)
}

async function gravar(i, limpar = false) {
  const r = rasc(i)
  if (!limpar && !r.texto.trim() && !r.acao) return
  if (!limpar && faltaFila(r)) {
    emit('avisar', { texto: 'Reatribuir fila: escolha a fila de destino da lista.', erro: true })
    return
  }
  if (!limpar && faltaFormato(r)) {
    emit('avisar', { texto: 'Carregador: escolha o formato (Layout SDI ou PC Genérica).', erro: true })
    return
  }
  gravando.value[i.id] = true
  try {
    const carregador = !limpar && r.acao === 'Carregador'
      ? { formato: r.formato, complementar: r.complementar, postar: r.postar } : null
    await api.direcionar(i.id, limpar ? '' : r.texto, limpar ? '' : r.acao, carregador,
      !limpar && r.acao === 'Reatribuir fila' ? filaExata(r.fila) : null)
    rascunho.value[i.id] = novoRasc()
    await carregar()
    emit('avisar', { texto: limpar ? `${i.numero || i.protocolo}: direcionamento removido`
      : `${i.numero || i.protocolo}: direcionamento gravado — aguardando sua confirmação para executar` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível gravar: ${e.message}`, erro: true })
  } finally {
    gravando.value[i.id] = false
  }
}

// ---- aprovação em lote (11/11/2026): aprova a ação sugerida de todos os filtrados sem direcionamento
const LOTE_FORA = ['Carregador', 'Maninha']   // precisam de opções/arquivos: um a um
const loteCand = computed(() => lista.value.filter((i) => !i.direcionamento && i.pre_analise?.acao && !LOTE_FORA.includes(i.pre_analise.acao)))
const loteResumo = computed(() => {
  const c = {}
  for (const i of loteCand.value) c[i.pre_analise.acao] = (c[i.pre_analise.acao] || 0) + 1
  return Object.entries(c).sort((a, b) => b[1] - a[1])
})
const loteConfirma = ref(false)
const loteGravando = ref(false)
async function aprovarLote() {
  loteGravando.value = true
  try {
    const r = await api.lote(loteCand.value.map((i) => i.id))
    loteConfirma.value = false
    await carregar()
    emit('avisar', { texto: `${r.aprovados} aprovado(s) em lote${r.pulados ? ` · ${r.pulados} pulado(s) (já tinham direcionamento)` : ''}. As automáticas rodam no próximo Executor; "Reatribuir fila" vai para o painel laranja.` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível aprovar em lote: ${e.message}`, erro: true })
  } finally {
    loteGravando.value = false
  }
}

// ---- vários atendimentos marcados (12/11/2026): o mesmo direcionamento para todos
const marcados = ref({})
const nMarc = computed(() => Object.keys(marcados.value).length)
const todosMarc = computed(() => listaTabela.value.length > 0 && listaTabela.value.every((i) => marcados.value[i.id]))
function marcar(i) {
  const m = { ...marcados.value }
  m[i.id] ? delete m[i.id] : (m[i.id] = true)
  marcados.value = m
}
function marcarTodos() {
  const m = { ...marcados.value }
  if (todosMarc.value) listaTabela.value.forEach((i) => delete m[i.id])
  else listaTabela.value.forEach((i) => (m[i.id] = true))
  marcados.value = m
}
const ACOES_VARIOS = ACOES.filter((a) => a !== 'Carregador')
const varios = ref({ texto: '', acao: '', fila: '' })
const variosGravando = ref(false)
const faltaVarios = computed(() => (!varios.value.texto.trim() && !varios.value.acao) || faltaFila(varios.value))
async function gravarVarios(aprovarJa) {
  variosGravando.value = true
  try {
    const v = varios.value
    const r = await api.direcionarVarios(Object.keys(marcados.value).map(Number), v.texto, v.acao,
      v.acao === 'Reatribuir fila' ? filaExata(v.fila) : null, aprovarJa)
    marcados.value = {}
    varios.value = { texto: '', acao: '', fila: '' }
    await carregar()
    emit('avisar', { texto: `${r.gravados} direcionamento(s) ${aprovarJa ? 'gravado(s) e aprovado(s)' : 'gravado(s) — aguardando sua aprovação'}`
      + (r.pulados ? ` · ${r.pulados} pulado(s) (já aprovados ou enviados ao Vigia)` : '') })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível gravar: ${e.message}`, erro: true })
  } finally {
    variosGravando.value = false
  }
}

// ---- relatório para cobrança (13/11/2026): exporta os filtrados (ou só os marcados) para Excel e copia um resumo
function paraExportar() {
  const ids = Object.keys(marcados.value)
  const base = ids.length ? itens.value.filter((i) => marcados.value[i.id]) : lista.value
  return [...base].sort((a, b) => (b.dias_uteis_sem_interacao || 0) - (a.dias_uteis_sem_interacao || 0))
}
const nomeRel = () => {
  const r = responsavel.value.length === 1 ? responsavel.value[0] : responsavel.value.length ? 'varios' : 'todos'
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `Cobranca_${r.replace(/\s+/g, '_')}_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`
}
function exportarExcel() {
  const l = paraExportar()
  const cols = [
    ['Atendimento', (i) => i.numero], ['Protocolo', (i) => i.protocolo], ['Título', (i) => i.titulo],
    ['Responsável', (i) => i.responsavel], ['Solicitante', (i) => i.solicitante], ['Etapa', (i) => i.etapa],
    ['Tipo', (i) => i.tipo], ['Criado em', (i) => i.abertura], ['Última interação', (i) => i.ultima_interacao],
    ['Último a interagir', (i) => i.ultimo_autor], ['Dias úteis sem interação', (i) => i.dias_uteis_sem_interacao],
    ['Dias úteis em aberto', (i) => i.dias_uteis_abertura], ['Prioridade', (i) => i.pre_analise?.prioridade],
    ['Pedido', (i) => i.pre_analise?.pedido], ['Situação', (i) => i.pre_analise?.situacao],
    ['Próximo passo (sugestão)', (i) => i.pre_analise?.sugestao], ['Link', (i) => i.link],
  ]
  const esc = (v) => {
    const t = String(v ?? '').replace(/\r?\n/g, ' ')
    return /[";]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t
  }
  const linhas = [cols.map((c) => c[0]).join(';'), ...l.map((i) => cols.map((c) => esc(c[1](i))).join(';'))]
  const blob = new Blob(['\ufeff' + linhas.join('\r\n')], { type: 'text/csv;charset=utf-8' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = nomeRel() + '.csv'
  document.body.appendChild(a)
  a.click()
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove() }, 1000)
  emit('avisar', { texto: `${l.length} atendimento(s) exportado(s) — abra o arquivo no Excel (Downloads)` })
}
async function copiarResumo() {
  const l = paraExportar()
  const nome = responsavel.value.length === 1 ? responsavel.value[0].split(' ')[0] : ''
  const txt = [`${nome ? nome + ', ' : ''}segue a lista de ${l.length} atendimento(s) em aberto para retorno (ordenados pelo tempo sem interação):`, '']
    .concat(l.map((i) => `• ${i.numero || '#' + i.protocolo} (${i.protocolo}) – ${i.titulo} – ${i.etapa}, ${i.dias_uteis_sem_interacao} dia(s) útil(eis) sem interação`
      + (i.pre_analise?.sugestao ? `\n   Próximo passo: ${i.pre_analise.sugestao}` : '')))
    .concat(['', 'Por favor, atualizem os atendimentos ou me sinalizem o que está pendente.']).join('\n')
  try {
    await navigator.clipboard.writeText(txt)
    emit('avisar', { texto: 'Resumo copiado — cole no Teams ou no e-mail' })
  } catch (e) {
    emit('avisar', { texto: 'Não consegui copiar automaticamente: use o Exportar Excel', erro: true })
  }
}

const statusDe = (d) => {
  const st = String(d?.status || '')
  if (st.startsWith('executado') || st.startsWith('concluído')) return 'executado'
  if (st.startsWith('aprovado')) return 'aprovado'
  if (st.startsWith('enviado')) return 'enviado'   // pedido já na fila do Vigia: não dá para desfazer daqui
  return 'aguardando'
}
const corStatus = { executado: 'ok', aprovado: 'accent', enviado: 'accent', aguardando: 'warn' }

// ---- aprovados que pedem outra fila (o Odoo não deixa o usuário do Julio mudar a fila: ele faz à mão)
const RE_FILA = /\bfila\b|devolv|implanta[cç][aã]o|relacionamento|outra equipe/i
function pedeFila(i) {
  const d = i.direcionamento
  if (!d) return false
  const st = String(d.status || '')
  if (st.startsWith('aguardando') || st.startsWith('removido') || st.startsWith('concluído') || st.startsWith('aprendizado')) return false
  if (d.acao === 'Devolver ao solicitante') return true
  // 12/11/2026: com fila de destino, quem transfere é o Vigia -> fica só em 'Aprovados p/ executar'
  if (d.acao === 'Reatribuir fila') return !st.startsWith('executado') && !(d.fila_destino || filaDaSugestao(d.texto) || filaDaSugestao(d.sugestao_claude))
  if (d.acao === 'Repassar responsável') return false   // 11/11/2026: é para pessoa da MESMA fila (Executor delega); outra fila = 'Reatribuir fila'
  return RE_FILA.test(d.texto || '') && !st.startsWith('executado')
}
const paraFila = computed(() => itens.value.filter(pedeFila))
function filaSugerida(i) {
  const d = i.direcionamento || {}
  if (d.fila_destino) return d.fila_destino
  const m = /fila\s+(?:de\s+|da\s+|do\s+)?([A-ZÀ-Úa-zà-ú0-9 ]{3,40})/i.exec(d.texto || '')
  if (m) return m[1].trim()
  if (d.acao === 'Devolver ao solicitante') {
    const fs = (i.fila_solicitante || []).filter((f) => f !== 'Dados Operacionais' && f !== 'Sem fila')
    if (fs.includes('Implantação')) return 'Implantação (fila do solicitante)'
    return fs.length ? fs.slice(0, 3).join(' / ') + (fs.length > 3 ? ` +${fs.length - 3}` : '') : 'solicitante sem fila'
  }
  return '—'
}
const verFila = ref(true)

// ---- dúvidas do Carregador (Duvidas.txt da pasta Carga SDI): o Julio responde aqui e o item volta para execução
const comDuvidas = computed(() => itens.value.filter((i) => (i.duvidas || []).some((d) => d.pendentes > 0)))
const resp = ref({})   // `${id}|${pasta}` -> [respostas]
function respDe(i, d) {
  const k = `${i.id}|${d.pasta}`
  if (!resp.value[k]) resp.value[k] = d.perguntas.map((p) => p.resposta || '')
  return resp.value[k]
}
async function gravarRespostas(i, d) {
  const k = `${i.id}|${d.pasta}`
  gravando.value[k] = true
  try {
    await api.respostas(i.id, d.pasta, respDe(i, d))
    delete resp.value[k]
    await carregar()
    emit('avisar', { texto: `${i.numero || i.protocolo}: respostas gravadas — o Carregador roda de novo na próxima hora (:47)` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível: ${e.message}. Se for "rota inexistente", feche a janela preta e abra o iniciar.bat.`, erro: true })
  } finally {
    gravando.value[k] = false
  }
}
async function concluir(i) {
  gravando.value[i.id] = true
  try {
    await api.concluir(i.id, 'Reatribuído de fila pelo Julio no Odoo')
    await carregar()
    emit('avisar', { texto: `${i.numero || i.protocolo}: marcado como reatribuído` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível: ${e.message}. Feche a janela preta da Plataforma e abra o iniciar.bat de novo.`, erro: true })
  } finally {
    gravando.value[i.id] = false
  }
}

async function aprovar(i, sim = true) {
  gravando.value[i.id] = true
  try {
    await api.aprovar(i.id, sim)
    await carregar()
    emit('avisar', { texto: sim ? `${i.numero || i.protocolo}: execução aprovada — o Executor roda na próxima hora (:47)`
      : `${i.numero || i.protocolo}: aprovação desfeita` })
  } catch (e) {
    emit('avisar', { texto: `Não foi possível: ${e.message}`, erro: true })
  } finally {
    gravando.value[i.id] = false
  }
}

function novoDirecionamento(i) {
  // nova rodada no mesmo atendimento (o anterior fica no histórico/aprendizado)
  rascunho.value[i.id] = novoRasc('', i.direcionamento?.acao || '', i.direcionamento?.carregador, i.direcionamento?.fila_destino || '')
  i._editando = true
}

function editar(i) {
  rascunho.value[i.id] = novoRasc(i.direcionamento?.texto || '', i.direcionamento?.acao || '', i.direcionamento?.carregador, i.direcionamento?.fila_destino || '')
  i._editando = true
}

const corPrio = { Alta: 'danger', 'Média': 'warn', Baixa: '' }
const corTipo = { Carga: 'carga', Layout: 'layout', Sinistro: 'warn' }
const quando = (iso) => (iso ? new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '')

const esc = (e) => { if (e.key === 'Escape') selecionado.value = null }
onMounted(() => { carregar(); window.addEventListener('keydown', esc) })
onUnmounted(() => window.removeEventListener('keydown', esc))
defineExpose({ carregar })
</script>

<template>
  <section>
    <datalist id="filas-px"><option v-for="f in filasPx" :key="f" :value="f" /></datalist>
    <div class="topo card">
      <div>
        <b>Pré-análise da fila Dados Operacionais</b>
        <div class="muted">
          Gerada pelo Claude em {{ dados.gerado_em || '—' }} (dados do Odoo de {{ dados.coletado_em || '—' }}) ·
          {{ itens.length }} atendimentos · {{ pendentes }} sem direcionamento ·
          {{ dados.total_aprendizado }} direcionamento(s) já registrados para aprendizado
        </div>
      </div>
      <button class="btn" :disabled="carregando" @click="carregar">{{ carregando ? 'Lendo…' : '↻ Recarregar' }}</button>
    </div>

    <div class="filtros card">
      <div class="seg">
        <span class="modo" role="group" aria-label="Visão">
          <button :class="{ on: modo === 'tabela' }" @click="modo = 'tabela'" title="Visão compacta, como o relatório">☰ Compacta</button>
          <button :class="{ on: modo === 'cartoes' }" @click="modo = 'cartoes'" title="Visão com a pré-análise completa">▤ Cartões</button>
        </span>
        <button :class="{ on: situacao === 'pendentes' }" @click="situacao = 'pendentes'">Sem direcionamento</button>
        <button :class="{ on: situacao === 'direcionados' }" @click="situacao = 'direcionados'">Direcionados</button>
        <button :class="{ on: situacao === 'aprovados' }" @click="situacao = 'aprovados'">Aprovados p/ executar</button>
        <button :class="{ on: situacao === 'fila' }" @click="situacao = 'fila'">Reatribuir fila<span v-if="paraFila.length" class="cont-fila">{{ paraFila.length }}</span></button>
        <button :class="{ on: situacao === '' }" @click="situacao = ''">Todos</button>
      </div>
      <div class="linha">
        <input v-model="numero" class="num" type="search" inputmode="text" aria-label="Número do atendimento"
               placeholder="Nº do atendimento (HT, protocolo ou id)" />
        <input v-model="busca" type="search" placeholder="Buscar por cliente, solicitante, texto…" />
        <MultiFiltro v-model="prioridade" rotulo="Prioridade" todos="Toda prioridade" :opcoes="opcoesN((i) => i.pre_analise?.prioridade, ['Alta', 'Média', 'Baixa'])" />
        <MultiFiltro v-model="acao" rotulo="Ação" todos="Toda ação sugerida" :opcoes="opcoesN((i) => i.pre_analise?.acao)" />
        <MultiFiltro v-model="tipo" rotulo="Tipo" todos="Todo tipo" :opcoes="opcoesN((i) => i.tipo)" />
        <MultiFiltro v-model="etapa" rotulo="Etapa" todos="Toda etapa" :opcoes="opcoesN((i) => i.etapa)" />
        <MultiFiltro v-model="responsavel" rotulo="Responsável" todos="Todos os responsáveis" :opcoes="opcoesN((i) => i.responsavel)" />
        <MultiFiltro v-model="solicitante" rotulo="Solicitante" todos="Todos os solicitantes" :opcoes="opcoesN((i) => i.solicitante)" />
        <MultiFiltro v-model="filaSol" rotulo="Fila do solicitante" todos="Toda fila do solicitante" :opcoes="opcoesNLista((i) => i.fila_solicitante)" />
        <button v-if="algumFiltro || busca" type="button" class="btn limpar" @click="limparFiltros">✕ Limpar filtros</button>
      </div>
      <div v-if="lista.length" class="exportar">
        <b>Relatório para cobrança:</b>
        <button class="btn small" @click="exportarExcel">⬇ Exportar Excel ({{ nMarc || lista.length }})</button>
        <button class="btn small" @click="copiarResumo">Copiar resumo para Teams/e-mail</button>
        <span class="muted">{{ nMarc ? 'só os marcados' : 'todos os filtrados' }} · ordenado pelo tempo sem interação</span>
      </div>
      <div v-if="loteCand.length" class="lote">
        <template v-if="!loteConfirma">
          <button class="btn" @click="loteConfirma = true">✔ Aprovar a sugestão dos {{ loteCand.length }} filtrados sem direcionamento</button>
          <span class="muted">Use os filtros (ex.: Ação = Encerrar) para escolher o grupo. Carregador e Maninha ficam de fora.</span>
        </template>
        <template v-else>
          <span><b>Aprovar {{ loteCand.length }} atendimento(s)?</b>
            <span v-for="([a, n], k) in loteResumo" :key="a">{{ k ? ' · ' : ' ' }}{{ a }} {{ n }}</span></span>
          <button class="btn primary" :disabled="loteGravando" @click="aprovarLote">{{ loteGravando ? 'Aprovando…' : 'Confirmar' }}</button>
          <button class="btn" :disabled="loteGravando" @click="loteConfirma = false">Cancelar</button>
        </template>
      </div>
    </div>

    <div v-if="comDuvidas.length" class="card fila-box duv-box">
      <div class="fila-top">
        <b>Dúvidas do Carregador ({{ comDuvidas.length }})</b>
        <span class="muted">O Carregador parou por falta de informação. Clique no atendimento, responda e grave — ele roda de novo sozinho.</span>
      </div>
      <table class="fila-tab">
        <thead><tr><th>Atendimento</th><th>Protocolo</th><th>Título</th><th>Pendentes</th><th></th></tr></thead>
        <tbody>
          <tr v-for="i in comDuvidas" :key="i.id">
            <td class="nw"><a :href="i.link" target="_blank" rel="noopener">{{ i.numero || i.protocolo }}</a></td>
            <td class="nw">{{ i.protocolo }}</td>
            <td class="tt" :title="i.titulo">{{ i.titulo }}</td>
            <td>{{ i.duvidas.reduce((s, d) => s + d.pendentes, 0) }} pergunta(s)</td>
            <td class="nw"><button class="btn" @click="responderDuvidas(i)">Responder</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="paraFila.length" class="card fila-box">
      <div class="fila-top">
        <b>Reatribuir para outra fila ({{ paraFila.length }})</b>
        <span class="muted">Aprovados que pedem outra fila sem fila de destino definida (ex.: devolver ao solicitante) — faça no Odoo e marque aqui. Os de "Reatribuir fila" com fila escolhida o Vigia transfere sozinho.</span>
        <button class="link" @click="verFila = !verFila">{{ verFila ? 'ocultar' : 'mostrar' }}</button>
      </div>
      <table v-if="verFila" class="fila-tab">
        <thead><tr><th>Atendimento</th><th>Protocolo</th><th>Título</th><th>Solicitante</th><th>Atribuído a</th><th>Fila sugerida</th><th>Seu direcionamento</th><th></th></tr></thead>
        <tbody>
          <tr v-for="i in paraFila" :key="i.id">
            <td class="nw"><a :href="i.link" target="_blank" rel="noopener">{{ i.numero || i.protocolo }}</a></td>
            <td class="nw">{{ i.protocolo }}</td>
            <td class="tt" :title="i.titulo">{{ i.titulo }}</td>
            <td>{{ i.solicitante }}</td>
            <td>{{ i.responsavel }}</td>
            <td><b>{{ filaSugerida(i) }}</b></td>
            <td><span class="chip accent">{{ i.direcionamento.acao || '—' }}</span> {{ i.direcionamento.texto }}</td>
            <td class="nw"><button class="btn" :disabled="gravando[i.id]" @click="concluir(i)">✔ Já reatribuí</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="erro" class="card erro">Erro ao ler a pré-análise: {{ erro }}</div>
    <div v-else-if="!carregando && !itens.length" class="card vazio">
      Nenhuma pré-análise ainda. Peça ao Claude: "gera a pré-análise" — ele grava em _sistema\preanalise.json.
    </div>
    <div v-else-if="!lista.length" class="card vazio">
      {{ termosNumero.length ? `Nenhum atendimento aberto com o número "${numero}".` : 'Nenhum atendimento com esses filtros.' }}
    </div>
    <div v-else-if="termosNumero.length" class="muted aviso">
      {{ lista.length }} atendimento(s) encontrado(s) pelo número — os outros filtros estão ignorados enquanto este campo estiver preenchido.
    </div>

    <div v-if="modo === 'tabela' && lista.length" class="card tab-wrap">
      <table class="tab">
        <thead>
          <tr>
            <th class="ck" @click.stop><input type="checkbox" :checked="todosMarc" aria-label="Marcar todos os da lista" @change="marcarTodos" /></th>
            <th v-for="c in COLS" :key="c.k" :class="{ num: c.num, ord: ordenar.col === c.k }" @click="clicarCol(c)"
                :aria-sort="ordenar.col === c.k ? (ordenar.asc ? 'ascending' : 'descending') : 'none'">
              {{ c.t }}<span v-if="ordenar.col === c.k">{{ ordenar.asc ? ' ▲' : ' ▼' }}</span>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="i in listaTabela" :key="i.id" :class="{ sel: selecionado === i.id }" tabindex="0"
              @click="abrir(i)" @keydown.enter="abrir(i)" title="Clique para ver a pré-análise e direcionar">
            <td class="ck" @click.stop="marcar(i)"><input type="checkbox" :checked="!!marcados[i.id]" :aria-label="'Marcar ' + (i.numero || i.protocolo)" @click.stop="marcar(i)" /></td>
            <td><span class="chip" :class="corPrio[i.pre_analise?.prioridade]">{{ i.pre_analise?.prioridade }}</span></td>
            <td>{{ i.responsavel }}</td>
            <td><a :href="i.link" target="_blank" rel="noopener" @click.stop>{{ i.numero || '—' }}</a></td>
            <td>{{ i.protocolo }}</td>
            <td><span class="chip" :class="corTipo[i.tipo]">{{ i.tipo }}</span></td>
            <td>{{ i.etapa }}</td>
            <td class="nw">{{ i.ultima_interacao }}</td>
            <td class="nw">{{ i.abertura }}</td>
            <td>{{ i.ultimo_autor }}</td>
            <td>{{ i.solicitante }}</td>
            <td class="tt" :title="i.titulo">{{ i.titulo }}</td>
            <td class="nw">{{ i.pre_analise?.acao }}</td>
            <td class="c">
              <span v-if="i.direcionamento" class="chip" :class="corStatus[statusDe(i.direcionamento)]"
                    :title="i.direcionamento.status + ' — ' + (i.direcionamento.texto || '')">
                {{ { executado: '✓✓', aprovado: '✔', aguardando: '…' }[statusDe(i.direcionamento)] }} {{ i.direcionamento.acao || 'sim' }}
              </span>
              <span v-else class="muted">—</span>
            </td>
            <td class="num" :class="corDias(i.dias_uteis_sem_interacao)">{{ i.dias_uteis_sem_interacao }}</td>
            <td class="num" :class="corDias(i.dias_uteis_abertura)">{{ i.dias_uteis_abertura }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="nMarc && modo === 'tabela'" class="barra-varios card">
      <b>{{ nMarc }} marcado(s)</b>
      <input v-model="varios.texto" class="vt" placeholder="Direcionamento para todos (ex.: encerrar, são só avisos)" />
      <select v-model="varios.acao" aria-label="Ação para os marcados">
        <option value="">Ação (opcional)</option>
        <option v-for="a in ACOES_VARIOS" :key="a">{{ a }}</option>
      </select>
      <input v-if="varios.acao === 'Reatribuir fila'" v-model="varios.fila" list="filas-px" class="fila-in"
             :class="{ ruim: varios.fila && !filaExata(varios.fila) }" placeholder="Fila de destino" aria-label="Fila de destino" />
      <button class="btn" :disabled="variosGravando || faltaVarios" @click="gravarVarios(false)">Gravar</button>
      <button class="btn primary" :disabled="variosGravando || faltaVarios" @click="gravarVarios(true)">Gravar e aprovar</button>
      <button class="btn" :disabled="variosGravando" @click="marcados = {}">Desmarcar</button>
    </div>
    <div v-if="modo === 'tabela' && cartoes.length" class="fundo" @click="selecionado = null"></div>
    <aside v-if="cartoes.length" ref="painelRef" :class="{ painel: modo === 'tabela' }">
      <div v-if="modo === 'tabela'" class="painel-topo">
        <b>Pré-análise</b>
        <button class="fechar" aria-label="Fechar" @click="selecionado = null">×</button>
      </div>
    <article v-for="i in cartoes" :key="i.id" class="card item">
      <header>
        <div class="tit">
          <a :href="i.link" target="_blank" rel="noopener">{{ i.numero || '#' + i.protocolo }}</a>
          <span class="muted">({{ i.protocolo }})</span>
          <span class="nome">{{ i.titulo }}</span>
        </div>
        <div class="chips">
          <span class="chip" :class="corPrio[i.pre_analise?.prioridade]">{{ i.pre_analise?.prioridade }}</span>
          <span class="chip" :class="corTipo[i.tipo]">{{ i.tipo }}</span>
          <span class="chip">{{ i.responsavel }}</span>
          <span class="chip" :class="i.dias_uteis_abertura > 30 ? 'danger' : i.dias_uteis_abertura > 7 ? 'warn' : ''"
                title="Dias úteis desde a abertura">{{ i.dias_uteis_abertura }} du aberto</span>
          <span class="chip" :class="i.dias_uteis_sem_interacao > 7 ? 'warn' : ''"
                title="Dias úteis sem interação">{{ i.dias_uteis_sem_interacao }} du sem interação</span>
        </div>
      </header>
      <div class="meta muted">
        Solicitante: <b>{{ i.solicitante || '—' }}</b>
        <span v-if="i.fila_solicitante?.length" :title="i.fila_solicitante.join(', ')"> (fila{{ i.fila_solicitante.length > 1 ? 's' : '' }}: {{ i.fila_solicitante.slice(0, 3).join(', ') }}{{ i.fila_solicitante.length > 3 ? ` +${i.fila_solicitante.length - 3}` : '' }})</span> · Etapa: {{ i.etapa }} · Aberto em {{ i.abertura }} ·
        Última interação {{ i.ultima_interacao }}<span v-if="i.ultimo_autor"> ({{ i.ultimo_autor }})</span>
        <span v-if="i.contrato"> · Contrato {{ i.contrato }}</span>
      </div>

      <dl class="pa">
        <dt>Pedido</dt><dd>{{ i.pre_analise?.pedido }}</dd>
        <dt>Situação</dt><dd>{{ i.pre_analise?.situacao }}</dd>
        <dt>Sugestão do Claude</dt>
        <dd><span class="chip accent">{{ i.pre_analise?.acao }}</span> {{ i.pre_analise?.sugestao }}</dd>
        <template v-if="i.anexos?.length">
          <dt>Anexos</dt><dd class="muted">{{ i.anexos.map((a) => `${a.nome} (${a.data})`).join(' · ') }}</dd>
        </template>
        <template v-if="i.dados_contrato">
          <dt>Contrato (carga sem arquivo)</dt>
          <dd v-if="i.dados_contrato.erro" class="muted">{{ i.dados_contrato.erro }}</dd>
          <dd v-else class="dc">
            <div><b>{{ i.dados_contrato.contrato }}</b> · Apólice {{ i.dados_contrato.apolice || '—' }} · {{ i.dados_contrato.operadora }}
              <span v-if="i.dados_contrato.identificado_pelo_texto || i.dados_contrato.identificado_pelo_nome" class="chip warn">confira o contrato</span>
              <span v-if="i.dados_contrato.status_ok === false" class="chip danger">contrato {{ i.dados_contrato.status }} — não está Ativo nem Em Implantação</span>
              <span v-else-if="i.dados_contrato.status" class="chip ok">{{ i.dados_contrato.status }}</span></div>
            <div class="dc-t">Subempresas ativas/em implantação ({{ i.dados_contrato.subcontratos.length }}<template v-if="i.dados_contrato.subcontratos_ignorados?.length"> · {{ i.dados_contrato.subcontratos_ignorados.length }} fechada(s) ocultada(s)</template>)</div>
            <ul v-if="i.dados_contrato.subcontratos.length"><li v-for="sc in i.dados_contrato.subcontratos" :key="sc.nome"><b>{{ sc.codigo || '—' }}</b> · {{ sc.razao_social || sc.nome }} · {{ sc.cnpj }} · {{ sc.status }}</li></ul>
            <div v-else class="muted">nenhuma</div>
            <div class="dc-t">Planos</div>
            <ul v-if="i.dados_contrato.planos.length"><li v-for="(p, k) in i.dados_contrato.planos" :key="k"><b>{{ p.codigo_plano || p.codigo }}</b> · {{ p.nome }} · {{ p.acomodacao }}</li></ul>
            <div v-else class="muted">nenhum</div>
            <div class="dc-t">Acessos</div>
            <ul v-if="i.dados_contrato.portais.length"><li v-for="pa in i.dados_contrato.portais" :key="pa.codigo">
              <b>{{ pa.portal }}</b> · Entrar: {{ pa.login }} ·
              <a :href="pa.site.startsWith('http') ? pa.site : 'https://' + pa.site" target="_blank" rel="noopener">site</a> ·
              <a :href="pa.link" target="_blank" rel="noopener">senha no Odoo</a></li></ul>
            <div v-else-if="i.dados_contrato.identificado_pelo_texto || i.dados_contrato.identificado_pelo_nome" class="chip warn">Sem acesso cadastrado — mas o contrato foi deduzido do título; vincule o contrato no atendimento para eu postar a nota</div>
            <div v-else class="chip warn">Sem acesso cadastrado no contrato — ao executar, posto nota interna marcando o solicitante</div>
          </dd>
        </template>
      </dl>

      <div v-for="d in (i.duvidas || [])" :key="d.pasta" class="duv">
        <b>Dúvidas do Carregador</b> <span class="muted">— Carga SDI\{{ d.pasta }}\Arquivo Final\Duvidas.txt</span>
        <div v-for="(p, k) in d.perguntas" :key="k" class="duv-q">
          <div class="duv-p">{{ k + 1 }}. {{ p.pergunta }}</div>
          <textarea v-model="respDe(i, d)[k]" rows="2" placeholder="Sua resposta…"></textarea>
        </div>
        <button class="btn small primary" :disabled="gravando[`${i.id}|${d.pasta}`] || !respDe(i, d).some((r) => r && r.trim())"
                @click="gravarRespostas(i, d)">{{ gravando[`${i.id}|${d.pasta}`] ? 'Gravando…' : 'Gravar respostas e reenviar ao Carregador' }}</button>
      </div>

      <button class="link" @click="aberto[i.id] = !aberto[i.id]">
        {{ aberto[i.id] ? '▾ Esconder interações' : `▸ Ver últimas interações (${i.mensagens?.length || 0})` }}
      </button>
      <ul v-if="aberto[i.id]" class="msgs">
        <li v-for="(m, k) in i.mensagens" :key="k"><b>{{ m.data }} · {{ m.autor }}</b><div>{{ m.texto }}</div></li>
      </ul>

      <div v-if="i.direcionamento && !i._editando" class="dir ok">
        <div>
          <b>Seu direcionamento</b> <span class="muted">({{ quando(i.direcionamento.quando) }})</span>
          <span v-if="i.direcionamento.acao" class="chip ok">{{ i.direcionamento.acao }}</span>
          <template v-if="i.direcionamento.carregador">
            <span class="chip">{{ FORMATOS[i.direcionamento.carregador.formato] || i.direcionamento.carregador.formato }}</span>
            <span v-for="c in i.direcionamento.carregador.complementar" :key="c" class="chip" title="Layout complementar">＋ {{ c }}</span>
            <span class="chip" :class="i.direcionamento.carregador.postar ? '' : 'warn'">
              {{ i.direcionamento.carregador.postar ? 'posta ao solicitante' : 'não posta (só pasta)' }}</span>
          </template>
          <span v-if="i.direcionamento.fila_destino" class="chip">→ fila {{ i.direcionamento.fila_destino }}</span>
          <span class="chip" :class="corStatus[statusDe(i.direcionamento)]">{{ i.direcionamento.status }}</span>
          <div class="txt">{{ i.direcionamento.texto }}</div>
          <div v-if="i.direcionamento.execucao" class="muted exec">↳ {{ i.direcionamento.execucao }}</div>
        </div>
        <div class="acoes">
          <template v-if="statusDe(i.direcionamento) === 'aguardando'">
            <button class="btn small primary" :disabled="gravando[i.id]" @click="aprovar(i)">✔ Aprovar execução</button>
            <button class="btn small" @click="editar(i)">Editar</button>
            <button class="btn small" :disabled="gravando[i.id]" @click="gravar(i, true)">Remover</button>
          </template>
          <button v-else-if="statusDe(i.direcionamento) === 'aprovado'" class="btn small" :disabled="gravando[i.id]"
                  @click="aprovar(i, false)">Desfazer aprovação</button>
          <button v-if="(statusDe(i.direcionamento) !== 'aguardando' && statusDe(i.direcionamento) !== 'enviado') || /^falhou/.test(i.direcionamento.status || '')"
                  class="btn small" title="Ex.: o solicitante mandou um arquivo novo e o Maninha precisa rodar de novo"
                  @click="novoDirecionamento(i)">+ Novo direcionamento</button>
        </div>
      </div>
      <div v-else class="dir">
        <label :for="'d' + i.id"><b>Seu direcionamento</b></label>
        <textarea :id="'d' + i.id" v-model="rasc(i).texto" rows="2"
                  placeholder="Ex.: concordo; ou: não é com a gente, devolver para o Relacionamento; ou: priorizar hoje…"></textarea>
        <div class="linha">
          <select v-model="rasc(i).acao" aria-label="Ação">
            <option value="">Ação (opcional)</option>
            <option v-for="a in ACOES" :key="a">{{ a }}</option>
          </select>
          <template v-if="rasc(i).acao === 'Reatribuir fila'">
            <input v-model="rasc(i).fila" list="filas-px" class="fila-in" placeholder="Fila de destino (ex.: Faturamento)"
                   aria-label="Fila de destino" :class="{ ruim: rasc(i).fila && !filaExata(rasc(i).fila) }" />
          </template>
          <button class="btn small" @click="concordar(i)">Concordo com a sugestão</button>
          <button class="btn small primary" :disabled="gravando[i.id] || enviandoCompl[i.id] || faltaFormato(rasc(i)) || faltaFila(rasc(i)) || (!rasc(i).texto.trim() && !rasc(i).acao)" @click="gravar(i)">
            {{ gravando[i.id] ? 'Gravando…' : 'Gravar direcionamento' }}
          </button>
          <button v-if="i._editando" class="btn small" @click="i._editando = false">Cancelar</button>
        </div>
        <div v-if="rasc(i).acao === 'Carregador'" class="carreg">
          <div class="carreg-l">
            <b>Formato do arquivo final</b>
            <label v-for="(nome, k) in FORMATOS" :key="k" class="radio">
              <input type="radio" :name="'fmt' + i.id" :value="k" v-model="rasc(i).formato" /> {{ nome }}
            </label>
            <span v-if="!rasc(i).formato" class="chip warn">escolha um</span>
          </div>
          <div class="carreg-l">
            <b>Layout complementar</b> <span class="muted">(opcional — base para completar CPF, nascimento, parentesco…)</span>
          </div>
          <div class="carreg-l">
            <span v-for="(c, k) in rasc(i).complementar" :key="c" class="chip">
              {{ c }} <button class="x" title="Não usar este arquivo" @click="rasc(i).complementar.splice(k, 1)">×</button>
            </span>
            <label class="btn small">
              {{ enviandoCompl[i.id] ? 'Enviando…' : '+ Escolher arquivo' }}
              <input type="file" multiple accept=".xlsx,.xlsm,.xls,.csv,.txt" hidden :disabled="enviandoCompl[i.id]"
                     @change="enviarComplementar(i, $event)" />
            </label>
          </div>
          <label class="carreg-l radio">
            <input type="checkbox" v-model="rasc(i).postar" /> Postar o arquivo final ao solicitante (nota interna com @menção)
          </label>
        </div>
      </div>
    </article>
    </aside>
  </section>
</template>

<style scoped>
.topo { display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 12px 16px; margin-bottom: 12px; }
.filtros { padding: 12px 16px; margin-bottom: 12px; display: grid; gap: 10px; }
.seg { display: flex; gap: 6px; flex-wrap: wrap; }
.seg button { border: 1px solid var(--border); background: var(--surface); border-radius: 999px; padding: 4px 12px; cursor: pointer; }
.seg button.on { background: var(--accent); border-color: var(--accent); color: #fff; }
.linha { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.linha input { flex: 1 1 260px; min-width: 0; }
.linha input.num { flex: 0 1 260px; }
.linha .mf { flex: 0 1 210px; }
.dc ul { margin: 2px 0 6px; padding-left: 18px; }
.dc li { margin: 1px 0; overflow-wrap: anywhere; }
.dc .chip { white-space: normal; }
.fila-box.duv-box { border-left-color: #7c3aed; }
.duv { margin: 10px 0; padding: 10px 12px; border: 1px solid #ddd6fe; background: #f5f3ff; border-radius: 8px; }
.duv-q { margin: 8px 0; }
.duv-p { white-space: pre-wrap; margin-bottom: 4px; }
.duv textarea { width: 100%; box-sizing: border-box; font: inherit; padding: 6px 8px; border: 1px solid #c4b5fd; border-radius: 6px; }
.fila-box { padding: 12px 16px; margin-bottom: 12px; border-left: 4px solid #d97706; }
.fila-top { display: flex; gap: 12px; align-items: baseline; flex-wrap: wrap; }
.fila-tab { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 13px; }
.fila-tab th { text-align: left; color: var(--muted); font-weight: 600; padding: 4px 6px; border-bottom: 1px solid #e5e7eb; }
.fila-tab td { padding: 5px 6px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
.fila-tab .tt { max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cont-fila { margin-left: 6px; background: #d97706; color: #fff; border-radius: 9px; padding: 0 6px; font-size: 12px; }
.dc-t { margin-top: 6px; font-weight: 600; font-size: 13px; }
.linha .limpar { white-space: nowrap; }
.fila-in { min-width: 220px; }
.tab th.ck, .tab td.ck { width: 34px; text-align: center; padding-left: 6px; padding-right: 6px; cursor: default; }
.tab td.ck input, .tab th.ck input { width: 16px; height: 16px; cursor: pointer; padding: 0; }
.barra-varios { position: sticky; bottom: 12px; z-index: 5; margin-top: 10px; padding: 10px 14px; display: flex; gap: 8px;
  flex-wrap: wrap; align-items: center; border: 2px solid var(--accent); box-shadow: 0 8px 24px rgba(0,0,0,.15); }
.barra-varios .vt { flex: 1 1 280px; min-width: 0; }
.fila-in.ruim { border-color: var(--danger); }
.exportar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; padding-top: 8px; border-top: 1px dashed var(--border); font-size: 13px; }
.lote { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; padding-top: 8px; border-top: 1px dashed var(--border); font-size: 13px; }
.aviso { margin: 0 4px 10px; font-size: 13px; }
input, select, textarea { border: 1px solid var(--border); background: var(--surface); border-radius: 8px; padding: 6px 10px; }
.item { padding: 14px 16px; margin-bottom: 10px; }
header { display: flex; justify-content: space-between; gap: 10px; flex-wrap: wrap; }
.tit { display: flex; gap: 6px; align-items: baseline; flex-wrap: wrap; min-width: 0; }
.tit a { font-weight: 700; }
.nome { font-weight: 600; }
.chips { display: flex; gap: 4px; flex-wrap: wrap; }
.meta { font-size: 13px; margin-top: 4px; }
.pa { display: grid; grid-template-columns: 150px 1fr; gap: 4px 12px; margin: 10px 0 6px; }
.pa dt { color: var(--muted); font-weight: 600; }
.pa dd { margin: 0; min-width: 0; overflow-wrap: anywhere; }
.link { background: none; border: 0; color: var(--accent); cursor: pointer; padding: 0; font-size: 13px; }
.msgs { list-style: none; padding: 0; margin: 8px 0; display: grid; gap: 6px; }
.msgs li { background: var(--surface-2); border-radius: 8px; padding: 6px 10px; font-size: 13px; }
.dir { margin-top: 10px; padding: 10px; border-radius: 8px; background: var(--surface-2); display: grid; gap: 6px; }
.dir.ok { display: flex; justify-content: space-between; gap: 10px; background: var(--ok-soft); }
.dir textarea { width: 100%; resize: vertical; }
.dir .txt { margin-top: 4px; white-space: pre-wrap; }
.dir .exec { margin-top: 4px; font-size: 13px; }
.acoes { flex-wrap: wrap; justify-content: flex-end; }
.acoes { display: flex; gap: 6px; align-items: flex-start; }
.carreg { margin-top: 8px; padding: 8px 10px; border: 1px dashed var(--border); border-radius: 6px; display: flex; flex-direction: column; gap: 6px; }
.carreg-l { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.carreg input[type=radio], .carreg input[type=checkbox] { padding: 0; margin: 0; }
.carreg .radio { display: inline-flex; gap: 4px; align-items: center; cursor: pointer; }
.carreg .x { border: 0; background: none; cursor: pointer; padding: 0 0 0 4px; font-size: 1em; line-height: 1; }
.modo { display: inline-flex; border: 1px solid var(--border); border-radius: 999px; overflow: hidden; margin-right: 6px; }
.modo button { border: 0; border-radius: 0; padding: 4px 12px; background: var(--surface); cursor: pointer; }
.modo button.on { background: var(--text); color: var(--bg); }
.tab-wrap { overflow: auto; max-height: calc(100vh - 290px); padding: 0; }
.tab { width: 100%; border-collapse: collapse; font-size: 13px; }
.tab th { position: sticky; top: 0; z-index: 1; background: #1f4e78; color: #fff; text-align: left; font-weight: 600;
  padding: 7px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.tab th.num { text-align: right; white-space: normal; min-width: 96px; line-height: 1.2; }
.tab td { padding: 4px 8px; border-bottom: 1px solid var(--border); vertical-align: middle; white-space: nowrap; }
.tab tbody tr:nth-child(even) td { background: var(--surface-2); }
.tab tbody tr { cursor: pointer; }
.tab tbody tr:hover td, .tab tbody tr.sel td { background: var(--accent-soft); }
.tab tbody tr:focus-visible { outline: 2px solid var(--accent); outline-offset: -2px; }
.tab td.num { text-align: right; font-variant-numeric: tabular-nums; font-weight: 600; }
.tab td.d8 { background: #ffe699 !important; color: #5c4400; }
.tab td.d30 { background: #f8cbad !important; color: #6b2108; }
.tab td.tt { max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tab td.nw { white-space: nowrap; }
.tab td.c { text-align: center; }
.fundo { position: fixed; inset: 0; background: rgba(0, 0, 0, .25); z-index: 20; }
.painel { position: fixed; top: 0; right: 0; bottom: 0; width: min(640px, 100%); z-index: 21; overflow-y: scroll; overflow-x: hidden;
  overscroll-behavior: contain; scrollbar-gutter: stable; scrollbar-width: auto; scrollbar-color: #9aa2b1 transparent;
  background: var(--bg); padding: 0 14px 20px; box-shadow: -8px 0 24px rgba(0, 0, 0, .18); }
.painel-topo { position: sticky; top: 0; display: flex; justify-content: space-between; align-items: center;
  padding: 12px 2px; background: var(--bg); z-index: 1; }
.painel .item { margin-bottom: 0; }
.painel::-webkit-scrollbar { width: 14px; }
.painel::-webkit-scrollbar-thumb { background: #9aa2b1; border-radius: 8px; border: 3px solid var(--bg); }
.painel::-webkit-scrollbar-thumb:hover { background: #6b7280; }
.painel .duv { scroll-margin-top: 56px; }
.fechar { background: none; border: 0; font-size: 22px; cursor: pointer; color: var(--muted); }
.erro { padding: 12px 16px; border-color: var(--danger); color: var(--danger); }
@media (max-width: 640px) {
  .pa { grid-template-columns: 1fr; }
  .dir.ok { flex-direction: column; }
}
</style>
