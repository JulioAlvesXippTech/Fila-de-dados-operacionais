<script setup>
import { ref, computed, watch } from 'vue'
import { TIPOS, OPCOES, diasDesde } from '../api.js'

const props = defineProps({ caso: Object, situacao: String })
const emit = defineEmits(['responder'])

const aberto = ref(false)
const opcao = ref('')
const obs = ref('')
const salvando = ref(false)

const c = computed(() => props.caso)
const dias = computed(() => diasDesde(c.value.aberto_iso))
const idadeCls = computed(() => (dias.value == null ? '' : dias.value >= 15 ? 'danger' : dias.value >= 5 ? 'warn' : 'ok'))

const situacaoChip = computed(() => {
  switch (props.situacao) {
    case 'fechado': return { t: 'Fora do filtro / fechado', cls: '' }
    case 'automatico': return { t: `Automático → ${c.value.encaminhado?.destino}`, cls: 'accent' }
    case 'respondido': return { t: `Respondido: ${c.value.decisao || c.value.resposta}`, cls: 'ok' }
    default: return { t: 'Aguardando sua resposta', cls: 'warn' }
  }
})

watch(aberto, (v) => {
  if (v) {
    const r = c.value.resposta || ''
    const m = r.match(/^\s*([123])\b\s*[-–]?\s*(.*)$/)
    if (m) {
      opcao.value = m[1]
      obs.value = m[2].replace(/^(Maninha|Carregador do futuro|Sem a[çc][ãa]o)\s*/i, '')
    } else if (/^ok\b/i.test(r)) {
      opcao.value = 'ok'
      obs.value = r.replace(/^ok\s*/i, '')
    } else {
      opcao.value = ''
      obs.value = r
    }
  }
})

const resposta = computed(() => {
  const o = obs.value.trim()
  if (opcao.value === 'ok') return ('ok ' + o).trim()
  if (opcao.value) return `${opcao.value} - ${OPCOES[opcao.value]}${o ? ' ' + o : ''}`
  return o
})

function salvar() {
  salvando.value = true
  emit('responder', { caso: c.value, resposta: resposta.value, anterior: c.value.resposta })
  setTimeout(() => (salvando.value = false), 800)
}

function rapido(op) {
  opcao.value = op
  obs.value = ''
  salvar()
}
</script>

<template>
  <article class="card caso" :class="c.tipo">
    <div class="cab" @click="aberto = !aberto">
      <div class="idade" :class="idadeCls" :title="`Aberto em ${c.aberto_em}`">
        <b>{{ dias ?? '—' }}</b><small>{{ dias === 1 ? 'dia' : 'dias' }}</small>
      </div>
      <div class="info">
        <div class="l1">
          <span class="chip" :class="c.tipo">{{ TIPOS[c.tipo].rotulo }}</span>
          <a :href="c.link" target="_blank" rel="noopener" class="ht" @click.stop>{{ c.chave }}</a>
          <span class="muted">#{{ c.protocolo }}</span>
          <span v-if="c.marca" class="chip accent">{{ c.marca }}</span>
          <span class="chip" :class="situacaoChip.cls">{{ situacaoChip.t }}</span>
        </div>
        <h3>{{ c.titulo }}</h3>
        <div class="l3 muted">
          <span>Aberto em {{ c.aberto_em || '—' }}</span>
          <span>Solicitante: {{ c.solicitante || '—' }}</span>
          <span>Responsável: {{ c.responsavel || '—' }}</span>
          <span>Status: {{ c.status || '—' }}</span>
          <span v-if="c.contrato?.Operadora">{{ c.contrato.Operadora.split(' - ')[0] }}</span>
        </div>
      </div>
      <div class="acoes" @click.stop>
        <template v-if="situacao === 'pendente'">
          <button v-if="c.sugestao" class="btn small primary" :title="c.sugestao_txt" @click="rapido('ok')">
            OK: {{ OPCOES[c.sugestao] }}
          </button>
        </template>
        <button class="btn small" :aria-expanded="aberto" @click="aberto = !aberto">{{ aberto ? 'Fechar' : 'Abrir' }}</button>
      </div>
    </div>

    <div v-if="aberto" class="corpo">
      <div class="col">
        <h4>O que foi solicitado</h4>
        <p>{{ c.resumo || '—' }}</p>

        <template v-if="c.contrato?.Contrato">
          <h4>Contrato <span v-if="c.contrato_pelo_texto" class="chip warn">identificado pelo texto — confira</span></h4>
          <dl>
            <template v-for="k in ['Contrato', 'Operadora', 'Benefício', 'Status', 'CNPJ', 'Vidas', 'Grupo financeiro', 'Início']" :key="k">
              <template v-if="c.contrato[k]"><dt>{{ k }}</dt><dd>{{ c.contrato[k] }}</dd></template>
            </template>
          </dl>
          <details v-if="c.planos.length">
            <summary>{{ c.planos.length }} plano(s)</summary>
            <ul><li v-for="(p, i) in c.planos" :key="i">{{ p }}</li></ul>
          </details>
          <details v-if="c.portais.length">
            <summary>{{ c.portais.length }} portal(is) da operadora</summary>
            <ul><li v-for="(p, i) in c.portais" :key="i">{{ p }}</li></ul>
          </details>
        </template>

        <h4>Arquivos</h4>
        <ul v-if="c.arquivos.length" class="arqs"><li v-for="(a, i) in c.arquivos" :key="i">{{ a }}</li></ul>
        <p v-else class="muted">Nenhum arquivo anexado (fora imagens de assinatura).</p>

        <p v-if="c.encaminhado" class="muted enc">
          Encaminhado ({{ c.encaminhado.automatico ? 'automático' : 'pela sua resposta' }}) em {{ c.encaminhado.data }}
          → <b>{{ c.encaminhado.destino }}</b><span v-if="c.encaminhado.pasta"> · {{ c.encaminhado.pasta }}</span>
          <span v-if="c.encaminhado.status"> · {{ c.encaminhado.status }}</span>
        </p>
        <p class="muted fonte">Fonte: {{ c.txt }}<span v-if="c.txts.length > 1"> · aparece em {{ c.txts.length }} TXT</span></p>
      </div>

      <div class="col resp">
        <div v-if="c.sugestao" class="sug">
          <span class="muted">Sugestão do Claude</span>
          <b>{{ c.sugestao }} - {{ OPCOES[c.sugestao] }}</b>
          <span>{{ c.sugestao_txt.replace(/^[^-]*-\s*/, '') }}</span>
        </div>
        <h4>Sua orientação (linha R:)</h4>
        <div class="ops">
          <button v-for="(n, k) in OPCOES" :key="k" class="op" :class="{ on: opcao === k }" @click="opcao = opcao === k ? '' : k">
            <b>{{ k }}</b> {{ n }}
          </button>
          <button v-if="c.sugestao" class="op" :class="{ on: opcao === 'ok' }" @click="opcao = opcao === 'ok' ? '' : 'ok'">
            <b>ok</b> aceitar sugestão
          </button>
        </div>
        <textarea v-model="obs" rows="3"
          :placeholder="opcao ? 'Observação opcional (ex.: nome do anexo a usar)' : 'Ou escreva uma orientação livre (vira Outro)'"></textarea>
        <div class="prev muted">Vai gravar: <code>R: {{ resposta || '(vazio)' }}</code></div>
        <div class="botoes">
          <button v-if="c.resposta" class="btn small" :disabled="salvando" @click="opcao = ''; obs = ''; salvar()">Apagar resposta</button>
          <button class="btn primary" :disabled="salvando || !resposta || resposta === c.resposta" @click="salvar">
            Gravar no TXT
          </button>
        </div>
      </div>
    </div>
  </article>
</template>

<style scoped>
.caso { border-left: 4px solid var(--outros); overflow: hidden; }
.caso.carga { border-left-color: var(--carga); }
.caso.layout { border-left-color: var(--layout); }
.cab { display: flex; gap: 14px; padding: 12px 14px; cursor: pointer; align-items: flex-start; }
.idade {
  flex: none; width: 52px; text-align: center; border-radius: 8px; padding: 6px 0;
  background: var(--surface-2); display: grid; line-height: 1.1;
}
.idade b { font-size: 18px; }
.idade small { font-size: 11px; color: var(--muted); }
.idade.warn { background: var(--warn-soft); color: var(--warn); }
.idade.danger { background: var(--danger-soft); color: var(--danger); }
.idade.ok { background: var(--ok-soft); color: var(--ok); }
.info { flex: 1; min-width: 0; }
.l1 { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.ht { font-weight: 700; text-decoration: none; }
h3 { margin: 4px 0; font-size: 15px; font-weight: 600; overflow-wrap: anywhere; }
.l3 { display: flex; flex-wrap: wrap; gap: 4px 14px; font-size: 12.5px; }
.acoes { display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; flex: none; }
.corpo {
  display: grid; grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr); gap: 20px;
  border-top: 1px solid var(--border); padding: 14px; background: var(--surface-2);
}
h4 { margin: 12px 0 4px; font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); }
.col > h4:first-child { margin-top: 0; }
p { margin: 0 0 6px; }
dl { display: grid; grid-template-columns: max-content 1fr; gap: 2px 12px; margin: 0; font-size: 13px; }
dt { color: var(--muted); }
dd { margin: 0; overflow-wrap: anywhere; }
details { margin-top: 6px; font-size: 13px; }
summary { cursor: pointer; color: var(--accent); }
ul { margin: 4px 0; padding-left: 18px; }
.arqs { font-size: 13px; }
.enc, .fonte { font-size: 12.5px; margin-top: 10px; }
.resp { display: flex; flex-direction: column; gap: 8px; }
.sug {
  display: grid; gap: 2px; background: var(--surface); border: 1px dashed var(--border);
  border-radius: 8px; padding: 8px 10px; font-size: 13px;
}
.resp h4 { margin: 4px 0 0; }
.ops { display: flex; flex-wrap: wrap; gap: 6px; }
.op {
  border: 1px solid var(--border); background: var(--surface); border-radius: 8px; padding: 6px 10px; cursor: pointer;
}
.op.on { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); }
textarea {
  width: 100%; border: 1px solid var(--border); border-radius: 8px; padding: 8px; background: var(--surface); resize: vertical;
}
.prev { font-size: 12.5px; overflow-wrap: anywhere; }
.botoes { display: flex; gap: 8px; justify-content: flex-end; }
@media (max-width: 820px) {
  .corpo { grid-template-columns: 1fr; }
  .cab { flex-wrap: wrap; }
  .acoes { width: 100%; justify-content: flex-start; }
}
</style>
