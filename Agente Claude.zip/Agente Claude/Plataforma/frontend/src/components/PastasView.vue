<script setup>
import { ref, computed, onMounted } from 'vue'
import { api } from '../api.js'

const pastas = ref([])
const erro = ref('')
const carregando = ref(true)
const raiz = ref('todas')
const sit = ref('')
const busca = ref('')

onMounted(async () => {
  try {
    pastas.value = (await api.pastas()).pastas
  } catch (e) {
    erro.value = e.message
  } finally {
    carregando.value = false
  }
})

const situacoes = computed(() => [...new Set(pastas.value.map((p) => p.situacao))].sort())
const lista = computed(() => {
  const q = busca.value.trim().toLowerCase()
  return pastas.value
    .filter((p) => raiz.value === 'todas' || p.raiz === raiz.value)
    .filter((p) => !sit.value || p.situacao === sit.value)
    .filter((p) => !q || p.nome.toLowerCase().includes(q))
    .sort((a, b) => b.mtime.localeCompare(a.mtime))
})
const cont = (r) => pastas.value.filter((p) => r === 'todas' || p.raiz === r).length

function cls(s) {
  if (/pendente|aguardando resp/.test(s)) return 'warn'
  if (/conclu|gerado/.test(s)) return 'ok'
  if (/aguardando base/.test(s)) return ''
  return 'accent'
}
const ORDEM = { Layouts: ['Arquivo Origem', 'Modelo Operadora', 'Base Complementar', 'Arquivo Validado'],
  'Carga SDI': ['Arquivo Origem', 'Base Complementar', 'Arquivo Modelo', 'Arquivo Final'] }
const subs = (p) => [...ORDEM[p.raiz].filter((s) => s in p.subpastas), ...Object.keys(p.subpastas).filter((s) => !ORDEM[p.raiz].includes(s))]
</script>

<template>
  <section>
    <div class="filtros card">
      <div class="seg">
        <button :class="{ on: raiz === 'todas' }" @click="raiz = 'todas'">Todas <b>{{ cont('todas') }}</b></button>
        <button :class="['layout', { on: raiz === 'Layouts' }]" @click="raiz = 'Layouts'">Layouts · Maninha <b>{{ cont('Layouts') }}</b></button>
        <button :class="['carga', { on: raiz === 'Carga SDI' }]" @click="raiz = 'Carga SDI'">Carga SDI · Carregador do Futuro <b>{{ cont('Carga SDI') }}</b></button>
      </div>
      <div class="linha">
        <input v-model="busca" type="search" placeholder="Buscar pasta…" />
        <select v-model="sit"><option value="">Todas as situações</option><option v-for="s in situacoes" :key="s">{{ s }}</option></select>
      </div>
    </div>
    <div v-if="erro" class="vazio">{{ erro }}</div>
    <div v-else-if="carregando" class="vazio">Carregando…</div>
    <div v-else-if="!lista.length" class="vazio">Nenhuma pasta.</div>
    <div class="grade">
      <article v-for="p in lista" :key="p.raiz + p.nome" class="card pasta" :class="p.raiz === 'Layouts' ? 'layout' : 'carga'">
        <div class="l1">
          <span class="chip" :class="p.raiz === 'Layouts' ? 'layout' : 'carga'">{{ p.raiz === 'Layouts' ? 'Maninha' : 'Carregador' }}</span>
          <span class="chip" :class="cls(p.situacao)">{{ p.situacao }}</span>
          <span v-if="p.perguntas?.sem_resposta" class="chip warn">{{ p.perguntas.sem_resposta }} pergunta(s) sem R:</span>
        </div>
        <h3>{{ p.nome }}</h3>
        <div class="subs">
          <div v-for="s in subs(p)" :key="s" class="sub">
            <span class="muted">{{ s }}</span>
            <b>{{ p.subpastas[s].length }}</b>
            <ul v-if="p.subpastas[s].length"><li v-for="f in p.subpastas[s]" :key="f" :title="f">{{ f }}</li></ul>
          </div>
        </div>
        <div class="muted rod">Atualizada em {{ new Date(p.mtime).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) }}</div>
      </article>
    </div>
  </section>
</template>

<style scoped>
.filtros { padding: 12px; display: grid; gap: 10px; }
.seg { display: flex; flex-wrap: wrap; gap: 6px; }
.seg button {
  border: 1px solid var(--border); background: var(--surface); border-radius: 999px; padding: 6px 12px;
  cursor: pointer; font-weight: 600; color: var(--muted);
}
.seg button b { color: var(--text); margin-left: 4px; }
.seg button.on { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
.seg button.carga.on { background: var(--carga-soft); border-color: var(--carga); color: var(--carga); }
.seg button.layout.on { background: var(--layout-soft); border-color: var(--layout); color: var(--layout); }
.linha { display: flex; gap: 8px; flex-wrap: wrap; }
.linha input { flex: 1 1 240px; }
input, select { border: 1px solid var(--border); background: var(--surface); border-radius: 8px; padding: 7px 10px; min-width: 0; }
.grade { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 380px), 1fr)); gap: 10px; margin-top: 12px; }
.pasta { padding: 12px 14px; border-top: 3px solid var(--carga); }
.pasta.layout { border-top-color: var(--layout); }
.l1 { display: flex; gap: 6px; flex-wrap: wrap; }
h3 { font-size: 14px; margin: 6px 0 8px; overflow-wrap: anywhere; }
.subs { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.sub { background: var(--surface-2); border-radius: 8px; padding: 6px 8px; font-size: 12.5px; min-width: 0; }
.sub b { float: right; }
.sub ul { margin: 4px 0 0; padding-left: 14px; }
.sub li { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.rod { font-size: 12px; margin-top: 8px; }
</style>
