<script setup>
import { ref, onMounted } from 'vue'
import { api } from '../api.js'

const e = ref(null)
const erro = ref('')
onMounted(async () => {
  try { e.value = await api.estrutura() } catch (x) { erro.value = x.message }
})

const PARTES = [
  { id: 'A', nome: 'Encaminhar', script: 'encaminhar.py', cor: 'accent',
    faz: 'Lê suas respostas "R:" nos TXT e cria a pasta do atendimento em Layouts (1 · Maninha) ou Carga SDI (2 · Carregador). Automático, sem esperar o R:, pedido de layout com arquivo → Layouts; atualização de base / posição cadastral → Carga SDI (sem base: pasta só com _Dados do contrato.txt, aguardando base).' },
  { id: 'B', nome: 'Ler novos', script: 'agente_atendimentos.py + gerar_txt.py', cor: 'accent',
    faz: 'Lê na plataforma (somente leitura) os atendimentos de Julio Alves / Renan Silva / João Lourenço / sem responsável, resume os novos ou atualizados, traz dados do contrato e sugestão (1/2/3) e grava um novo Atendimentos_AAAAMMDD_HHMM.txt.' },
  { id: 'C', nome: 'Reatribuir / devolver', script: 'reatribuir.py', cor: 'warn',
    faz: 'Pedido de CARGA sem arquivo: benefício ≠ Vida → fila Dados Operacionais, atribuído a Vitor Matsuoka. Vida → nota interna ao solicitante pedindo base/fatura de ativos e devolve para a fila dele. Backup antes de alterar.' },
  { id: 'D', nome: 'Processar', script: 'criticador_xlsm.py + postar_criticador.py', cor: 'ok',
    faz: 'Maninha: gera o Criticador de layout (.xlsm), posta no atendimento como nota interna e monta o Layout Operadora. Carregador do Futuro: gera o Arquivo Final no Layout de movimentação, com Duvidas.txt quando falta informação.' },
]
</script>

<template>
  <section>
    <div v-if="erro" class="vazio">{{ erro }}</div>
    <template v-else>
      <h2>Fluxo de cada execução agendada</h2>
      <div class="fluxo">
        <article v-for="p in PARTES" :key="p.id" class="card parte">
          <div class="letra" :class="p.cor">{{ p.id }}</div>
          <div>
            <h3>{{ p.nome }}</h3>
            <code>{{ p.script }}</code>
            <p>{{ p.faz }}</p>
          </div>
        </article>
      </div>

      <div class="duas" v-if="e">
        <article class="card bloco">
          <h3>Situação</h3>
          <dl>
            <dt>Última execução</dt><dd>{{ e.ultima_execucao || '—' }}</dd>
            <dt>Atendimentos no controle</dt><dd>{{ e.total_controle }}</dd>
            <dt>Encaminhados</dt><dd>{{ e.total_encaminhados }}</dd>
            <dt>TXT gerados</dt><dd>{{ e.txts.length }} (último: {{ e.txts.at(-1) || '—' }})</dd>
            <dt>Credenciais</dt><dd><span class="chip" :class="e.credenciais ? 'ok' : 'danger'">{{ e.credenciais ? 'credenciais.env presente' : 'credenciais.env ausente' }}</span></dd>
            <dt>Backups</dt><dd>{{ e.total_backups }}</dd>
          </dl>
          <h4>Pastas</h4>
          <dl class="caminhos">
            <dt>Agente</dt><dd>{{ e.agente }}</dd>
            <dt>Layouts</dt><dd>{{ e.pastas.Layouts }}</dd>
            <dt>Carga SDI</dt><dd>{{ e.pastas['Carga SDI'] }}</dd>
          </dl>
        </article>
        <article class="card bloco">
          <h3>_sistema</h3>
          <table>
            <thead><tr><th>Arquivo</th><th>KB</th><th>Alterado</th></tr></thead>
            <tbody>
              <tr v-for="s in e.scripts" :key="s.nome">
                <td>{{ s.nome }}</td><td>{{ s.kb }}</td>
                <td>{{ new Date(s.mtime).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) }}</td>
              </tr>
            </tbody>
          </table>
          <h4>Últimos backups</h4>
          <ul class="bk"><li v-for="b in e.backups.slice().reverse()" :key="b">{{ b }}</li></ul>
        </article>
      </div>

      <article class="card bloco regras">
        <h3>Como responder (linha R:)</h3>
        <ul>
          <li><b>1</b> / maninha → cria pasta em Layouts e baixa os anexos</li>
          <li><b>2</b> / carregador → cria pasta em Carga SDI e baixa os anexos</li>
          <li><b>3</b> / sem ação → nada é feito</li>
          <li><b>ok</b> → aceita a Sugestão do Claude</li>
          <li>Citar o nome de um anexo → baixa só esse arquivo</li>
          <li>Qualquer outro texto → "Outro", vai para o relatório da execução</li>
        </ul>
        <p class="muted">Agendamentos separados "Maninha" e "Carregador do Futuro" cuidam de pastas manuais e de Duvidas.txt respondidos.</p>
      </article>
    </template>
  </section>
</template>

<style scoped>
h2 { font-size: 16px; margin: 4px 0 12px; }
.fluxo { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 260px), 1fr)); gap: 10px; }
.parte { display: flex; gap: 12px; padding: 14px; }
.letra {
  flex: none; width: 34px; height: 34px; border-radius: 8px; display: grid; place-items: center;
  font-weight: 800; background: var(--accent-soft); color: var(--accent);
}
.letra.warn { background: var(--warn-soft); color: var(--warn); }
.letra.ok { background: var(--ok-soft); color: var(--ok); }
h3 { margin: 0 0 4px; font-size: 15px; }
code { font-size: 12px; color: var(--muted); }
p { margin: 6px 0 0; font-size: 13px; }
.duas { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 420px), 1fr)); gap: 10px; margin-top: 16px; }
.bloco { padding: 14px; }
h4 { margin: 14px 0 6px; font-size: 12px; text-transform: uppercase; color: var(--muted); }
dl { display: grid; grid-template-columns: max-content 1fr; gap: 4px 14px; margin: 8px 0 0; font-size: 13px; }
dt { color: var(--muted); }
dd { margin: 0; overflow-wrap: anywhere; }
table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; }
th, td { text-align: left; padding: 4px 6px; border-bottom: 1px solid var(--border); }
th { color: var(--muted); font-weight: 600; }
.bk { font-size: 12.5px; padding-left: 18px; margin: 0; }
.regras { margin-top: 16px; }
.regras ul { font-size: 13px; padding-left: 18px; }
</style>
