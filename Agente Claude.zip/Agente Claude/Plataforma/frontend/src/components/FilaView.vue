<script setup>
// Aba "Fila completa" (pedido do Julio de 11/11/2026): todos os atendimentos abertos de Dados Operacionais,
// de todos os responsáveis — só informações, sem pré-análise. Somente leitura.
import { ref, computed, onMounted, watch } from 'vue'
import { api } from '../api.js'
import MultiFiltro from './MultiFiltro.vue'

const emit = defineEmits(['avisar', 'contagem'])
const dados = ref({ coletado_em: '', itens: [], rpa: [] })
const carregando = ref(false)
const erro = ref('')

const busca = ref('')
const responsavel = ref([])
const etapa = ref([])
const tipo = ref([])
const solicitante = ref([])
const filaSol = ref([])
const parado = ref('')
const naPre = ref('')
const origem = ref('')
const solicitacao = ref([])
const ordem = ref({ campo: 'dias_uteis_sem_interacao', desc: true })
const verRpa = ref(false)
const limite = ref(300)   // com o Xipp Bot são ~2.000 linhas: mostra 300 e carrega mais sob demanda
watch([busca, responsavel, etapa, tipo, solicitante, filaSol, parado, naPre, origem, solicitacao, ordem], () => (limite.value = 300), { deep: true })
const visiveis = computed(() => filtrados.value.slice(0, limite.value))

async function carregar(sync = false) {
  carregando.value = true
  erro.value = ''
  try {
    const r = await api.fila(sync)
    dados.value = r
    emit('contagem', r.itens.length)
    if (r.erro_atualizacao) emit('avisar', { texto: `Não consegui atualizar a fila: ${r.erro_atualizacao}`, erro: true })
    else if (sync) emit('avisar', { texto: `Fila atualizada: ${r.itens.length} atendimentos abertos` })
  } catch (e) {
    erro.value = e.message
  } finally {
    carregando.value = false
  }
}
onMounted(() => carregar())

const itens = computed(() => dados.value.itens || [])

function semAcento(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
}
function opcoesN(f, ordemFixa) {
  const c = new Map()
  for (const i of itens.value) c.set(f(i) || '—', (c.get(f(i) || '—') || 0) + 1)
  let l = [...c].map(([v, n]) => ({ v, n }))
  if (ordemFixa) l.sort((a, b) => ordemFixa.indexOf(a.v) - ordemFixa.indexOf(b.v))
  else l.sort((a, b) => b.n - a.n || String(a.v).localeCompare(b.v))
  return l
}
function opcoesNLista(f) {
  const c = new Map()
  for (const i of itens.value) for (const v of f(i) || []) c.set(v, (c.get(v) || 0) + 1)
  return [...c].map(([v, n]) => ({ v, n })).sort((a, b) => b.n - a.n || a.v.localeCompare(b.v))
}

const filtrados = computed(() => {
  const q = semAcento(busca.value.trim())
  const lim = parado.value ? Number(parado.value) : null
  const l = itens.value.filter((i) =>
    (!responsavel.value.length || responsavel.value.includes(i.responsavel)) &&
    (!etapa.value.length || etapa.value.includes(i.etapa)) &&
    (!tipo.value.length || tipo.value.includes(i.tipo)) &&
    (!solicitante.value.length || solicitante.value.includes(i.solicitante || '—')) &&
    (!filaSol.value.length || (i.fila_solicitante || []).some((f) => filaSol.value.includes(f))) &&
    (lim === null || i.dias_uteis_sem_interacao > lim) &&
    (!naPre.value || (naPre.value === 'sim') === !!i.na_preanalise) &&
    (!origem.value || (origem.value === 'bot') === !!i.bot) &&
    (!solicitacao.value.length || solicitacao.value.includes(i.solicitacao || '—')) &&
    (!q || semAcento([i.id, i.numero, i.protocolo, i.titulo, i.contrato, i.solicitante, i.responsavel].join(' ')).includes(q)))
  const { campo, desc } = ordem.value
  const chave = (i) => (campo === 'abertura' || campo === 'ultima_interacao' ? dataNum(i[campo]) : i[campo])
  return l.sort((a, b) => {
    const x = chave(a), y = chave(b)
    const r = typeof x === 'number' && typeof y === 'number' ? x - y : String(x || '').localeCompare(String(y || ''))
    return desc ? -r : r
  })
})

function dataNum(s) {
  const m = /(\d\d)\/(\d\d)\/(\d{4})(?: (\d\d):(\d\d))?/.exec(s || '')
  return m ? Number(m[3] + m[2] + m[1] + (m[4] || '00') + (m[5] || '00')) : 0
}
function ordenar(campo) {
  ordem.value = ordem.value.campo === campo ? { campo, desc: !ordem.value.desc } : { campo, desc: true }
}
function seta(campo) {
  return ordem.value.campo === campo ? (ordem.value.desc ? ' ▼' : ' ▲') : ''
}

// Resumo por responsável (clicar filtra)
const resumo = computed(() => {
  const m = new Map()
  for (const i of itens.value) {
    const r = m.get(i.responsavel) || { nome: i.responsavel, total: 0, novo: 0, andamento: 0, outros: 0, parados: 0 }
    r.total++
    if (i.etapa === 'Novo') r.novo++
    else if (i.etapa === 'Em Andamento') r.andamento++
    else r.outros++
    if (i.dias_uteis_sem_interacao > 7) r.parados++
    m.set(i.responsavel, r)
  }
  return [...m.values()].sort((a, b) => b.total - a.total)
})
function filtrarResp(nome) {
  responsavel.value = responsavel.value.length === 1 && responsavel.value[0] === nome ? [] : [nome]
}
function limpar() {
  busca.value = ''; responsavel.value = []; etapa.value = []; tipo.value = []; solicitante.value = []
  filaSol.value = []; parado.value = ''; naPre.value = ''; origem.value = ''; solicitacao.value = []
}
const temFiltro = computed(() => busca.value || responsavel.value.length || etapa.value.length || tipo.value.length ||
  solicitante.value.length || filaSol.value.length || parado.value || naPre.value || origem.value || solicitacao.value.length)

const rpaTotal = computed(() => (dados.value.rpa || []).reduce((s, r) => s + r.qtd, 0))
const rpaPorEtapa = computed(() => {
  const m = new Map()
  for (const r of dados.value.rpa || []) m.set(r.etapa, (m.get(r.etapa) || 0) + r.qtd)
  return [...m].sort((a, b) => b[1] - a[1])
})
const fmt = (n) => Number(n).toLocaleString('pt-BR')
const nBot = computed(() => itens.value.filter((i) => i.bot).length)
const corTipo = { Carga: 'carga', Layout: 'layout', Sinistro: 'warn' }
const corEtapa = { Novo: 'accent', 'Em Andamento': 'ok' }
function corParado(d) {
  return d > 15 ? 'danger' : d > 7 ? 'warn' : ''
}
</script>

<template>
  <section>
    <div class="cab">
      <div>
        <h2>Fila completa — Dados Operacionais</h2>
        <div class="muted">
          {{ fmt(itens.length) }} atendimentos abertos ({{ fmt(nBot) }} do Xipp Bot, fora Posição Cadastral/Faturamento) · coletado em <b>{{ dados.coletado_em || '—' }}</b>
        </div>
      </div>
      <button class="btn primary" :disabled="carregando" @click="carregar(true)">
        {{ carregando ? 'Atualizando…' : '↻ Atualizar fila' }}
      </button>
    </div>

    <div v-if="erro" class="card erro">Erro ao ler a fila: {{ erro }}</div>
    <div v-else-if="!itens.length && !carregando" class="card vazio">
      Ainda não há coleta da fila. Clique em <b>↻ Atualizar fila</b>.
    </div>

    <template v-if="itens.length">
      <div class="resumo">
        <button v-for="r in resumo" :key="r.nome" class="card pessoa"
                :class="{ sel: responsavel.length === 1 && responsavel[0] === r.nome }" @click="filtrarResp(r.nome)">
          <div class="nome">{{ r.nome }}</div>
          <div class="num">{{ r.total }}</div>
          <div class="det muted">
            {{ r.novo }} novo · {{ r.andamento }} andamento<span v-if="r.outros"> · {{ r.outros }} outras</span>
          </div>
          <div v-if="r.parados" class="det par">{{ r.parados }} parado{{ r.parados > 1 ? 's' : '' }} &gt; 7 dias úteis</div>
        </button>
      </div>

      <div class="filtros card">
        <div class="linha">
          <input v-model="busca" class="busca" type="search" placeholder="Buscar HT, protocolo, id, título, contrato…" />
          <select v-model="parado" title="Dias úteis sem interação">
            <option value="">Qualquer tempo parado</option>
            <option value="3">Parado &gt; 3 dias úteis</option>
            <option value="7">Parado &gt; 7 dias úteis</option>
            <option value="15">Parado &gt; 15 dias úteis</option>
          </select>
          <select v-model="origem">
            <option value="">Pessoas e Xipp Bot</option>
            <option value="pessoa">Só abertos por pessoas</option>
            <option value="bot">Só Xipp Bot</option>
          </select>
          <select v-model="naPre">
            <option value="">Na Pré-análise ou não</option>
            <option value="sim">Só os da Pré-análise</option>
            <option value="nao">Só os fora da Pré-análise</option>
          </select>
          <button v-if="temFiltro" class="btn small" @click="limpar">Limpar filtros</button>
        </div>
        <div class="linha">
          <MultiFiltro v-model="responsavel" rotulo="Responsável" todos="Todos os responsáveis" :opcoes="opcoesN((i) => i.responsavel)" />
          <MultiFiltro v-model="etapa" rotulo="Etapa" todos="Toda etapa" :opcoes="opcoesN((i) => i.etapa)" />
          <MultiFiltro v-model="tipo" rotulo="Tipo" todos="Todo tipo" :opcoes="opcoesN((i) => i.tipo)" />
          <MultiFiltro v-model="solicitacao" rotulo="Solicitação" todos="Toda solicitação" :opcoes="opcoesN((i) => i.solicitacao)" />
          <MultiFiltro v-model="solicitante" rotulo="Solicitante" todos="Todos os solicitantes" :opcoes="opcoesN((i) => i.solicitante)" />
          <MultiFiltro v-model="filaSol" rotulo="Fila do solicitante" todos="Toda fila do solicitante" :opcoes="opcoesNLista((i) => i.fila_solicitante)" />
        </div>
        <div class="muted small">{{ fmt(filtrados.length) }} de {{ fmt(itens.length) }} com estes filtros</div>
      </div>

      <div class="card rolar">
        <table class="tab">
          <thead>
            <tr>
              <th @click="ordenar('protocolo')">Protocolo{{ seta('protocolo') }}</th>
              <th @click="ordenar('titulo')">Título{{ seta('titulo') }}</th>
              <th @click="ordenar('responsavel')">Responsável{{ seta('responsavel') }}</th>
              <th @click="ordenar('etapa')">Etapa{{ seta('etapa') }}</th>
              <th @click="ordenar('tipo')">Tipo{{ seta('tipo') }}</th>
              <th @click="ordenar('solicitante')">Solicitante{{ seta('solicitante') }}</th>
              <th @click="ordenar('contrato')">Contrato{{ seta('contrato') }}</th>
              <th @click="ordenar('abertura')">Criado em{{ seta('abertura') }}</th>
              <th @click="ordenar('ultima_interacao')">Última interação{{ seta('ultima_interacao') }}</th>
              <th @click="ordenar('dias_uteis_sem_interacao')" title="Dias úteis sem interação">Parado{{ seta('dias_uteis_sem_interacao') }}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="i in visiveis" :key="i.id">
              <td class="nw">
                <a :href="i.link" target="_blank" rel="noopener">{{ i.protocolo || i.id }}</a>
                <div v-if="i.numero" class="muted small">{{ i.numero }}</div>
              </td>
              <td class="tit">{{ i.titulo }}</td>
              <td>{{ i.responsavel }}<div v-if="!i.na_preanalise" class="muted small">fora da Pré-análise</div></td>
              <td><span class="chip" :class="corEtapa[i.etapa]">{{ i.etapa }}</span></td>
              <td><span class="chip" :class="corTipo[i.tipo]">{{ i.tipo }}</span></td>
              <td>{{ i.solicitante || '—' }}<div v-if="i.solicitacao || i.bot" class="muted small">{{ i.solicitacao || 'solicitação em branco' }}</div></td>
              <td class="small">{{ i.contrato || '—' }}</td>
              <td class="nw small">{{ i.abertura }}</td>
              <td class="nw small">{{ i.ultima_interacao }}<div v-if="i.ultimo_autor" class="muted">{{ i.ultimo_autor }}</div></td>
              <td><span class="chip" :class="corParado(i.dias_uteis_sem_interacao)">{{ i.dias_uteis_sem_interacao }} d</span></td>
            </tr>
          </tbody>
        </table>
        <div v-if="!filtrados.length" class="vazio">Nenhum atendimento com esses filtros.</div>
        <div v-else-if="filtrados.length > limite" class="mais">
          <span class="muted">Mostrando {{ fmt(limite) }} de {{ fmt(filtrados.length) }}</span>
          <button class="btn small" @click="limite += 300">Mostrar mais 300</button>
          <button class="btn small" @click="limite = filtrados.length">Mostrar todos</button>
        </div>
      </div>

      <div v-if="rpaTotal" class="card rpa">
        <button class="btn small" @click="verRpa = !verRpa">{{ verRpa ? '▾' : '▸' }} Xipp Bot — Posição Cadastral / Faturamento</button>
        <span class="muted"> {{ fmt(rpaTotal) }} atendimentos abertos das rotinas RPA — não listados um a um:
          <span v-for="([e, n], k) in rpaPorEtapa" :key="e">{{ k ? ' · ' : '' }}{{ e }} {{ fmt(n) }}</span>
        </span>
        <table v-if="verRpa" class="tab rpa-tab">
          <thead><tr><th>Etapa</th><th>Responsável</th><th class="dir">Qtd</th></tr></thead>
          <tbody>
            <tr v-for="r in dados.rpa" :key="r.etapa + r.responsavel">
              <td>{{ r.etapa }}</td><td>{{ r.responsavel }}</td><td class="dir">{{ fmt(r.qtd) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </section>
</template>

<style scoped>
.cab { display: flex; justify-content: space-between; align-items: flex-end; gap: 12px; margin-bottom: 14px; flex-wrap: wrap; }
h2 { margin: 0 0 2px; font-size: 18px; }
.erro { padding: 12px 16px; border-color: var(--danger); color: var(--danger); }
.resumo { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 10px; margin-bottom: 12px; }
.pessoa { text-align: left; padding: 10px 12px; cursor: pointer; font: inherit; color: inherit; }
.pessoa:hover { border-color: var(--accent); }
.pessoa.sel { border-color: var(--accent); background: var(--accent-soft); }
.pessoa .nome { font-weight: 600; font-size: 13px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pessoa .num { font-size: 24px; font-weight: 700; line-height: 1.2; }
.pessoa .det { font-size: 12px; }
.pessoa .par { color: var(--warn); font-weight: 600; }
.filtros { padding: 12px 16px; margin-bottom: 12px; display: grid; gap: 10px; }
.linha { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.busca { flex: 1 1 260px; min-width: 0; }
input, select { border: 1px solid var(--border); border-radius: 8px; padding: 6px 10px; background: var(--surface); }
.small { font-size: 12px; }
.rolar { overflow-x: auto; }
.tab { width: 100%; border-collapse: collapse; font-size: 13px; }
.tab th { text-align: left; color: var(--muted); font-weight: 600; padding: 8px; border-bottom: 1px solid var(--border);
  cursor: pointer; white-space: nowrap; user-select: none; position: sticky; top: 0; background: var(--surface); }
.tab td { padding: 7px 8px; border-bottom: 1px solid var(--border); vertical-align: top; }
.tab tbody tr:hover { background: var(--surface-2); }
.nw { white-space: nowrap; }
.tit { min-width: 240px; }
.dir { text-align: right; }
.rpa { padding: 12px 16px; margin-top: 12px; }
.mais { display: flex; gap: 8px; align-items: center; justify-content: center; padding: 12px; flex-wrap: wrap; }
.rpa-tab { margin-top: 10px; max-width: 640px; }
.rpa-tab th { cursor: default; }
</style>
