<script setup>
import { ref, computed, watch } from 'vue'
import { TIPOS } from '../api.js'
import CasoCard from './CasoCard.vue'

const props = defineProps({ casos: Array, modo: String, carregando: Boolean })
const emit = defineEmits(['responder'])

const LS = 'agente-filtros-' + props.modo
const salvo = (() => { try { return JSON.parse(localStorage.getItem(LS) || '{}') } catch { return {} } })()

const tipo = ref(salvo.tipo || 'todos')
const busca = ref('')
const responsavel = ref(salvo.responsavel || '')
const situacao = ref(salvo.situacao || (props.modo === 'todos' ? 'abertos' : ''))
const ordem = ref(salvo.ordem || 'antigos')

watch([tipo, responsavel, situacao, ordem], () => {
  try {
    localStorage.setItem(LS, JSON.stringify({ tipo: tipo.value, responsavel: responsavel.value, situacao: situacao.value, ordem: ordem.value }))
  } catch {}
})

function situacaoDe(c) {
  if (c.aberto_na_plataforma === false) return 'fechado'
  if (c.encaminhado && !c.resposta) return 'automatico'
  if (c.resposta) return 'respondido'
  return 'pendente'
}

const base = computed(() => {
  let l = props.casos
  if (props.modo === 'todos' && situacao.value) {
    l = l.filter((c) => (situacao.value === 'abertos' ? situacaoDe(c) !== 'fechado' : situacaoDe(c) === situacao.value))
  }
  if (responsavel.value) l = l.filter((c) => c.responsavel === responsavel.value)
  const q = busca.value.trim().toLowerCase()
  if (q) {
    l = l.filter((c) =>
      [c.chave, c.protocolo, c.titulo, c.solicitante, c.resumo, c.contrato?.Contrato, c.contrato?.Operadora]
        .join(' ')
        .toLowerCase()
        .includes(q),
    )
  }
  return l
})

const contagem = computed(() => {
  const r = { todos: base.value.length, carga: 0, layout: 0, outros: 0 }
  base.value.forEach((c) => r[c.tipo]++)
  return r
})

const lista = computed(() => {
  const l = tipo.value === 'todos' ? base.value : base.value.filter((c) => c.tipo === tipo.value)
  const s = [...l].sort((a, b) => (a.aberto_iso || '9').localeCompare(b.aberto_iso || '9') || a.id - b.id)
  return ordem.value === 'antigos' ? s : s.reverse()
})

const responsaveis = computed(() => [...new Set(props.casos.map((c) => c.responsavel).filter(Boolean))].sort())
</script>

<template>
  <section>
    <div class="filtros card">
      <div class="seg" role="tablist" aria-label="Tipo de caso">
        <button :class="{ on: tipo === 'todos' }" @click="tipo = 'todos'">Todos <b>{{ contagem.todos }}</b></button>
        <button :class="['carga', { on: tipo === 'carga' }]" @click="tipo = 'carga'">
          <i class="dot carga"></i>Carga de arquivo <b>{{ contagem.carga }}</b>
        </button>
        <button :class="['layout', { on: tipo === 'layout' }]" @click="tipo = 'layout'">
          <i class="dot layout"></i>Validação de layout <b>{{ contagem.layout }}</b>
        </button>
        <button :class="{ on: tipo === 'outros' }" @click="tipo = 'outros'">Outros <b>{{ contagem.outros }}</b></button>
      </div>
      <div class="linha">
        <input v-model="busca" type="search" placeholder="Buscar por HT, protocolo, cliente, solicitante, contrato…" />
        <select v-model="responsavel" aria-label="Responsável">
          <option value="">Todos os responsáveis</option>
          <option v-for="r in responsaveis" :key="r" :value="r">{{ r }}</option>
        </select>
        <select v-if="modo === 'todos'" v-model="situacao" aria-label="Situação">
          <option value="abertos">Abertos na plataforma</option>
          <option value="pendente">Aguardando sua resposta</option>
          <option value="respondido">Respondidos</option>
          <option value="automatico">Encaminhados automaticamente</option>
          <option value="fechado">Fora do filtro / fechados</option>
          <option value="">Todos</option>
        </select>
        <select v-model="ordem" aria-label="Ordem">
          <option value="antigos">Mais antigo → mais recente</option>
          <option value="recentes">Mais recente → mais antigo</option>
        </select>
      </div>
    </div>

    <p v-if="modo === 'responder'" class="muted dica">
      Casos sem resposta no "R:" e ainda abertos na plataforma, do mais antigo para o mais recente.
      Ao responder, a linha "R:" é gravada no TXT e o agente agendado executa na próxima rodada.
    </p>

    <div v-if="carregando && !casos.length" class="vazio">Carregando…</div>
    <div v-else-if="!lista.length" class="vazio">
      {{ modo === 'responder' ? 'Nada aguardando sua resposta neste filtro.' : 'Nenhum caso neste filtro.' }}
    </div>
    <div v-else class="lista">
      <CasoCard v-for="c in lista" :key="c.id" :caso="c" :situacao="situacaoDe(c)" @responder="emit('responder', $event)" />
    </div>
  </section>
</template>

<style scoped>
.filtros { padding: 12px; display: grid; gap: 10px; position: sticky; top: 0; z-index: 5; }
.seg { display: flex; flex-wrap: wrap; gap: 6px; }
.seg button {
  border: 1px solid var(--border); background: var(--surface); border-radius: 999px; padding: 6px 12px;
  cursor: pointer; display: inline-flex; gap: 6px; align-items: center; font-weight: 600; color: var(--muted);
}
.seg button b { font-weight: 700; color: var(--text); }
.seg button.on { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
.seg button.carga.on { background: var(--carga-soft); border-color: var(--carga); color: var(--carga); }
.seg button.layout.on { background: var(--layout-soft); border-color: var(--layout); color: var(--layout); }
.dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
.dot.carga { background: var(--carga); }
.dot.layout { background: var(--layout); }
.linha { display: flex; gap: 8px; flex-wrap: wrap; }
.linha input { flex: 1 1 260px; }
input, select {
  border: 1px solid var(--border); background: var(--surface); border-radius: 8px; padding: 7px 10px; min-width: 0;
}
.dica { margin: 12px 2px; font-size: 13px; }
.lista { display: grid; gap: 10px; margin-top: 12px; }
</style>
