<script setup>
import { ref, computed, onMounted } from 'vue'
import { api } from './api.js'
import CasosView from './components/CasosView.vue'
import PastasView from './components/PastasView.vue'
import EstruturaView from './components/EstruturaView.vue'
import PreAnaliseView from './components/PreAnaliseView.vue'
import FilaView from './components/FilaView.vue'

const aba = ref('preanalise')
const preCont = ref(null)
const filaCont = ref(null)
const casos = ref([])
const meta = ref({ ultima_execucao: '', odoo: {} })
const carregando = ref(false)
const erro = ref('')
const toast = ref(null)
let toastTimer = null

async function carregar(sync = false) {
  carregando.value = true
  erro.value = ''
  try {
    const r = await api.casos(sync)
    casos.value = r.casos
    meta.value = { ultima_execucao: r.ultima_execucao, odoo: r.odoo || {} }
  } catch (e) {
    erro.value = e.message
  } finally {
    carregando.value = false
  }
}

const pendentes = computed(() => casos.value.filter((c) => c.precisa_responder))

function avisar(t) {
  toast.value = t
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.value = null), 7000)
}

async function responder({ caso, resposta, anterior }) {
  try {
    const r = await api.responder(caso.id, resposta)
    await carregar()
    avisar({
      texto: resposta ? `${caso.chave}: resposta "${resposta}" gravada em ${r.txt}` : `${caso.chave}: resposta apagada`,
      desfazer: () => responder({ caso, resposta: anterior || '', anterior: resposta }),
    })
  } catch (e) {
    avisar({ texto: `Não foi possível gravar: ${e.message}`, erro: true })
  }
}

const odooTxt = computed(() => {
  const o = meta.value.odoo || {}
  if (o.erro) return { cls: 'warn', t: 'Plataforma Odoo indisponível — mostrando todos os casos dos TXT' }
  if (o.abertos != null) {
    const h = o.quando ? new Date(o.quando).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : ''
    return { cls: 'ok', t: `${o.abertos} abertos no filtro · sincronizado ${h}` }
  }
  return { cls: '', t: 'Sem sincronização' }
})

onMounted(() => carregar())
</script>

<template>
  <header class="topo">
    <div class="marca">
      <div class="logo">X</div>
      <div>
        <h1>Agente de Atendimentos</h1>
        <div class="muted sub">
          Última execução do agente: <b>{{ meta.ultima_execucao || '—' }}</b>
          <span class="chip" :class="odooTxt.cls" :title="meta.odoo?.erro || ''">{{ odooTxt.t }}</span>
        </div>
      </div>
    </div>
    <button class="btn" :disabled="carregando" @click="carregar(true)">
      {{ carregando ? 'Atualizando…' : '↻ Atualizar' }}
    </button>
  </header>

  <nav class="abas">
    <button :class="{ ativa: aba === 'preanalise' }" @click="aba = 'preanalise'">
      Pré-análise <span v-if="preCont !== null" class="cont">{{ preCont }}</span>
    </button>
    <button :class="{ ativa: aba === 'fila' }" @click="aba = 'fila'">
      Fila completa <span v-if="filaCont !== null" class="cont">{{ filaCont }}</span>
    </button>
    <button :class="{ ativa: aba === 'responder' }" @click="aba = 'responder'">
      Para responder <span class="cont">{{ pendentes.length }}</span>
    </button>
    <button :class="{ ativa: aba === 'todos' }" @click="aba = 'todos'">
      Todos os casos <span class="cont">{{ casos.length }}</span>
    </button>
    <button :class="{ ativa: aba === 'pastas' }" @click="aba = 'pastas'">Pastas (Maninha / Carregador)</button>
    <button :class="{ ativa: aba === 'estrutura' }" @click="aba = 'estrutura'">Estrutura do agente</button>
  </nav>

  <main>
    <div v-if="erro" class="card erro">Erro ao ler os dados: {{ erro }}</div>
    <PreAnaliseView v-if="aba === 'preanalise'" @avisar="avisar" @contagem="(n) => (preCont = n)" />
    <FilaView v-else-if="aba === 'fila'" @avisar="avisar" @contagem="(n) => (filaCont = n)" />
    <CasosView v-else-if="aba === 'responder'" :casos="pendentes" modo="responder" :carregando="carregando" @responder="responder" />
    <CasosView v-else-if="aba === 'todos'" :casos="casos" modo="todos" :carregando="carregando" @responder="responder" />
    <PastasView v-else-if="aba === 'pastas'" />
    <EstruturaView v-else />
  </main>

  <transition name="sobe">
    <div v-if="toast" class="toast" :class="{ erro: toast.erro }">
      <span>{{ toast.texto }}</span>
      <button v-if="toast.desfazer" class="btn small" @click="toast.desfazer(); toast = null">Desfazer</button>
      <button class="fechar" @click="toast = null" aria-label="Fechar">×</button>
    </div>
  </transition>
</template>

<style scoped>
.topo {
  display: flex; justify-content: space-between; align-items: center; gap: 12px;
  padding: 16px 24px; background: var(--surface); border-bottom: 1px solid var(--border);
}
.marca { display: flex; gap: 12px; align-items: center; min-width: 0; }
.logo {
  width: 36px; height: 36px; border-radius: 9px; background: var(--accent); color: #fff;
  display: grid; place-items: center; font-weight: 800; flex: none;
}
h1 { margin: 0; font-size: 18px; }
.sub { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; font-size: 13px; }
.abas {
  display: flex; gap: 4px; padding: 0 24px; background: var(--surface);
  border-bottom: 1px solid var(--border); overflow-x: auto;
}
.abas button {
  border: 0; background: none; padding: 12px 10px; cursor: pointer; color: var(--muted);
  border-bottom: 2px solid transparent; font-weight: 600; white-space: nowrap;
}
.abas button.ativa { color: var(--text); border-bottom-color: var(--accent); }
.cont { background: var(--surface-2); border-radius: 999px; padding: 0 7px; font-size: 12px; margin-left: 4px; }
.abas button.ativa .cont { background: var(--accent); color: #fff; }
main { padding: 20px 24px 80px; max-width: 1680px; margin: 0 auto; }
.erro { padding: 12px 16px; border-color: var(--danger); color: var(--danger); margin-bottom: 12px; }
.toast {
  position: fixed; left: 50%; bottom: 20px; transform: translateX(-50%);
  background: var(--text); color: var(--bg); padding: 10px 12px 10px 16px; border-radius: 10px;
  display: flex; gap: 12px; align-items: center; box-shadow: 0 8px 24px rgba(0,0,0,.2); max-width: calc(100% - 32px);
}
.toast.erro { background: var(--danger); color: #fff; }
.toast .btn { background: transparent; color: inherit; border-color: currentColor; }
.fechar { background: none; border: 0; color: inherit; font-size: 18px; cursor: pointer; }
.sobe-enter-from, .sobe-leave-to { opacity: 0; transform: translate(-50%, 10px); }
.sobe-enter-active, .sobe-leave-active { transition: all .2s; }
@media (max-width: 640px) {
  .topo, main { padding-left: 16px; padding-right: 16px; }
  .abas { padding: 0 8px; }
}
</style>
