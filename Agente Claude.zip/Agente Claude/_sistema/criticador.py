#!/usr/bin/env python3
"""Maninha - Criticador de Layout (formato .xlsx padrão de 3 abas: Resumo / Dados / Relatório de Crítica).

Implementa as regras da skill layout-implantacao-ans num processo único e reutilizável
(nunca editar regras por caso). Uso:
  python3 criticador.py --entrada arq1.xlsx [arq2.xlsx ...] --saida AAAAMMDD_Criticador\ de\ layout_V1.xlsx
                        [--complementar base.xlsx] [--titulo "(#566478-1) ..."] [--json resumo.json]
"""
import argparse, json, re, unicodedata, datetime as dt
from collections import Counter, defaultdict
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

COLS = ["CNPJ", "NOME EMPRESA", "MATRICULA FUNCIONARIO", "CENTRO CUSTO", "NOME", "CARGO", "PLANO", "NOME PLANO",
        "PARENTESCO", "SEXO", "NASCIMENTO", "CPF", "PIS", "RG", "ORGAO EMISSOR", "DATA EXPEDICAO", "DNV", "ESTADO CIVIL",
        "NOME MAE", "ADMISSAO", "DEPARTAMENTO", "NOME BANCO", "CODIGO BANCO", "CODIGO AGENCIA", "DIGITO AGENCIA",
        "CODIGO CONTA CORRENTE", "DIGITO CONTA CORRENTE", "TIPO LOGRADOURO", "NOME LOGRADOURO", "NUMERO", "COMPLEMENTO",
        "BAIRRO", "CIDADE", "UF", "CEP", "DDD", "TELEFONE", "EMAIL", "PESO", "ALTURA", "VINCULO EMPREGATICIO", "CNS",
        "NOME SOCIAL", "IDADE", "SITUAÇÃO", "DATA DEMISSÃO / APOSENTADORIA", "DATA FIM DA COBERTURA"]
DATAS = ["NASCIMENTO", "DATA EXPEDICAO", "ADMISSAO", "DATA DEMISSÃO / APOSENTADORIA", "DATA FIM DA COBERTURA"]
HERANCA = ["CNPJ", "NOME EMPRESA", "PLANO", "NOME PLANO", "NOME LOGRADOURO", "NUMERO", "COMPLEMENTO", "BAIRRO",
           "CIDADE", "UF", "CEP"]
# (coluna, mensagem, só titular)
OBRIG = [("CNPJ", "Sub ou CNPJ não informado", False), ("NOME EMPRESA", "Nome da empresa não informado", False),
         ("MATRICULA FUNCIONARIO", "Matrícula não informada", False), ("NOME", "Nome não informado", False),
         ("CARGO", "Cargo não informado", True), ("PLANO", "Plano não informado", False),
         ("PARENTESCO", "Parentesco não informado", False), ("SEXO", "Sexo não informado", False),
         ("NASCIMENTO", "Data de nascimento não informada", False), ("CPF", "CPF não informado", False),
         ("ESTADO CIVIL", "Estado civil não informado", False), ("NOME MAE", "Nome da mãe não informado", False),
         ("ADMISSAO", "Data de admissão não informado", True), ("NOME LOGRADOURO", "Logradouro não informado", True),
         ("NUMERO", "Número do logradouro não informado", True), ("BAIRRO", "Bairro não informado", True),
         ("CIDADE", "Cidade não informado", True), ("UF", "Estado não informado", True),
         ("CEP", "CEP não informado", True), ("DDD", "DDD não informado", True),
         ("TELEFONE", "Telefone não informado", True), ("EMAIL", "E-mail não informado", True)]
MSG_COL = {m: c for c, m, _ in OBRIG}
PLACEHOLDER = {"N INFORMADO", "NAO INFORMADO", "NAO INFORMADA", "N/A", "NA", "-", "--", "NULL", "NONE", "N/I", "NI",
               "SEM INFORMACAO", "NAO CONSTA"}
CONJ = {"CONJUGE", "ESPOSO", "ESPOSA", "COMPANHEIRO", "COMPANHEIRA", "COMPANHEIRO (A)", "COMPANHEIRO(A)",
        "COMPANHEIRA (O)", "COMPANHEIRA(O)"}
CAT_COR = {"Obrigatório ausente": ("F5B7B1", "943126"), "Formato inválido": ("FAD7A0", "9C640C"),
           "Duplicidade": ("D2B4DE", "6C3483"), "Consistência": ("A9CCE3", "1F618D")}
NAVY = "1F3864"
HOJE = dt.date.today()


def sem_acento(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()


def chave(s):
    return re.sub(r"\s+", " ", sem_acento(str(s or "")).upper().replace("_", " ")).strip()


ALIAS = {chave(c): c for c in COLS}
ALIAS.update({"MATRICULA": "MATRICULA FUNCIONARIO", "DATA NASCIMENTO": "NASCIMENTO", "DATA DE NASCIMENTO": "NASCIMENTO",
              "NOME DA MAE": "NOME MAE", "DATA ADMISSAO": "ADMISSAO", "DATA DE ADMISSAO": "ADMISSAO", "E-MAIL": "EMAIL",
              "SITUACAO": "SITUAÇÃO", "DATA DEMISSAO / APOSENTADORIA": "DATA DEMISSÃO / APOSENTADORIA",
              "DATA DEMISSAO/APOSENTADORIA": "DATA DEMISSÃO / APOSENTADORIA", "LOGRADOURO": "NOME LOGRADOURO",
              # relações extraídas de fatura/portal de operadora (ex.: Bradesco) — 26/10/2026
              "TITULARIDADE": "PARENTESCO", "GRAU DE PARENTESCO": "PARENTESCO", "NOME DO PLANO": "NOME PLANO"})


def txt(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    if isinstance(v, (dt.datetime, dt.date)):
        return v.strftime("%d/%m/%Y")
    return re.sub(r"\s+", " ", str(v)).strip()


def digitos(s):
    return re.sub(r"\D", "", s or "")


def para_data(v):
    """Retorna date ou None (inválida) - aceita datetime, serial Excel, DD/MM/AAAA, AAAA-MM-DD, MM/DD/AAAA."""
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    if isinstance(v, (int, float)) and 1000 < v < 80000:
        return dt.date(1899, 12, 30) + dt.timedelta(days=int(v))
    s = txt(v).split(" ")[0]
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        a, mth, d = map(int, m.groups())
    else:
        m = re.fullmatch(r"(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})", s)
        if not m:
            m8 = re.fullmatch(r"(\d{2})(\d{2})(\d{4})", s)
            if not m8:
                return None
            m = m8
        d, mth, a = map(int, m.groups())
        if a < 100:
            a += 2000 if a <= HOJE.year % 100 else 1900
        if mth > 12 and d <= 12:
            d, mth = mth, d
    try:
        return dt.date(a, mth, d)
    except ValueError:
        return None


def cpf_valido(cpf):
    cpf = digitos(cpf)
    if len(cpf) != 11:
        return False
    def dv(digs, pesos):
        r = 11 - (sum(int(d) * p for d, p in zip(digs, pesos)) % 11)
        return 0 if r >= 10 else r
    return dv(cpf[:9], range(10, 1, -1)) == int(cpf[9]) and dv(cpf[:10], range(11, 1, -1)) == int(cpf[10])


def cgc_valido(cgc):
    cgc = digitos(cgc)
    if len(cgc) == 8:
        j = 0
        for i, d in enumerate(cgc[:7], start=1):
            a = int(d) * (2 if i % 2 else 1)
            j += (a // 10 + a % 10) if a > 9 else a
        return (10 - j % 10 if j % 10 else 0) == int(cgc[7])
    if len(cgc) == 14:
        def dv(digs, pesos):
            r = sum(int(d) * p for d, p in zip(digs, pesos)) % 11
            return 11 - r if r > 1 else 0
        return dv(cgc[:12], [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) == int(cgc[12]) and \
            dv(cgc[:13], [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) == int(cgc[13])
    return False


def pis_valido(pis):
    pis = digitos(pis)
    if len(pis) != 11 or int(pis) == 0:
        return False
    r = sum(int(pis[i]) * p for i, p in enumerate([3, 2, 9, 8, 7, 6, 5, 4, 3, 2])) % 11
    dv = 11 - r if r else 0
    return (0 if dv in (10, 11) else dv) == int(pis[10])


def idade(d):
    if not d:
        return None
    return HOJE.year - d.year - ((HOJE.month, HOJE.day) < (d.month, d.day))


def abreviado(n):
    return any(len(p) == 1 and p.isalpha() for p in (n or "").split(" "))


def eh_filho(p):
    return p.startswith("FILHO") or p.startswith("FILHA")


def eh_irmao(p):
    return p.startswith("IRMA") or p.startswith("IRMAO")


def ler_fonte(caminho):
    """Lê a primeira aba que tiver cabeçalho com NOME e CPF (ou NOME e data de nascimento). Retorna (linhas como dict, colunas mapeadas, params)."""
    wb = openpyxl.load_workbook(caminho, read_only=True, data_only=True)
    params = {}
    if "Criticador" in wb.sheetnames:
        ws = wb["Criticador"]
        for r in ws.iter_rows(min_row=1, max_row=6, values_only=True):
            if r and len(r) > 2 and isinstance(r[1], str):
                params[chave(r[1])] = r[2]
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        for hi, r in enumerate(rows[:30]):
            ks = [chave(c) for c in r]
            # cabeçalho = NOME + CPF; sem CPF (relação de fatura), aceita NOME + data de nascimento — o CPF
            # ausente vira crítica "CPF não informado" em todas as linhas.
            if "NOME" in ks and ("CPF" in ks or any(ALIAS.get(k) == "NASCIMENTO" for k in ks)):
                mapa = {i: ALIAS[k] for i, k in enumerate(ks) if k in ALIAS}
                out = []
                for rr in rows[hi + 1:]:
                    if not rr or not any(c not in (None, "") for c in rr):
                        continue
                    reg = {c: "" for c in COLS}
                    bruto = {}
                    for i, c in mapa.items():
                        v = rr[i] if i < len(rr) else None
                        bruto[c] = v
                        reg[c] = txt(v)
                    reg["_bruto"] = bruto
                    out.append(reg)
                return out, sorted(set(mapa.values()), key=COLS.index), params, ws.title
    raise SystemExit(f"Nenhuma aba com cabeçalho NOME/CPF (ou NOME/NASCIMENTO) em {caminho}")


def preparar(regs, notas):
    n_ph = n_her = n_ec = n_tel55 = n_ddd = n_ddd0 = 0
    for i, r in enumerate(regs, start=1):
        r["Linha"] = i
        r["PARENTESCO"] = chave(r["PARENTESCO"])
        for c, _, _ in OBRIG:
            if chave(r[c]) in PLACEHOLDER:
                r[c] = ""
                n_ph += 1
        for c in DATAS:
            if r[c]:
                d = para_data(r["_bruto"].get(c, r[c]))
                r["_d_" + c] = d
                r[c] = d.strftime("%d/%m/%Y") if d else r[c]
        # Telefone / DDD (item 8)
        tel = digitos(r["TELEFONE"]).lstrip("0")
        ddd = digitos(r["DDD"])
        if len(tel) in (12, 13) and tel.startswith("55"):
            tel = tel[2:]
            n_tel55 += 1
        if len(tel) in (10, 11):
            pre = tel[:2]
            if not ddd or ddd.rstrip("0") == pre or ddd == pre:
                if not ddd:
                    n_ddd += 1
                ddd, tel = pre, tel[2:]
        if len(ddd) == 3 and ddd.endswith("0"):
            ddd = ddd[:2]
            n_ddd0 += 1
        r["TELEFONE"], r["DDD"] = tel, ddd
        for c in ("CPF", "PIS"):
            if r[c] and digitos(r[c]):
                r[c] = digitos(r[c]).zfill(11)
        if r["CEP"] and digitos(r["CEP"]):
            r["CEP"] = digitos(r["CEP"]).zfill(8)
    tit = {r["MATRICULA FUNCIONARIO"]: r for r in regs if r["PARENTESCO"] == "TITULAR" and r["MATRICULA FUNCIONARIO"]}
    for r in regs:
        if r["PARENTESCO"] != "TITULAR" and r["MATRICULA FUNCIONARIO"] in tit:
            t = tit[r["MATRICULA FUNCIONARIO"]]
            for c in HERANCA:
                if not r[c] and t[c]:
                    r[c] = t[c]
                    n_her += 1
        if eh_filho(r["PARENTESCO"]) and not r["ESTADO CIVIL"]:
            r["ESTADO CIVIL"] = "SOLTEIRO"
            n_ec += 1
        d = r.get("_d_NASCIMENTO")
        r["_idade"] = idade(d)
        if d:
            r["IDADE"] = str(r["_idade"])
    if n_ph:
        notas.append(f"{n_ph} valor(es)-placeholder (ex. 'N INFORMADO') em campo obrigatório foram apagados e tratados como ausentes.")
    if n_tel55:
        notas.append(f"{n_tel55} telefone(s) vieram com o código do país (55) na frente; o 55 foi removido antes de separar o DDD.")
    if n_ddd:
        notas.append(f"DDD estava vazio e embutido no TELEFONE em {n_ddd} linha(s): separado para a coluna DDD (sem duplicar no telefone).")
    if n_ddd0:
        notas.append(f"{n_ddd0} DDD(s) com 3 dígitos terminando em 0 foram corrigidos para 2 dígitos.")
    if n_her:
        notas.append(f"Herança titular→dependente (mesma matrícula) aplicada em {n_her} campo(s) de CNPJ/empresa/plano/endereço.")
    if n_ec:
        notas.append(f"Estado civil de {n_ec} filho(s) sem valor preenchido como SOLTEIRO (não gera crítica).")
    return tit


def criticar(regs, tit, presentes, idade_limite, notas):
    crit = []
    add = lambda r, m, cat: crit.append((r["Linha"], r["NOME"], m, cat))
    ausentes_estrut = [c for c, _, _ in OBRIG if c not in presentes]
    if ausentes_estrut:
        notas.append("Campos inexistentes na fonte (ficam em branco e não são criticados): " + ", ".join(ausentes_estrut) + ".")
    matriculas_vazias = sum(1 for r in regs if not r["MATRICULA FUNCIONARIO"]) >= 0.9 * len(regs)
    cpfs = Counter(digitos(r["CPF"]) for r in regs if digitos(r["CPF"]))
    rgs = Counter(digitos(r["RG"]) or r["RG"] for r in regs if r["RG"])
    mat_tit = Counter(r["MATRICULA FUNCIONARIO"] for r in regs if r["PARENTESCO"] == "TITULAR" and r["MATRICULA FUNCIONARIO"])
    conj = Counter(r["MATRICULA FUNCIONARIO"] for r in regs if r["PARENTESCO"] in CONJ)
    tits = defaultdict(list)
    for r in regs:
        if r["PARENTESCO"] == "TITULAR" and r["MATRICULA FUNCIONARIO"]:
            tits[r["MATRICULA FUNCIONARIO"]].append(r)
    for r in regs:
        p = r["PARENTESCO"]
        titular = p == "TITULAR"
        for c, m, so_tit in OBRIG:
            if c in presentes and not r[c] and (titular or not so_tit):
                add(r, m, "Obrigatório ausente")
        if r["NASCIMENTO"] and not r.get("_d_NASCIMENTO"):
            add(r, "Data de nascimento inválida", "Formato inválido")
        if r["CPF"] and not cpf_valido(r["CPF"]):
            add(r, "CPF inválido", "Formato inválido")
        if titular and r["TELEFONE"] and not (8 <= len(r["TELEFONE"]) <= 9):
            add(r, "Telefone fora do padrão", "Formato inválido")
        if abreviado(r["NOME"]):
            add(r, "Nome abreviado", "Formato inválido")
        if abreviado(r["NOME MAE"]):
            add(r, "Nome da mãe abreviado", "Formato inválido")
        if titular and r["PIS"] and not pis_valido(r["PIS"]):
            add(r, "PIS/PASEP inválido", "Formato inválido")
        if r["_idade"] is not None and r["_idade"] >= idade_limite:
            add(r, "Idade acima do limite permitido", "Formato inválido")
        if r["CNPJ"] and len(digitos(r["CNPJ"])) in (8, 14) and not cgc_valido(r["CNPJ"]):
            add(r, "CNPJ/CGC inválido", "Formato inválido")
        if "VINCULO EMPREGATICIO" in presentes and r["VINCULO EMPREGATICIO"] and chave(r["VINCULO EMPREGATICIO"]) != "CLT":
            add(r, "Vínculo empregatício inválido", "Formato inválido")
        if titular and not matriculas_vazias and mat_tit[r["MATRICULA FUNCIONARIO"]] > 1:
            add(r, "Matrícula Duplicada", "Duplicidade")
        if digitos(r["CPF"]) and cpfs[digitos(r["CPF"])] > 1:
            add(r, "CPF em duplicidade", "Duplicidade")
        if r["RG"] and rgs[digitos(r["RG"]) or r["RG"]] > 1:
            add(r, "RG duplicado", "Duplicidade")
        if p in CONJ and conj[r["MATRICULA FUNCIONARIO"]] > 1:
            add(r, "Cônjuge/Companheiro em duplicidade", "Duplicidade")
        if not titular:
            ts = tits.get(r["MATRICULA FUNCIONARIO"], [])  # como o Power Query: compara com TODOS os titulares da matrícula
            if r["MATRICULA FUNCIONARIO"] and not ts:
                add(r, "Dependente sem titular", "Consistência")
            if ts:
                if any(r["PLANO"] != t["PLANO"] for t in ts):
                    add(r, "Plano do dependente diferente do titular", "Consistência")
                if r["NOME MAE"] and any(r["NOME MAE"] == t["NOME MAE"] for t in ts) and not eh_irmao(p):
                    add(r, "Nome mãe do dependente igual ao do titular", "Consistência")
                if eh_filho(p) and r["_idade"] is not None and any(
                        t["_idade"] is not None and t["_idade"] - r["_idade"] <= 13 for t in ts):
                    add(r, "Filho com idade incompatível do titular", "Consistência")
            if eh_filho(p) and r["_idade"] is not None and r["_idade"] >= 24:
                add(r, "Filho com 24 anos ou mais", "Consistência")
            if p in CONJ and r["_idade"] is not None and r["_idade"] <= 14:
                add(r, "Cônjuge/Companheiro com idade incompatível", "Consistência")
    if matriculas_vazias:
        notas.append("Matrícula vazia em praticamente toda a base: checagem de Matrícula Duplicada não aplicada.")
    crit.sort(key=lambda x: x[0])
    return crit


def ordenar(regs):
    def k(r):
        m = r["MATRICULA FUNCIONARIO"]
        return (digitos(r["CNPJ"]) or r["CNPJ"], (0, int(m)) if m.isdigit() else (1, m),
                0 if r["PARENTESCO"] == "TITULAR" else 1, r["Linha"])
    return sorted(regs, key=k)


def gerar(regs, crit, notas, saida, titulo):
    wb = openpyxl.Workbook()
    navy = PatternFill("solid", fgColor=NAVY)
    thin = Side(style="thin", color="BFBFBF")
    # ---- Resumo
    ws = wb.active
    ws.title = "Resumo"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    for c in "BCD":
        ws.column_dimensions[c].width = 34
    for r in range(2, 9):
        for c in "BCD":
            ws[f"{c}{r}"].fill = navy
    ws["B2"] = "Relatório de Crítica de Layout"
    ws["B2"].font = Font(name="Arial", size=18, bold=True, color="FFFFFF")
    ws["B3"] = f"Gerado em {HOJE.strftime('%d/%m/%Y')}" + (f"  •  {titulo}" if titulo else "")
    ws["B3"].font = Font(name="Arial", size=10, color="D9D9D9")
    kpis = [(len(regs), "Linhas analisadas"), (len(crit), "Total de críticas"),
            (sum(1 for r in regs if r["PARENTESCO"] == "TITULAR"), "Titulares")]
    for c, (v, lbl) in zip("BCD", kpis):
        ws[f"{c}5"] = v
        ws[f"{c}5"].font = Font(name="Arial", size=22, bold=True, color="FFFFFF")
        ws[f"{c}6"] = lbl
        ws[f"{c}6"].font = Font(name="Arial", size=10, bold=True, color="D9D9D9")
        for rr in (5, 6):
            ws[f"{c}{rr}"].alignment = Alignment(horizontal="center")
    row = 10
    ws[f"B{row}"] = "Críticas por tipo"
    ws[f"B{row}"].font = Font(name="Arial", size=12, bold=True, color=NAVY)
    row += 1
    for c, h in zip("BCD", ["Tipo de crítica", "Qtd", ""]):
        ws[f"{c}{row}"] = h
        ws[f"{c}{row}"].fill = navy
        ws[f"{c}{row}"].font = Font(name="Arial", size=11, bold=True, color="FFFFFF")
    cat_de = {m: cat for _, _, m, cat in crit}
    tipos = Counter(m for _, _, m, _ in crit).most_common()
    mx = tipos[0][1] if tipos else 1
    for m, q in tipos:
        row += 1
        bg, fg = CAT_COR[cat_de[m]]
        ws[f"B{row}"] = m
        ws[f"C{row}"] = q
        ws[f"D{row}"] = "█" * max(1, round(q / mx * 20))
        ws[f"B{row}"].font = ws[f"C{row}"].font = Font(name="Arial", size=10)
        ws[f"D{row}"].font = Font(name="Arial", size=10, color=fg)
        ws[f"D{row}"].fill = PatternFill("solid", fgColor="F2F2F2")
    row += 2
    ws[f"B{row}"] = "Legenda"
    ws[f"B{row}"].font = Font(name="Arial", size=12, bold=True, color=NAVY)
    for cat, (bg, fg) in CAT_COR.items():
        row += 1
        ws[f"B{row}"] = cat
        ws[f"B{row}"].fill = PatternFill("solid", fgColor=bg)
        ws[f"B{row}"].font = Font(name="Arial", size=10, bold=True, color=fg)
    row += 2
    ws[f"B{row}"] = "METODOLOGIA E PREMISSAS"
    ws[f"B{row}"].font = Font(name="Arial", size=12, bold=True, color=NAVY)
    for n in notas:
        row += 1
        ws[f"B{row}"] = "• " + n
        ws[f"B{row}"].font = Font(name="Arial", size=10)
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(f"B{row}:D{row}")
        ws.row_dimensions[row].height = 15 * max(1, len(n) // 95 + 1)
    # ---- Dados
    wd = wb.create_sheet("Dados")
    for j, c in enumerate(COLS, 1):
        cell = wd.cell(1, j, c)
        cell.fill = navy
        cell.font = Font(name="Arial", size=11, bold=True, color="FFFFFF")
    marcar = defaultdict(set)
    for ln, _, m, cat in crit:
        if cat == "Obrigatório ausente":
            marcar[ln].add(MSG_COL[m])
    red = PatternFill("solid", fgColor="F5B7B1")
    fnt, fred = Font(name="Arial", size=9), Font(name="Arial", size=9, bold=True, color="943126")
    larg = [len(c) for c in COLS]
    for i, r in enumerate(ordenar(regs), start=2):
        for j, c in enumerate(COLS, 1):
            v = r[c]
            cell = wd.cell(i, j, v if v != "" else None)
            cell.number_format = "@"
            if c in marcar[r["Linha"]]:
                cell.fill, cell.font = red, fred
            else:
                cell.font = fnt
            larg[j - 1] = max(larg[j - 1], len(v) * 0.9)
    for j, w in enumerate(larg, 1):
        wd.column_dimensions[get_column_letter(j)].width = min(45, w + 2)
    wd.auto_filter.ref = f"A1:{get_column_letter(len(COLS))}{len(regs) + 1}"
    # ---- Relatório de Crítica
    wr = wb.create_sheet("Relatório de Crítica")
    for j, h in enumerate(["Linha", "NOME", "Crítica", "Categoria"], 1):
        c = wr.cell(1, j, h)
        c.fill, c.font = navy, Font(name="Arial", size=11, bold=True, color="FFFFFF")
    for i, (ln, nome, m, cat) in enumerate(crit, start=2):
        bg, fg = CAT_COR[cat]
        for j, v in enumerate([ln, nome, m, cat], 1):
            c = wr.cell(i, j, v)
            c.fill = PatternFill("solid", fgColor=bg)
            c.font = Font(name="Arial", size=10, color=fg)
    for col, w in zip("ABCD", [8, 42, 46, 22]):
        wr.column_dimensions[col].width = w
    wr.freeze_panes = "A2"
    wr.auto_filter.ref = f"A1:D{len(crit) + 1}"
    wb.save(saida)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--entrada", nargs="+", required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--titulo", default="")
    ap.add_argument("--json", default="")
    a = ap.parse_args()
    regs, presentes, params, notas = [], set(), {}, []
    for f in a.entrada:
        r, p, prm, aba = ler_fonte(f)
        regs += r
        presentes |= set(p)
        params.update(prm)
        notas.append(f"Fonte: {f.split('/')[-1]} (aba '{aba}'), {len(r)} linha(s).")
    notas.append("Sem Base Complementar: validação feita só com o arquivo de origem.")
    lim = params.get("IDADE LIMITE") or 100
    try:
        lim = int(lim)
    except (TypeError, ValueError):
        lim = 100
    notas.append(f"Idade calculada na data de hoje ({HOJE.strftime('%d/%m/%Y')}); limite de idade usado: {lim}.")
    tit = preparar(regs, notas)
    if not tit:
        notas.append("Nenhuma linha com PARENTESCO = TITULAR: as regras só-titular (cargo, admissão, endereço, contato, PIS) "
                     "não se aplicam e todas as linhas com matrícula aparecem como 'Dependente sem titular' — mesmo comportamento "
                     "do botão 'Levantar críticas' da ferramenta. Preencher o PARENTESCO resolve.")
    notas.append("Peso/Altura e Vínculo empregatício não foram criticados (planos PME não identificados / campo vazio na fonte).")
    crit = criticar(regs, tit, presentes, lim, notas)
    notas.append("Datas padronizadas como texto DD/MM/AAAA. Linhas ordenadas por CNPJ → matrícula → titular antes dos dependentes.")
    notas.append("Células em vermelho na aba Dados = campo obrigatório ausente (mesma cor da categoria 'Obrigatório ausente').")
    gerar(regs, crit, notas, a.saida, a.titulo)
    res = {"linhas": len(regs), "titulares": sum(1 for r in regs if r["PARENTESCO"] == "TITULAR"), "criticas": len(crit),
           "por_tipo": Counter(m for _, _, m, _ in crit).most_common(),
           "por_categoria": Counter(c for *_, c in crit).most_common(), "saida": a.saida}
    if a.json:
        json.dump(res, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    main()
