# Vigia SDI/PX — documentação para o Carregador do Futuro

Última atualização: 12/11/2026 (seção 9: regras de operação pelo chat; tempos medidos do lote)

## 1. O que é

O **vigia** é um programa que fica ligado no computador do Julio e executa ações na Plataforma Xipp (PX) e no SDI quando o Carregador do Futuro pede. O Claude (Cowork) não tem terminal no computador do Julio, só lê e grava arquivos nas pastas conectadas. Por isso a comunicação é por **arquivos numa fila**:

1. O Carregador grava um **pedido** (arquivo `.json`) na pasta `_fila`.
2. O vigia vê o pedido, executa a ação (um script Python que dirige o navegador) e grava o **resultado** num arquivo `.status.json`.
3. O Carregador lê o resultado e segue o trabalho.

Pasta de tudo: `C:\Users\JulioCesardaSilvaAlv\Downloads\Claude\Agente Claude\_sistema\`

## 2. Ações disponíveis

| Ação | O que faz | Campos obrigatórios | Situação |
|---|---|---|---|
| `baixar_base_sdi` | Baixa a base de beneficiários do SDI (grupo financeiro + contrato) e salva em `<pasta do cliente>\Arquivo Origem` | `grupo`, `contrato`, `pasta` | Validada de ponta a ponta no PC do Julio (Grupo Caixa CNP, contrato 511312: 1.100 linhas, ~3 min) |
| `consultar_carga_api_bradesco` | Procura, em "Carga de Dados", o arquivo enviado por API pelo código do contrato e devolve Etapa, Status e as críticas | `contrato` | **Validada na tela real** em 28/10/2026 (72222: 18 arquivos, críticas lidas). Filtro de período de 3 dias validado em 29/10/2026 (72222: 3 arquivos de 26 a 28/10; 94244 Dental: nenhum, 108 de 108 lidos). O resultado traz `cobertura` e `periodo` |
| `carregar_arquivo_sdi` | **Altera dados.** Carrega um arquivo em "Carga de Dados > Novo Upload": preenche Tipo de arquivo, Grupo financeiro, (Contrato/Subcontrato), Operadora e Competência, anexa e clica em Upload | `tipo`, `grupo`, `operadora`, `competencia`, `arquivo` | Escrita em 29/10/2026 a partir do vídeo e testada em tela simulada. **Falta o 1º teste real** (primeiro em simulação, depois com `enviar`) |
| `atribuir_fila_atendimento` | **Altera dados.** Transfere um atendimento da PX para outra fila: Painéis → card Dados Operacionais ou Dados de Sinistro (Atendimentos Abertos) → protocolo → "Atribuir para" → Fila de Atendimento (e Usuário, opcional) → Confirmar | `fila` + `protocolo` ou `protocolos` | Simulação **validada na PX real** em 11/11/2026 (609451: achado no card Dados Operacionais, fila Faturamento escolhida e cancelado; conferido que nada mudou). Na janela, "Fila de Atendimento" é lista de seleção nativa. Envio real validado em 11/11/2026: 609486, 609484, 609483, 609482, 609481, 609480 e 609479 → Faturamento (um pedido por número, ~2,5–3,5 min cada; a PX tira o atendimento da tela após confirmar, e ele some da visão do usuário). **Modo lote (`protocolos`) validado em 11/11/2026**: 609452 a 609446 (7) → Faturamento em 8 min 46 s (~1,5 min para entrar na PX + ~65 s por atendimento), 7/7 transferidos |

Quando uma ação for dada como validada, ela passa a ser confiável para uso automático. Enquanto estiver como "falta validar", o resultado "não encontrado" **não** prova que o arquivo não existe: conferir manualmente.

## 3. Como o Carregador pede uma ação

### 3.1 Antes de pedir: conferir se o vigia está vivo

O vigia grava a data/hora do último sinal de vida em `_fila\vigia_ativo.txt` (a cada ~5 s quando está parado; durante uma execução o arquivo não é atualizado). Se o arquivo tiver mais de uns 20 minutos, o vigia provavelmente não está rodando. Nesse caso avisar o Julio (ver seção 7) em vez de ficar esperando.

### 3.2 Gravar o pedido

Arquivo JSON em UTF-8: `_fila\<id>.json`. O `id` deve ser único (sugestão: `<chamado>_<AAAAMMDD_HHMM>`). O nome do arquivo é o próprio `id`.

**Baixar a base do SDI**

```json
{
  "id": "488167_20261028_1530",
  "acao": "baixar_base_sdi",
  "grupo": "Grupo Caixa CNP",
  "contrato": "511312",
  "pasta": "C:\\Users\\JulioCesardaSilvaAlv\\Downloads\\Claude\\Carga SDI\\(#488167) Atualização de base - Grupo caixa - Odonto Empresas",
  "solicitante": "Julio Alves"
}
```

- `grupo`: como aparece no filtro "Grupo Financeiro" do SDI.
- `contrato`: número do contrato como aparece na opção do filtro "Contrato" (ex.: 511312 para "Odonto - Odonto Empresas - 511312").
- `pasta`: pasta do cliente, a que contém `Arquivo Origem`. A base vai para `<pasta>\Arquivo Origem\RELATORIO_BENEFICIARIOS_<data>.xlsx`.
- `solicitante`: opcional. Nome que o script procura na coluna "Solicitado por" de "Emissão de Relatórios". Padrão: Julio Alves.
- Sem o campo `acao`, o vigia assume `baixar_base_sdi`.

**Consultar carga por API (Bradesco)**

```json
{
  "id": "carga_92934_20261028",
  "acao": "consultar_carga_api_bradesco",
  "contrato": "92934"
}
```

- `contrato`: código do contrato que aparece no nome do arquivo (ex.: `20261027_200158_PC_74109.json` tem o código 74109).
- Período: por padrão a busca filtra **de hoje − 3 dias até hoje** (seletor "Personalizado" + calendário). `dias` muda a janela (ex.: `"dias": 10`); `sem_filtro_data` (`true`) mantém o padrão da tela (últimos 30 dias). O resultado traz `periodo` com `inicio`, `fim`, `aplicado` e `conferido_na_rede` (a lista foi pedida ao servidor com essas datas, por operadora; a tela manda o fim como o dia seguinte, ex.: até 29/10 vira `endDate=2026-10-30`). Se o filtro não pegar, a busca segue nos 30 dias e `periodo.aviso` explica.
- Opcionais: `operadora` (padrão `Bradesco`, cobre as 3 opções: Bradesco Dental, Bradesco Saúde S/A e Bradesco Saúde - Operadora de Planos S/A; pode ser o nome exato de uma delas para reduzir o tempo), `tipo` (padrão `Posição Cadastral`), `max_paginas` (padrão 300), `todos` (`true` para não parar no primeiro arquivo encontrado), `sem_filtro_nome` (`true` para não usar o filtro "Nome do arquivo"), `discover` (`true` grava capturas de tela em `sdi_debug`, para diagnóstico).

**Carregar arquivo no SDI (altera dados)**

```json
{
  "id": "upload_prio_20261029_1600",
  "acao": "carregar_arquivo_sdi",
  "tipo": "Posição Cadastral",
  "grupo": "Prio",
  "operadora": "Bradesco Saude S/A",
  "competencia": "10/2026",
  "arquivo": "C:\\Users\\JulioCesardaSilvaAlv\\Downloads\\20261029_PC_Prio_Bradesco_Saude.txt",
  "enviar": true
}
```

- **Sem `"enviar": true` é só simulação**: o script preenche tudo e anexa o arquivo, mas não clica em Upload. Primeiro teste de cada combinação nova: rodar sem `enviar`.
- `tipo`: como aparece na lista (ex.: `Posição Cadastral`, `Fatura Técnica`). `grupo` e `operadora`: nome exato da opção (ex.: `Bradesco Saude S/A`, não só "Bradesco Saude"). Se o valor bater com mais de uma opção, o script para e lista as opções vistas; não escolhe no chute.
- `competencia`: `MM/AAAA`. `arquivo`: caminho completo no PC do Julio (o arquivo precisa estar numa pasta do PC).
- Opcionais: `contrato`, `subcontrato` (no vídeo ficaram em branco), `permitir_repetido` (`true` para reenviar um arquivo cujo nome já aparece na lista; sem isso o script recusa), `discover`.
- Resultado: `enviado` (true/false), `mensagem_tela` (o aviso verde "Os arquivos foram enviados com sucesso"), `na_lista` (protocolo e linha da lista, se já apareceu) e, quando houver, `ja_na_lista`.

**Transferir atendimento para outra fila (altera dados)**

```json
{
  "id": "fila_609487_20261111_2200",
  "acao": "atribuir_fila_atendimento",
  "protocolo": "609487",
  "fila": "Faturamento",
  "confirmar": true
}
```

- **Sem `"confirmar": true` é só simulação**: acha o atendimento, abre "Atribuir para", escolhe a fila e clica em Cancelar.
- **Vários atendimentos de uma vez (recomendado):** use `"protocolos": "609486,609484,609483"` em vez de `protocolo`. O script entra na PX e carrega o painel **uma vez só** e depois vai direto na lista do card para cada número (~65 s por atendimento na PX real, mais ~1,5 min para entrar; contra ~2,5–3,5 min com um pedido por número). Um erro num número não para os outros; o resultado traz `total`, `atribuidos`, `falhas`, `segundos_total` e `itens` (um bloco por protocolo, com os campos abaixo).
- `protocolo`: número da coluna Protocolo (campo `protocol_code`). O script procura nos abertos de **Dados Operacionais** e, se não achar, de **Dados de Sinistro**. `painel` (`operacionais`/`sinistro`) restringe a um card.
- `fila`: nome exato da Fila de Atendimento (há 134 na PX). Se o nome bater com mais de uma opção (ex.: `Faturamento` x `Faturamento Small`, ou `geral` x `Geral`), o script para e lista as opções. `usuario` (opcional): usuário da fila de destino.
- Se o atendimento já estiver na fila pedida, não faz nada. Depois de Confirmar, o script **sempre relê o atendimento numa página nova** e decide pela fila de verdade. O aviso **"Campos inválidos: Assunto, Solicitação"** (atendimento sem esses campos) aparece e a janela fica aberta, **mas a PX transfere mesmo assim** (confirmado pelo Julio em 11/11/2026): o script não cancela, devolve o aviso em `aviso_tela` e marca `atribuido` conforme a fila relida.
- Resultado: `atribuido` (true/false), `painel`, `titulo`, `fila_antes`, `fila_escolhida`, `fila_depois` (relida numa página nova depois de confirmar) e, se houver, `aviso_tela`.

### 3.3 Esperar o resultado

Listar a pasta `_fila` a cada ~30 s até aparecer `<id>.status.json` com `estado` diferente de `executando`. Prazos observados: baixar a base, 3 a 4 minutos; consulta de carga por API, de alguns minutos até ~15 minutos (a varredura de todas as páginas das 3 operadoras é lenta; usar `operadora` exata acelera). Se passar de ~40 minutos sem resposta, tratar como falha.

### 3.4 Ler o resultado

`<id>.status.json`:

```json
{
  "estado": "ok",
  "acao": "baixar_base_sdi",
  "pedido": { "grupo": "...", "contrato": "..." },
  "inicio": "2026-10-28T14:44:27",
  "fim": "2026-10-28T14:47:05",
  "arquivo": "C:\\...\\Arquivo Origem\\RELATORIO_BENEFICIARIOS_20261028144640.xlsx"
}
```

- `estado`: `executando`, `ok` ou `erro`.
- `arquivo`: (baixar_base_sdi) caminho da base baixada. Se o caminho vier com acento corrompido, listar a pasta `Arquivo Origem` e pegar o `RELATORIO_BENEFICIARIOS_*.xlsx` mais recente.
- `resultado`: (consultar_carga_api_bradesco) objeto com o que foi encontrado:

```json
"resultado": {
  "contrato": "72222",
  "tipo_arquivo": "Posição Cadastral",
  "operadoras_consultadas": ["Bradesco Dental", "..."],
  "paginas_varridas": 35,
  "encontrados": [
    {
      "protocolo": "158099",
      "data_hora": "27/10/2026 17:01",
      "criado_por": "API",
      "arquivo": "20261027_200107_PC_72222.json",
      "operadora": "Bradesco Saúde S.A",
      "etapa": "Processando",
      "status": "Finalizado com críticas",
      "criticas": {
        "total_erros": 6,
        "itens": [ { "data": "27/10/2026", "mensagem": "Não foi possível encontrar o plano ...", "linha": 0 } ]
      }
    }
  ]
}
```

  `cobertura`: uma entrada por operadora com `lidos` (arquivos distintos lidos), `total_tela` (total do rodapé) e `completa`. Quando `encontrados` vem vazio, vem também `varredura_completa`: só `true` prova que o arquivo não está na tela; com `false`, a `observacao` começa com "NAO ENCONTRADO, MAS A VARREDURA FICOU INCOMPLETA" e é preciso conferir manualmente.

  `criticas` só aparece quando o status tem críticas. Se `encontrados` vier vazio, vem também `observacao` (nenhum arquivo nas operadoras consultadas, no período do filtro; padrão: últimos 3 dias).
- `mensagem`: quando `estado` é `erro`, o motivo (última linha "ERRO:" do script). O texto completo está em `<id>.log.txt`.

Os pedidos já processados vão para `_fila\feito`. Nada é apagado.

### 3.5 Validar antes de usar

- Base do SDI: conferir que a coluna Contrato da base bate com o contrato pedido e que o número de linhas faz sentido. O script já valida e registra no log.
- Consulta de carga: usar `status` e `etapa` exatamente como a tela mostra. Não interpretar além disso.

## 4. Componentes (arquivos em `_sistema`)

| Arquivo | Função |
|---|---|
| `sdi_vigia.py` | O vigia: lê a fila, executa a ação, grava o status. Só roda uma cópia por vez (trava na porta local 47653). |
| `acoes.json` | Registro das ações (script, campos obrigatórios, argumentos, prazo). Relido a cada pedido: **ação nova não exige reiniciar o vigia**. |
| `sdi_baixar_base.py` | Ação `baixar_base_sdi` (e funções de login e navegação reutilizadas pelas outras ações). |
| `px_consulta_carga_api.py` | Ação `consultar_carga_api_bradesco`. |
| `iniciar_vigia.bat` | Abre o vigia numa janela (para acompanhar). |
| `instalar_vigia_automatico.bat` | Roda uma vez. Cria o atalho na inicialização do Windows e liga o vigia agora, sem janela (`vigia_oculto.vbs`). |
| `baixar_base.bat` | Roda a baixa do SDI na mão, perguntando grupo, contrato e pasta (uso manual). |
| `credenciais.env` | Login e senha da PX. **Nunca ler nem exibir.** |
| `.sdi_sessao\state.json` | Sessão salva da PX (cookies). Nunca ler nem compartilhar. |
| `_fila\` | Pedidos, status, logs e `vigia_ativo.txt`. |
| `sdi_debug\` | Capturas de tela e HTML de diagnóstico (só com `discover`). |

## 5. Como cada ação funciona por dentro

**baixar_base_sdi**: login na PX (sessão salva) → menu "SDI - Movimentação Cadastral" → card "Pesquisa de Beneficiário" → filtros Grupo Financeiro e Contrato → Pesquisar → "Exportar Base de Beneficiários" → Enviar → "Ir para Emissão de Relatórios" → localiza a linha do grupo, com "Solicitado por" = solicitante e solicitação recente → espera "Emitido com Sucesso" → baixa → salva em `Arquivo Origem` → valida o contrato e conta as linhas.

**carregar_arquivo_sdi**: login → "SDI - Movimentação Cadastral" → "Carga de Dados" → procura o nome do arquivo na lista (se já existir e não houver `permitir_repetido`, para) → abre "Novo Upload" → Tipo de arquivo → Grupo financeiro → (Contrato, Subcontrato) → Operadora → Competência (calendário de mês) → "Carregar arquivos" (confere "1 Arquivos carregados") → **só com `enviar`**: Upload → espera "enviados com sucesso" → procura o arquivo na lista e devolve o protocolo.

**atribuir_fila_atendimento**: login → app "Automação Operacional" → menu "Painéis" → "Atendimentos Dados Operacionais e Dados Sinistro" → card "Dados Operacionais - (Atendimentos Abertos)" → pesquisa o protocolo (se não achar, volta e tenta "Dados de Sinistro - (Atendimentos Abertos)") → abre o atendimento (confere "(#protocolo)" no topo) → lê a fila atual → "Atribuir para" → Fila de Atendimento (+ Usuário) → **só com `confirmar`**: Confirmar → registra aviso, se houver ("Campos inválidos" não impede a troca) → relê a fila numa página nova.

**consultar_carga_api_bradesco**: login → menu "SDI - Movimentação Cadastral" → card "Carga de Dados" → filtro "Tipo de arquivo" (Posição Cadastral) → período "Personalizado" (calendário: hoje − 3 até hoje, OK) → filtro "Operadora" (para cada opção que contém "Bradesco") → procura o código do contrato no nome do arquivo (primeiro tenta o filtro "Nome do arquivo", depois passa as páginas, com 100 linhas por página) → lê Etapa e Status → se o status tiver "críticas", abre o ícone de crítica e lê "Total de erros" e cada mensagem. Só consulta, não altera nada.

## 6. Como criar uma ação nova

1. O Julio grava um vídeo fazendo a ação na PX e escreve na mensagem o que a ação faz, o que muda a cada uso, como saber que deu certo e se altera dados (o Claude só vê a imagem, não ouve o áudio).
2. O Claude escreve o script em Python (usando a sessão e as funções de login que já existem) e o grava em `_sistema`.
3. O Claude registra a ação em `acoes.json`. Exemplo:

```json
{
  "minha_acao": {
    "script": "meu_script.py",
    "obrigatorios": ["contrato"],
    "args": { "contrato": "--contrato" },
    "flags": { "discover": "--discover" },
    "timeout_min": 30
  }
}
```

4. Convenções do script: imprimir `RESULTADO_JSON: {...}` (uma linha, com `json.dumps(..., ensure_ascii=True)`) para ações que devolvem dados; para ações que geram arquivo, imprimir `Base salva em: <caminho>`. Erro: imprimir `ERRO: <motivo>` e sair com código 1.
5. Ações que **alteram dados** na PX exigem que o pedido traga exatamente o que será alterado, e o script não deve agir sem esses campos.

## 7. Quando algo dá errado

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| `vigia_ativo.txt` velho / pedido não é processado | Vigia não está rodando | Pedir ao Julio para abrir `iniciar_vigia.bat`, ou rodar `instalar_vigia_automatico.bat` (uma vez) para ele iniciar com o Windows |
| `erro` com "Sessão expirada" ou login/2FA | Sessão da PX caducou | Julio roda `python sdi_baixar_base.py --login`, digita o código e marca "Não perguntar novamente neste dispositivo" |
| `erro` "Pedido inválido: faltam campos…" | Pedido incompleto | Corrigir o pedido e gravar de novo com outro `id` |
| `erro` "Não achei '…' na tela do SDI" | O SDI mudou de tela ou está lento | Repetir uma vez; se persistir, pedir com `"discover": true` e olhar `sdi_debug` |
| `estado` fica `executando` por mais de ~40 min | Execução travada | Avisar o Julio; não reenviar em loop |
| Consulta de carga "não encontrado" | Arquivo fora do período (30 dias), operadora diferente, ou leitura da lista falhou | Rodar de novo com `operadora` exata e `discover`; conferir manualmente enquanto a ação não estiver validada |

Regra geral: em caso de erro, **não** tentar de novo em loop. Avisar o Julio com a mensagem do status e pedir a base ou a conferência manual.

## 8. Segurança e limites

- Nunca ler, copiar ou exibir `credenciais.env`, `state.json` ou senhas. Nada disso é necessário para pedir uma ação.
- O vigia só roda no computador do Julio e usa o login dele. Quem receber os scripts precisa de login próprio na PX/SDI, do próprio `credenciais.env` e da própria sessão, e deve informar seu nome em `solicitante`.
- O vigia executa uma ação por vez, na ordem em que os pedidos chegaram.
- Não ativar tarefas agendadas do Claude para isso. O vigia é um programa local do Julio.
- Nada é apagado: pedidos processados vão para `_fila\feito`.
- O Claude não consegue testar as ações na tela real a partir da nuvem (o código de dois fatores da PX só o Julio tem). A primeira execução de cada ação nova é um teste no PC do Julio e pode pedir ajustes.

## 9. Como o Claude deve operar pelo chat (regras do Julio, 12/11/2026)

Estas regras valem para qualquer conversa nova que use o vigia. Ler esta seção antes de mandar pedidos.

1. **Uma conferência só, no fim.** Mandar o pedido, dizer ao Julio o horário estimado de término e conferir **uma única vez**, nesse horário. Não acompanhar no meio (cada conferência gasta tokens; o processamento no PC não gasta).
2. **Estimar antes de mandar**, com os tempos medidos:
   - `atribuir_fila_atendimento` em lote: ~1,5 min para entrar + ~65 s por atendimento (7 ≈ 9 min).
   - `consultar_carga_api_bradesco`: ~3 a 4 min por operadora com críticas; ~6 min nas 3 operadoras.
   - `baixar_base_sdi`: ~2,5 min.
3. **Vários protocolos = um pedido só** (`protocolos`), nunca um pedido por número.
4. **Conferir pelo meio mais barato:** primeiro o `.status.json` (texto). Para atendimentos, o conector da PX (`helpdesk.ticket`, campo `protocol_code`) também serve; um atendimento que vai para uma fila fora da visão do Julio (ex.: Faturamento) **some** da busca, e isso é o sinal esperado de que foi transferido. Ler capturas de tela (`discover`) só quando der erro e o texto não bastar (imagem custa bem mais).
5. **Ações que alteram dados** (`carregar_arquivo_sdi`, `atribuir_fila_atendimento`): antes de mandar, registrar o estado atual (ex.: fila de cada atendimento pelo conector). Primeira vez de uma combinação nova: simulação.
6. **Ao gravar arquivos no PC, usar sempre um nome de origem novo** (ex.: `acoes_v7_1112.json`): reaproveitar o nome de um arquivo já enviado pode gravar uma versão antiga (aconteceu em 29/10).
7. **Para cancelar pedidos que ainda não começaram** (sem permissão de apagar): sobrescrever o `.json` na `_fila` com uma `acao` inexistente (ex.: `"cancelado_pelo_julio"`); o vigia registra erro e não mexe na PX. O pedido que já está executando não para.
