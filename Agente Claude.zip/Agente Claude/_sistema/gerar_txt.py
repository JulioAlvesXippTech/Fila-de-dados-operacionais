#!/usr/bin/env python3
"""Monta o TXT de orientacoes a partir de novos_atendimentos.json + resumos.json (resumos escritos pelo Claude).
Uso: python3 gerar_txt.py <novos_atendimentos.json> <resumos.json> <saida.txt>
resumos.json = {"<numero ou id>": {"resumo": "...", "sugestao": "1|2|3", "motivo": "por que"}} (string simples tambem aceita)"""
import json, re, sys
dados = json.load(open(sys.argv[1], encoding="utf-8"))
resumos = json.load(open(sys.argv[2], encoding="utf-8"))
IMG = re.compile(r"^image\d*(\.\w+)?$|\.(png|jpe?g|gif|bmp)$", re.I)
L = []
L.append("AGENTE DE ATENDIMENTOS - ORIENTAÇÕES PENDENTES")
L.append(f"Execução: {dados['execucao']} | Atendimentos no filtro: {dados['total_no_filtro']} | "
         f"Novos/atualizados nesta leitura: {len(dados['novos_ou_atualizados'])}")
L.append("Filtro: Dados Operacionais, status não dobrado, solicitante ≠ Xipp bot, responsável Julio Alves / Renan Silva / João Lourenço / sem responsável")
L.append("")
L.append("COMO RESPONDER: em cada atendimento, escreva depois de \"R:\" o número da opção e, se quiser, uma observação.")
L.append("  1 = Salvar arquivo(s) para validação/conversão no MANINHA (pasta Layouts)")
L.append("  2 = Salvar arquivo(s) para conversão no CARREGADOR DO FUTURO (pasta Carga SDI)")
L.append("  3 = Sem ação de arquivo agora (só acompanhar / aguardando terceiros)")
L.append("  Outro = descreva a orientação")
L.append("A linha \"Sugestão do Claude\" é só uma análise; vale o que você escrever em R: (pode responder \"ok\" para aceitar a sugestão).")
L.append("Nenhum arquivo foi baixado e nada foi alterado na plataforma.")
L.append("=" * 100)
ordem = {"Julio Alves": 0, "Renan Silva": 1, "João Lourenço": 2, "Sem responsável": 3}
for t in sorted(dados["novos_ou_atualizados"], key=lambda t: (ordem.get(t["responsavel"], 9), t["criado_em"][6:10] + t["criado_em"][3:5] + t["criado_em"][:2])):
    chave = t["numero"] if str(t["numero"]).startswith("HT") else str(t["id"])
    L.append("")
    L.append(f"[{chave}] Protocolo {t['protocolo']} - {t['titulo'].strip()}   ({'NOVO' if t['motivo']=='novo' else 'ATUALIZADO'})")
    L.append(f"  Responsável: {t['responsavel']} | Status: {t['status']} | Solicitante: {t['solicitante']} | Aberto em: {t['criado_em']}")
    extra = " / ".join(x for x in [t["assunto"], t["solicitacao"], t["contrato"]] if x)
    if extra:
        L.append(f"  Assunto/Contrato: {extra}")
    L.append(f"  Link: {t['link']}")
    r = resumos.get(chave, {})
    if isinstance(r, str):
        r = {"resumo": r}
    L.append(f"  O que foi solicitado: {r.get('resumo') or t['descricao'][:400] or '(sem descrição)'}")
    ci = t.get("contrato_info")
    if ci and not ci.get("erro"):
        if ci.get("identificado_pelo_texto"):
            L.append("  (contrato não vinculado no atendimento; identificado pelo número citado no texto - confira)")
        L.append(f"  Contrato: {ci['contrato']} | Operadora: {ci['operadora']} | Benefício: {ci['beneficio']} | Status: {ci['status']}")
        L.append(f"    CNPJ: {ci['cnpj']} | Início: {ci['inicio']}{' | Fim: ' + ci['fim'] if ci['fim'] else ''} | Vidas: {ci['vidas']} | Grupo financeiro: {ci['grupo_financeiro']}")
        for p in ci["planos"][:8]:
            L.append(f"    Plano: {p['nome']} (código {p['codigo']}){' - ' + p['acomodacao'] if p['acomodacao'] else ''}{' - início ' + p['inicio'] if p['inicio'] else ''}")
        if ci.get("total_subcontratos"):
            L.append(f"    Subcontratos: {ci['total_subcontratos']} ({'; '.join(sc['nome'] for sc in ci['subcontratos'][:4])}{'...' if ci['total_subcontratos'] > 4 else ''})")
        if ci.get("outros_contratos_citados"):
            L.append(f"    Outros contratos citados: {'; '.join(ci['outros_contratos_citados'])}")
        for pa in ci["portais"][:3]:
            L.append(f"    Portal operadora: {pa['portal']} - {pa['site']} (login {pa['login']}; senha na plataforma, acesso {pa['codigo']})")
    elif ci and ci.get("erro"):
        L.append("  Contrato: sem permissão para ler os dados do contrato.")
    arqs = [a for a in t["arquivos"] if not IMG.search(a["nome"])]
    if arqs:
        L.append("  Arquivos mais recentes:")
        for a in arqs[:5]:
            L.append(f"    - {a['nome']} ({a['kb']} KB, {a['enviado_em']}, {a['enviado_por']}){'  <- NOVO' if a['novo'] and t['motivo']=='atualizado' else ''}")
        if len(arqs) > 5:
            L.append(f"    (+{len(arqs)-5} arquivo(s) mais antigos)")
    else:
        L.append("  Arquivos: nenhum arquivo anexado (fora imagens de assinatura).")
    OP = {"1": "1 - Maninha", "2": "2 - Carregador do Futuro", "3": "3 - Sem ação"}
    sug = str(r.get("sugestao", "")).strip()[:1]
    if sug in OP:
        L.append(f"  Sugestão do Claude: {OP[sug]}" + (f" - {r['motivo']}" if r.get("motivo") else ""))
    L.append("  Orientação (1 Maninha / 2 Carregador do Futuro / 3 Sem ação / Outro):")
    L.append("  R:")
    L.append("-" * 100)
open(sys.argv[3], "w", encoding="utf-8-sig", newline="\r\n").write("\n".join(L) + "\n")
print(sys.argv[3])
