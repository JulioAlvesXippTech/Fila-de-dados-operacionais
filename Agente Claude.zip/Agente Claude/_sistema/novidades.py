#!/usr/bin/env python3
"""Mostra, de forma compacta, o que o Claude precisa escrever na Pré-análise (economiza tokens em conversas novas).
  NOVOS    = atendimentos da coleta sem texto em preanalise_textos.json e sem regra automática (regras_bot.py)
  MUDARAM  = atendimentos com interação depois da última pré-análise gerada (gerado_em de preanalise.json)
Uso: python3 novidades.py <coleta.json> [--desde "dd/mm/aaaa HH:MM"]
Depois: escrever os textos em preanalise_textos.json ({id: [pedido, situacao, sugestao, acao, prioridade]}) e rodar monta_pre.py."""
import json, os, re, sys
from datetime import datetime
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from regras_bot import regra
col = sys.argv[1]
c = json.load(open(col, encoding='utf-8'))['itens']
T = json.load(open(os.path.join(AQUI, 'preanalise_textos.json'), encoding='utf-8'))
if '--desde' in sys.argv:
    corte = datetime.strptime(sys.argv[sys.argv.index('--desde') + 1], '%d/%m/%Y %H:%M')
else:
    corte = datetime.strptime(json.load(open(os.path.join(AQUI, 'preanalise.json'), encoding='utf-8'))['gerado_em'], '%d/%m/%Y %H:%M')
novos, mud = [], []
for i in c:
    if str(i['id']) not in T:
        if not regra(i['titulo'], bool(i.get('bot'))):
            novos.append(i)
    elif datetime.strptime(i['ultima_interacao'], '%d/%m/%Y %H:%M') > corte:
        mud.append(i)
print(f"TOTAL {len(c)} | NOVOS {len(novos)} | MUDARAM {len(mud)} | corte {corte:%d/%m/%Y %H:%M}")
def show(i, full):
    dc = i.get('dados_contrato') or {}
    print(f"### {i['id']} | {i['numero']} | prot {i['protocolo']} | {i['etapa']} | resp {i['responsavel']} | sol {i['solicitante']} | "
          f"tipo {i['tipo']} | contrato {i['contrato'][:45]} | aberto {i['abertura']} | ult {i['ultima_interacao']} {i['ultimo_autor']} | bot {i.get('bot')}")
    print('T:', i['titulo'][:110])
    if dc:
        print('DC:', dc.get('erro') or f"{dc.get('contrato')} {dc.get('operadora')} {dc.get('status')} portais={len(dc.get('portais') or [])}")
    if full:
        print('D:', re.sub(r'\s+', ' ', i['descricao'])[:260])
    ms = i['mensagens'][-2:] if full else [m for m in i['mensagens'] if datetime.strptime(m['data'], '%d/%m/%Y %H:%M') > corte][-3:]
    for m in ms:
        print('  M', m['data'], m['autor'], ':', re.sub(r'\s+', ' ', m['texto'])[:230])
    if i['anexos']:
        print('  A', [a['nome'] for a in i['anexos']][-4:])
for i in novos:
    show(i, True)
print('\n==== MUDARAM')
for i in mud:
    print('ANTES:', T[str(i['id'])][:2], T[str(i['id'])][3])
    show(i, False)
