#!/usr/bin/env python3
"""Muda o STATUS de um atendimento da fila Dados Operacionais. Ações "Avançar para Em andamento" e
"Encerrar (Fechado)" da Plataforma, criadas a pedido do Julio em 26/10/2026.

Transições permitidas (só estas):
  andamento : Novo/Pendente      -> Em Andamento  (stage 2,  state in_progress)
  fechar    : Novo/Pendente/Em Andamento -> Fechado (stage 14, state closed)
No Odoo da Xipp, Status (stage_id) e Situação (state) andam sempre juntos, por isso os dois são gravados.

ATENÇÃO: o Odoo envia e-mail automático ao solicitante na mudança de status
(Em Andamento = "Atendimento - Acompanhamento"; Fechado = "Atendimento - Encerramento app").

Escrita em PRODUÇÃO só com --confirmar-producao e só depois de o Julio aprovar o direcionamento.
Escritas: (opcional) nota interna com --nota; helpdesk.ticket.write {stage_id, state} e, se pedido no direcionamento
(27/10/2026), Assunto (ticket_type_id) e Solicitação (xipp_request_id) com --assunto/--solicitacao (nome exato,
a Solicitação tem de pertencer ao Assunto). Nunca unlink.
Backup antes; relê depois. Se o Odoo recusar, nada é alterado.

Uso: python3 mudar_status.py --cred credenciais.env --id 587633 --para andamento|fechar --out <pasta>
                             [--nota "texto da nota interna"] [--confirmar-producao]
"""
import argparse, html, json, os, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agente_atendimentos import Odoo, load_env, BRT

FILA = 27  # Dados Operacionais
DESTINO = {"andamento": (2, "in_progress", "Em Andamento"), "fechar": (14, "closed", "Fechado")}
ORIGEM_OK = {"andamento": {1, 122}, "fechar": {1, 122, 2}}
EMAIL = {"andamento": "Atendimento - Acompanhamento", "fechar": "Atendimento - Encerramento app"}
CAMPOS = ["number", "protocol_code", "name", "team_id", "stage_id", "state", "user_id", "close_date",
          "ticket_type_id", "xipp_request_id"]


def _norm(x):
    import unicodedata
    return " ".join(unicodedata.normalize("NFKD", x or "").encode("ascii", "ignore").decode().lower().split())


def resolver(o, assunto, solicitacao, atual_tipo):
    """Converte nomes em ids sem ambiguidade. Retorna (vals, erro)."""
    vals = {}
    tipo_id = atual_tipo
    if assunto:
        cands = [x for x in o.call("helpdesk.ticket.type", "search_read", [[["name", "ilike", assunto.split()[0]]]], {"fields": ["name"]})
                 if _norm(x["name"]) == _norm(assunto) or _norm(x["name"]).replace("de ", "") == _norm(assunto).replace("de ", "")]
        if len(cands) != 1:
            return None, f"Assunto '{assunto}' não encontrado de forma única ({[c['name'] for c in cands]})"
        tipo_id = cands[0]["id"]
        vals["ticket_type_id"] = tipo_id
    if solicitacao:
        cands = [x for x in o.call("xipp.helpdesk.ticket.request", "search_read", [[["name", "ilike", solicitacao]]],
                                   {"fields": ["name", "ticket_type_ids"]})
                 if _norm(x["name"]) == _norm(solicitacao) and (not tipo_id or tipo_id in x["ticket_type_ids"])]
        if len(cands) != 1:
            return None, f"Solicitação '{solicitacao}' não encontrada de forma única para o Assunto ({[c['name'] for c in cands]})"
        vals["xipp_request_id"] = cands[0]["id"]
    return vals, None


def escrever(o, model, method, args, kw=None):
    if o.uid is None:
        o.call("res.users", "search_count", [[["id", "=", -1]]])
    return o._post("/jsonrpc", {"service": "object", "method": "execute_kw",
                                "args": [o.db, o.uid, o.key, model, method, args, kw or {}]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--id", type=int, required=True)
    ap.add_argument("--para", choices=list(DESTINO), required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--nota", default="")
    ap.add_argument("--assunto", default="", help="nome do Assunto (helpdesk.ticket.type), ex.: 'Base Beneficiários'")
    ap.add_argument("--solicitacao", default="", help="nome da Solicitação ligada ao Assunto, ex.: 'Solicitação'")
    ap.add_argument("--confirmar-producao", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    o = Odoo(load_env(a.cred))
    t = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": CAMPOS})[0]
    sid, state, nome = DESTINO[a.para]
    extra, erro = resolver(o, a.assunto.strip(), a.solicitacao.strip(), t["ticket_type_id"] and t["ticket_type_id"][0])
    if erro:
        sys.exit("BLOQUEIO: " + erro)
    plano = {"atendimento": t["number"], "protocolo": t["protocol_code"], "titulo": t["name"],
             "antes": {"status": t["stage_id"], "situacao": t["state"], "fila": t["team_id"],
                       "assunto": t["ticket_type_id"], "solicitacao": t["xipp_request_id"]},
             "campos_extras": extra,
             "depois_previsto": {"status": [sid, nome], "situacao": state},
             "email_automatico_ao_solicitante": EMAIL[a.para], "nota_interna": a.nota or None}
    if not t["team_id"] or t["team_id"][0] != FILA:
        sys.exit(f"BLOQUEIO: atendimento fora da fila Dados Operacionais ({t['team_id']})")
    if t["stage_id"] and t["stage_id"][0] == sid and not extra:
        # já está no destino (ex.: rodada anterior fechou mas não conseguiu registrar): nada a gravar
        print(json.dumps({"ok": True, "ja_estava": True, "depois": {"stage_id": t["stage_id"], "state": t["state"]}},
                         ensure_ascii=False))
        return
    if not t["stage_id"] or t["stage_id"][0] not in ORIGEM_OK[a.para]:
        sys.exit(f"BLOQUEIO: status atual {t['stage_id']} não permite ir para {nome}")
    agora = datetime.now(BRT)
    plano["modo"] = "PRODUÇÃO" if a.confirmar_producao else "SIMULAÇÃO (nada gravado)"
    bpath = os.path.join(a.out, f"backup_status_{t['protocol_code']}_{agora:%Y%m%d_%H%M}.json")
    salvar = lambda: json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    salvar()
    if not a.confirmar_producao:
        print(json.dumps(plano, ensure_ascii=False, indent=1))
        return
    try:
        if a.nota.strip():
            corpo = "<p>" + html.escape(a.nota.strip()).replace("\n", "<br/>") + "</p>"
            plano["nota_id"] = escrever(o, "helpdesk.ticket", "message_post", [[a.id]],
                                        {"body": corpo, "body_is_html": True, "subtype_xmlid": "mail.mt_note",
                                         "message_type": "comment"})
            salvar()
        escrever(o, "helpdesk.ticket", "write", [[a.id], dict(extra, stage_id=sid, state=state)])
    except SystemExit as e:  # o Odoo desfaz a gravação inteira quando recusa
        plano["ok"] = False
        plano["erro"] = str(e)[:300]
        salvar()
        sys.exit("RECUSADO PELO ODOO (status não alterado): " + str(e)[:200])
    d = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["stage_id", "state", "close_date", "team_id", "user_id",
                                                               "ticket_type_id", "xipp_request_id"]})[0]
    plano["depois_lido"] = d
    plano["ok"] = bool(d["stage_id"] and d["stage_id"][0] == sid and d["state"] == state
                       and all((d[k] or [None])[0] == v for k, v in extra.items()))
    salvar()
    print(json.dumps({"ok": plano["ok"], "depois": d, "backup": os.path.basename(bpath)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
