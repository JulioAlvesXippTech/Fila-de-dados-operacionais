#!/usr/bin/env python3
"""Ações confirmadas pelo Julio no chat (29/10/2026), fora do automático:
  delegar : helpdesk.ticket.write {user_id} (mesma fila; só dentro de Dados Operacionais)
  nota    : nota interna marcando o solicitante (e, opcional, outras pessoas por nome de usuário)
Backup antes, releitura depois. Nunca unlink, nunca muda fila.

Uso:
  python3 acoes_manuais.py --cred credenciais.env --out <pasta> delegar --id 123 --para "Vitor Matsuoka" [--confirmar-producao]
  python3 acoes_manuais.py --cred credenciais.env --out <pasta> nota --id 123 --texto "..." [--marcar "Danilo Soares"] [--confirmar-producao]
"""
import argparse, html, json, os, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agente_atendimentos import Odoo, load_env, BRT
from postar_criticador import solicitante, rpc_write

FILA = 27


def usuario(o, nome):
    us = o.call("res.users", "search_read", [[["name", "=", nome]]], {"fields": ["id", "name", "partner_id"], "limit": 2})
    if len(us) != 1:
        sys.exit(f"BLOQUEIO: usuário '{nome}' não encontrado de forma única")
    return us[0]


def membro_da_fila(o, nome):
    """Para 'Repassar responsável': aceita nome parcial ('Vitor'), mas só entre os membros da fila Dados Operacionais
    e só se for único. Bloqueia se ambíguo ou se a pessoa não for da fila."""
    membros = o.call("helpdesk.ticket.team", "read", [[FILA]], {"fields": ["member_ids"]})[0]["member_ids"]
    us = o.call("res.users", "search_read", [[["id", "in", membros], ["name", "ilike", nome.strip()]]],
                {"fields": ["id", "name", "partner_id"], "limit": 5})
    exatos = [u for u in us if u["name"].lower() == nome.strip().lower()]
    us = exatos or us
    if len(us) != 1:
        sys.exit(f"BLOQUEIO: '{nome}' não é um membro único da fila Dados Operacionais ({[u['name'] for u in us]})")
    return us[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--out", required=True)
    sp = ap.add_subparsers(dest="cmd", required=True)
    d = sp.add_parser("delegar"); d.add_argument("--id", type=int, required=True); d.add_argument("--para", required=True)
    d.add_argument("--confirmar-producao", action="store_true")
    n = sp.add_parser("nota"); n.add_argument("--id", type=int, required=True); n.add_argument("--texto", required=True)
    n.add_argument("--marcar", action="append", default=[]); n.add_argument("--confirmar-producao", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    o = Odoo(load_env(a.cred))
    t = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["number", "protocol_code", "name", "team_id", "user_id",
                                                               "stage_id", "xipp_requester_id", "partner_id"]})[0]
    if not t["team_id"] or t["team_id"][0] != FILA:
        sys.exit(f"BLOQUEIO: atendimento fora da fila Dados Operacionais ({t['team_id']})")
    plano = {"acao": a.cmd, "atendimento": t["number"], "protocolo": t["protocol_code"],
             "antes": {"atribuido": t["user_id"], "fila": t["team_id"], "etapa": t["stage_id"]}}
    if a.cmd == "delegar":
        u = membro_da_fila(o, a.para)
        plano["depois"] = {"atribuido": [u["id"], u["name"]]}
    else:
        pid, nome, _ = solicitante(o, t)
        if not pid:
            sys.exit("BLOQUEIO: solicitante sem contato no Odoo")
        marcados = [(pid, nome)] + [(usuario(o, m)["partner_id"][0], m) for m in a.marcar]
        corpo = "".join(f'<a href="/odoo/res.partner/{p}" class="o_mail_redirect" data-oe-id="{p}" data-oe-model="res.partner" '
                        f'target="_blank">@{html.escape(nm)}</a> ' for p, nm in marcados)
        corpo = f"<p>{corpo.strip()}</p><p>{html.escape(a.texto)}</p>"
        plano["nota"] = " ".join("@" + nm for _, nm in marcados) + "\n" + a.texto
    plano["modo"] = "PRODUÇÃO" if a.confirmar_producao else "SIMULAÇÃO (nada gravado)"
    bpath = os.path.join(a.out, f"backup_{a.cmd}_{t['protocol_code']}_{datetime.now(BRT):%Y%m%d_%H%M%S}.json")
    json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if not a.confirmar_producao:
        print(json.dumps(plano, ensure_ascii=False))
        return
    try:
        if a.cmd == "delegar":
            rpc_write(o, "helpdesk.ticket", "write", [[a.id], {"user_id": plano["depois"]["atribuido"][0]}])
            dl = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["user_id", "team_id"]})[0]
            plano["ok"] = bool(dl["user_id"] and dl["user_id"][0] == plano["depois"]["atribuido"][0] and dl["team_id"][0] == FILA)
            plano["depois_lido"] = dl
        else:
            msg = rpc_write(o, "helpdesk.ticket", "message_post", [[a.id]],
                            {"body": corpo, "body_is_html": True, "message_type": "comment", "subtype_xmlid": "mail.mt_note",
                             "partner_ids": [p for p, _ in marcados]})
            plano["message_id"] = msg
            plano["ok"] = bool(msg)
    except SystemExit as e:
        plano["ok"] = False
        plano["erro"] = str(e)[:300]
    json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: plano.get(k) for k in ("atendimento", "ok", "erro", "message_id", "depois_lido")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
