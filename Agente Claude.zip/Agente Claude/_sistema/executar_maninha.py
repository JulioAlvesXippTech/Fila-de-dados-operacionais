#!/usr/bin/env python3
"""Prepara a ação "Maninha" de UM atendimento aprovado na Plataforma (SOMENTE LEITURA no Odoo).

Baixa as planilhas de beneficiários mais recentes do atendimento (as do solicitante, último lote),
monta a pasta Layouts\\(#<protocolo>) <título> com "_Dados do contrato.txt", "Arquivo Origem" e
"Arquivo Validado\\AAAAMMDD_Criticador de layout_V<n>.xlsm" (criticador_xlsm.py) dentro de --out,
e imprime um JSON com o que gravar no computador e o arquivo a postar.
A postagem (nota interna + anexo) continua sendo feita só por postar_criticador.py.

Uso: python3 executar_maninha.py --cred credenciais.env --id 591930 --out /mnt/user-data/outputs/exec \
        [--versoes-existentes "20261026_Criticador de layout_V1.xlsm,..."] [--json res.json]
"""
import argparse, base64, json, os, re, subprocess, sys
from datetime import datetime
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import encaminhar as E
from agente_atendimentos import Odoo, load_env, BRT, contrato_info, contrato_pelo_texto

JULIO_UID = 275


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--id", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--versoes-existentes", default="")
    ap.add_argument("--json", default="")
    a = ap.parse_args()
    o = Odoo(load_env(a.cred))
    t = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["number", "protocol_code", "name", "xipp_contract_id",
                                                               "xipp_requester_id", "ticket_type_id", "xipp_request_id", "description"]})[0]
    prot, titulo = t["protocol_code"], (t["name"] or "").strip()
    pasta = E.nome_pasta(prot, titulo)
    atts = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "=", a.id]]],
                  {"fields": ["id", "name", "create_date", "create_uid", "file_size"], "order": "create_date desc"})
    plan = [x for x in atts if E.PLANILHA.search(x["name"] or "") and "criticador de layout" not in E.norm(x["name"])]
    do_solic = [x for x in plan if not (x["create_uid"] and x["create_uid"][0] == JULIO_UID)]
    escolhidos = E.lote_recente(do_solic or plan)
    res = {"id": a.id, "atendimento": t["number"], "protocolo": prot, "pasta": pasta, "arquivos": [], "gravar": []}
    if not escolhidos:
        res["erro"] = "atendimento sem planilha de beneficiários anexada"
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(2)
    base = os.path.join(a.out, "Layouts", pasta)
    orig = os.path.join(base, "Arquivo Origem")
    os.makedirs(orig, exist_ok=True)
    entradas, separacao = [], []
    for x in escolhidos:
        d = o.call("ir.attachment", "read", [[x["id"]]], {"fields": ["datas"]})[0].get("datas")
        if not d:
            continue
        dados_b = base64.b64decode(d)
        # 29/10/2026: planilha sem vidas no mesmo lote (ex.: modelo da operadora) vai para "Modelo Operadora", não para o criticador
        try:
            n_linhas = E.linhas_de_dados(x["name"], dados_b)
        except Exception:
            n_linhas = -1
        if 0 <= n_linhas <= 1 and len(escolhidos) > 1:
            dst = os.path.join(base, "Modelo Operadora")
            os.makedirs(dst, exist_ok=True)
            open(os.path.join(dst, E.nome_arquivo(x["name"])), "wb").write(dados_b)
            separacao.append((x["name"], "modelo"))
            res.setdefault("modelos", []).append(x["name"])
            continue
        p = os.path.join(orig, E.nome_arquivo(x["name"]))
        open(p, "wb").write(dados_b)
        entradas.append(p)
        res["arquivos"].append(x["name"])
        separacao.append((x["name"], "base"))
    if not entradas:
        res["erro"] = "nenhuma planilha com vidas entre os anexos mais recentes"
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(2)
    ci = contrato_info(o, t["xipp_contract_id"][0]) if t["xipp_contract_id"] else contrato_pelo_texto(o, t)
    dados = os.path.join(base, "_Dados do contrato.txt")
    open(dados, "w", encoding="utf-8-sig", newline="\r\n").write(
        E.texto_contrato(t["number"], titulo, ci) + E.texto_extra(False, separacao, True))
    hoje = datetime.now(BRT).strftime("%Y%m%d")
    exist = {s.strip().lower() for s in a.versoes_existentes.split(",") if s.strip()}
    v = 1
    while any(f"_criticador de layout_v{v}." in s for s in exist):
        v += 1
    val = os.path.join(base, "Arquivo Validado")
    os.makedirs(val, exist_ok=True)
    saida = os.path.join(val, f"{hoje}_Criticador de layout_V{v}.xlsm")
    rj = os.path.join(a.out, f"res_{prot}.json")
    r = subprocess.run([sys.executable, os.path.join(AQUI, "criticador_xlsm.py"), "--modelo",
                        os.path.join(AQUI, "Modelo_Criticador.xlsm"), "--entrada", *entradas, "--saida", saida,
                        "--titulo", pasta, "--json", rj], capture_output=True, text=True)
    if r.returncode != 0:
        res["erro"] = "criticador falhou: " + (r.stderr or r.stdout).strip()[-400:]
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(3)
    res["criticador"] = json.load(open(rj, encoding="utf-8"))
    if not res["criticador"].get("linhas"):
        # 29/10/2026: anexo sem nenhuma vida (ex.: modelo do criticador vazio) -> não há o que validar nem postar
        res["erro"] = f"o anexo ({', '.join(res['arquivos'])}) não tem nenhuma vida (0 linhas): pedir a base ao solicitante"
        res["gravar"] = []
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(3)
    res["arquivo_postar"] = saida
    res["contrato"] = {"razao_social": (ci or {}).get("razao_social") if isinstance(ci, dict) else None}
    for raiz, _, fs in os.walk(base):
        for f in fs:
            p = os.path.join(raiz, f)
            res["gravar"].append({"local": p, "relativo": os.path.relpath(p, a.out).replace("/", "\\")})
    if a.json:
        json.dump(res, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
