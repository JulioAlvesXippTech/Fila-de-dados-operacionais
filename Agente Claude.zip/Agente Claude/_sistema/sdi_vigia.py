# -*- coding: utf-8 -*-
"""
Vigia da fila de acoes na PX/SDI (Carregador do Futuro).

Fica aberto no seu PC. Quando aparece um pedido  _fila\\<id>.json  ele executa a ACAO pedida (cada acao e um
script Python registrado em acoes.json) e escreve o resultado em  _fila\\<id>.status.json
(o Claude le esse arquivo para seguir o trabalho).

Pedido (<id>.json) - o campo "acao" escolhe o script (sem "acao" = baixar_base_sdi):
  {"id": "488167_20261028", "acao": "baixar_base_sdi", "grupo": "Grupo Caixa CNP", "contrato": "511312",
   "pasta": "C:\\...\\Carga SDI\\(#488167) ...", "solicitante": "Julio Alves"}
  {"id": "x1", "acao": "consultar_carga_api_bradesco", "contrato": "74109"}

Acoes novas: basta gravar o script na pasta e registrar no acoes.json (nao precisa reiniciar o vigia).

Uso:   python sdi_vigia.py            (headless; usa a sessao salva)
       python sdi_vigia.py --visivel  (mostra o navegador)
Nada e apagado: pedidos processados vao para _fila\\feito\\.
"""
import argparse
import json
import os
import re
import socket
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
FILA = AQUI / "_fila"
FEITO = FILA / "feito"


def python_console():
    """Se o vigia foi aberto com pythonw (sem janela), os filhos rodam com python.exe e sem abrir janela."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        cand = exe.with_name("python.exe")
        if cand.exists():
            return str(cand)
    return str(exe)


def agora():
    return datetime.now().isoformat(timespec="seconds")


def gravar_status(pid, dados):
    """Grava de forma atomica para o Claude nunca ler um arquivo pela metade."""
    destino = FILA / f"{pid}.status.json"
    tmp = FILA / f"{pid}.status.tmp"
    tmp.write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(destino)


ACOES_PADRAO = {
    "baixar_base_sdi": {
        "script": "sdi_baixar_base.py",
        "obrigatorios": ["grupo", "contrato", "pasta"],
        "args": {"grupo": "--grupo", "contrato": "--contrato", "pasta": "--pasta", "solicitante": "--solicitante"},
        "timeout_min": 30,
    },
    "consultar_carga_api_bradesco": {
        "script": "px_consulta_carga_api.py",
        "obrigatorios": ["contrato"],
        "args": {"contrato": "--contrato", "operadora": "--operadora", "tipo": "--tipo",
                 "max_paginas": "--max-paginas"},
        "flags": {"todos": "--todos", "sem_filtro_nome": "--sem-filtro-nome"},
        "timeout_min": 30,
    },
}


def carregar_acoes():
    """Acoes padrao + as do acoes.json (relido a cada pedido, assim acao nova nao exige reiniciar o vigia)."""
    acoes = dict(ACOES_PADRAO)
    try:
        extra = json.loads((AQUI / "acoes.json").read_text(encoding="utf-8-sig"))
        acoes.update({k: v for k, v in extra.items() if isinstance(v, dict)})
    except FileNotFoundError:
        pass
    except Exception as e:
        print("Aviso: acoes.json invalido:", e)
    return acoes


def encerrar_pedido(arq):
    destino = FEITO / arq.name
    if destino.exists():
        destino = FEITO / f"{arq.stem}_{int(time.time())}{arq.suffix}"
    arq.replace(destino)


def processar(arq, visivel):
    pid = arq.stem
    try:
        pedido = json.loads(arq.read_text(encoding="utf-8-sig"))
        nome_acao = str(pedido.get("acao") or "baixar_base_sdi").strip()
        acoes = carregar_acoes()
        if nome_acao not in acoes:
            raise ValueError(f"acao desconhecida '{nome_acao}' (disponiveis: {', '.join(sorted(acoes))})")
        ac = acoes[nome_acao]
        faltam = [k for k in ac.get("obrigatorios", []) if not str(pedido.get(k) or "").strip()]
        if faltam:
            raise ValueError("faltam campos no pedido: " + ", ".join(faltam))
        script = AQUI / ac["script"]
        if not script.exists():
            raise ValueError(f"script nao encontrado: {ac['script']}")
    except Exception as e:
        gravar_status(pid, {"estado": "erro", "mensagem": f"Pedido invalido: {e}", "fim": agora()})
        encerrar_pedido(arq)
        return

    entrada = {k: v for k, v in pedido.items() if k not in ("id", "acao")}
    status = {"estado": "executando", "acao": nome_acao, "pedido": entrada, "inicio": agora()}
    gravar_status(pid, status)
    print(f"[{agora()}] {pid}: {nome_acao} {entrada.get('contrato', '')}")

    cmd = [python_console(), str(script)]
    for campo, flag in ac.get("args", {}).items():
        valor = str(pedido.get(campo) or "").strip()
        if valor:
            cmd += [flag, valor]
    for campo, flag in ac.get("flags", {}).items():
        if pedido.get(campo) in (True, "true", "sim", 1, "1"):
            cmd.append(flag)
    if visivel:
        cmd.append("--visivel")

    try:
        r = subprocess.run(cmd, cwd=str(AQUI), capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=int(ac.get("timeout_min", 30)) * 60,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                           env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
        saida = (r.stdout or "") + (r.stderr or "")
        ok = r.returncode == 0
    except subprocess.TimeoutExpired:
        saida, ok = "Tempo esgotado.", False
    except Exception as e:
        saida, ok = f"Falha ao executar: {e}", False

    (FILA / f"{pid}.log.txt").write_text(saida, encoding="utf-8")
    m = re.search(r"Base salva em:\s*(.+)", saida)
    arquivo = m.group(1).strip() if m else None
    if ok and m and not Path(arquivo).exists() and pedido.get("pasta"):   # acento mal decodificado: procura no disco
        t0 = datetime.fromisoformat(status["inicio"]).timestamp() - 120
        achados = [p for p in (Path(pedido["pasta"]) / "Arquivo Origem").glob("RELATORIO_BENEFICIARIOS_*.xlsx")
                   if p.stat().st_mtime >= t0]
        arquivo = str(max(achados, key=lambda p: p.stat().st_mtime)) if achados else arquivo
    resultado = None
    mj = re.search(r"^RESULTADO_JSON:\s*(\{.*\})\s*$", saida, re.M)
    if mj:
        try:
            resultado = json.loads(mj.group(1))
        except Exception:
            resultado = None
    status.update({"fim": agora(), "arquivo": arquivo})
    if resultado is not None:
        status["resultado"] = resultado
    gera_saida = ac.get("saida", "arquivo" if "baixar" in nome_acao else "json")
    sucesso = ok and ((m is not None) if gera_saida == "arquivo" else (resultado is not None))
    status["estado"] = "ok" if sucesso else "erro"
    if not sucesso:
        erro = re.findall(r"ERRO:.*", saida)
        status["mensagem"] = (erro[-1] if erro else saida.strip()[-400:]) or "sem detalhes (veja o .log.txt)"
    gravar_status(pid, status)
    encerrar_pedido(arq)
    print(f"[{agora()}] {pid}: {status['estado']}" + (f" -> {arquivo}" if arquivo else ""))


def main():
    ap = argparse.ArgumentParser(description="Vigia da fila de baixa do SDI")
    ap.add_argument("--visivel", action="store_true")
    a = ap.parse_args()
    FEITO.mkdir(parents=True, exist_ok=True)
    trava = socket.socket()                        # impede duas copias do vigia ao mesmo tempo
    try:
        trava.bind(("127.0.0.1", 47653))
    except OSError:
        print("O vigia ja esta rodando.")
        return
    print("Vigia ativo. Pasta da fila:", FILA)
    print("Deixe esta janela aberta. CTRL+C para parar.\n")
    batimento = FILA / "vigia_ativo.txt"
    while True:
        try:
            batimento.write_text(agora(), encoding="utf-8")   # o Claude le a data/hora para saber se o vigia esta vivo
            pend = sorted((p for p in FILA.glob("*.json") if not p.name.endswith(".status.json")),
                          key=lambda p: p.stat().st_mtime)
            if pend:
                processar(pend[0], a.visivel)
                continue
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print("Aviso:", e)
        time.sleep(5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nVigia encerrado.")
