# -*- coding: utf-8 -*-
"""
px_carregar_arquivo.py - carrega um arquivo no SDI pela tela "Carga de Dados" > "Novo Upload".

Caminho automatizado (mapeado do video do Julio, 29/10/2026):
  1. Login na PX -> menu "SDI - Movimentacao Cadastral" -> card "Carga de Dados"
  2. Abre o painel "Novo Upload"
  3. Preenche: Tipo de arquivo* (ex.: Posicao Cadastral / Fatura Tecnica), Grupo financeiro,
     [Contrato], [Subcontrato] (opcionais), Operadora*, Competencia* (calendario de mes -> MM/AAAA)
  4. "Carregar arquivos" -> escolhe o arquivo -> confere "1 Arquivos carregados"
  5. "Upload" -> espera o aviso verde "Os arquivos foram enviados com sucesso"
  6. Procura o arquivo na lista (filtro "Nome do arquivo") e devolve protocolo/etapa/status, se achar

ALTERA DADOS NA PX. Por seguranca:
  - Sem --enviar o script so SIMULA: preenche tudo, anexa o arquivo e para antes de clicar em Upload.
  - Antes de enviar, procura na lista um arquivo com o mesmo nome; se achar, NAO envia
    (a menos que venha --permitir-repetido).

Saida: uma linha  RESULTADO_JSON: {...}  (ASCII). Erro: "ERRO: <motivo>" e codigo 1.

Uso (manual):
    python px_carregar_arquivo.py --tipo "Posição Cadastral" --grupo Prio --operadora "Bradesco Saude S/A"
        --competencia 10/2026 --arquivo "C:\\...\\20261029_PC_Prio_Bradesco_Saude.txt" [--enviar]
Opcoes: --contrato, --subcontrato, --permitir-repetido, --visivel, --discover
"""
import argparse
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sdi_baixar_base import (sync_playwright, PWTimeout, PX_URL_PADRAO, STATE, SESSAO_DIR, AQUI,  # noqa: E402
                             Debug, rx, sem_acento, ler_env, abrir_sdi, tela_sdi, clicar, esperar)

MESES_ABREV = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]
RE_SUCESSO = re.compile(r"enviad[oa]s?\s+com\s+sucesso", re.I)
RE_ERRO_TOAST = re.compile(r"erro|falh|inv[aá]lid|n[aã]o foi poss", re.I)


def norm(s):
    return " ".join(sem_acento(s or "").split())


# ----------------------------------------------------------------- painel Novo Upload
JS_MARCA_PAINEL = """() => {
  document.querySelectorAll('[data-px-upload]').forEach(e => e.removeAttribute('data-px-upload'));
  const alvo = [...document.querySelectorAll('body *')].find(e => e.offsetParent !== null &&
                 [...e.childNodes].some(n => n.nodeType === 3 && /Arquivos carregados/i.test(n.textContent || '')));
  if (!alvo) return false;
  let p = alvo;
  while (p.parentElement) {
    p = p.parentElement;
    const t = p.innerText || '';
    if (/Grupo financeiro/i.test(t) && /Compet[eê]ncia/i.test(t)) { p.setAttribute('data-px-upload', '1'); return true; }
  }
  return false;
}"""


def abrir_painel_upload(pg, tela):
    """Clica em 'Novo Upload' (se ainda nao estiver aberto) e devolve o locator do painel."""
    for tentativa in range(3):
        if tela.evaluate(JS_MARCA_PAINEL):
            return tela.locator("[data-px-upload]").first
        clicar(tela, "Novo Upload", "Novo Upload")
        time.sleep(1.5)
    raise RuntimeError("O painel 'Novo Upload' nao abriu (nao achei 'Arquivos carregados').")


def campo_do_painel(painel, rotulo):
    campo = painel.locator(".v-input").filter(has_text=rx(rotulo)).first
    try:
        campo.wait_for(state="visible", timeout=15000)
    except PWTimeout:
        raise RuntimeError(f"Nao achei o campo '{rotulo}' no painel Novo Upload.")
    return campo


def opcoes_visiveis(tela):
    ops = tela.locator(".v-menu__content .v-list-item, [role=option]")
    vis = []
    for i in range(ops.count()):
        o = ops.nth(i)
        try:
            if o.is_visible():
                t = " ".join(o.inner_text().split())
                if t:
                    vis.append((t, o))
        except Exception:
            pass
    return vis


def escolher_no_painel(pg, tela, painel, rotulo, valor, digitar=None):
    """Abre o campo do painel, digita parte do valor para filtrar e clica na opcao.
    Escolhe a opcao IGUAL ao valor (sem acento/caixa); se nao houver igual e houver so uma que contem, usa ela.
    Se houver varias parecidas, para com erro (nao escolhe no chute)."""
    campo = campo_do_painel(painel, rotulo)
    campo.click()
    time.sleep(0.8)
    entrada = campo.locator("input[type=text], input:not([type])").first
    try:
        if entrada.is_visible() and entrada.is_editable():
            entrada.fill("")
            entrada.type(digitar or valor[:12], delay=50)
            time.sleep(1.2)
    except Exception:
        pass
    alvo = norm(valor)
    vis = []
    for _ in range(20):
        vis = opcoes_visiveis(tela)
        if vis:
            break
        time.sleep(0.5)
    iguais = [o for t, o in vis if norm(t) == alvo]
    contem = [(t, o) for t, o in vis if alvo in norm(t)]
    if iguais:
        iguais[0].click()
    elif len(contem) == 1:
        contem[0][1].click()
    else:
        nomes = [t for t, _ in vis][:15]
        pg.keyboard.press("Escape")
        if not vis:
            raise RuntimeError(f"Nenhuma opcao apareceu em '{rotulo}' para '{valor}'.")
        raise RuntimeError(f"'{valor}' nao bate exatamente com uma opcao de '{rotulo}'. Opcoes vistas: {nomes}")
    time.sleep(0.8)
    pg.keyboard.press("Escape")
    time.sleep(0.4)
    escolhido = " ".join(campo.inner_text().split())
    try:
        escolhido = (entrada.input_value() or "").strip() or escolhido
    except Exception:
        pass
    print(f"  - {rotulo}: {escolhido}")
    return escolhido


def escolher_competencia(pg, tela, painel, mes, ano):
    """Competencia: calendario de mes (cabecalho com o ano, botoes jan..dez)."""
    alvo_txt = f"{mes:02d}/{ano}"
    campo = campo_do_painel(painel, "Competência")
    entrada = campo.locator("input").first
    entrada.click()
    time.sleep(0.8)
    cal = tela.locator(".v-picker, .v-date-picker").filter(has=tela.locator("button")).last
    try:
        cal.wait_for(state="visible", timeout=8000)
    except PWTimeout:
        cal = None
    if cal is not None:
        for _ in range(30):                      # ajusta o ano
            cab = " ".join(cal.locator(".v-date-picker-header__value, .v-date-picker-header").first.inner_text().split())
            m = re.search(r"(\d{4})", cab)
            if not m:
                raise RuntimeError(f"Nao entendi o ano do calendario da competencia ('{cab}')")
            atual = int(m.group(1))
            if atual == ano:
                break
            botoes = cal.locator(".v-date-picker-header button")
            (botoes.first if atual > ano else botoes.last).click()
            time.sleep(0.5)
        abrev = MESES_ABREV[mes - 1]
        btn = None
        bts = cal.locator(".v-date-picker-table button, table button")
        for i in range(bts.count()):
            t = norm(bts.nth(i).inner_text()).rstrip(".")
            if t.startswith(abrev):
                btn = bts.nth(i)
                break
        if btn is None:
            raise RuntimeError(f"Nao achei o mes '{abrev}' no calendario da competencia")
        btn.click()
        time.sleep(0.6)
        ok = cal.locator("button").filter(has_text=re.compile(r"^\s*OK\s*$", re.I))
        if ok.count() and ok.first.is_visible():
            ok.first.click()
            time.sleep(0.5)
    else:                                         # sem calendario: tenta digitar
        entrada.fill(alvo_txt)
        entrada.press("Enter")
        time.sleep(0.5)
    pg.keyboard.press("Escape")
    time.sleep(0.4)
    valor = (entrada.input_value() or "").strip()
    if alvo_txt not in valor:
        raise RuntimeError(f"A competencia ficou '{valor}', esperado '{alvo_txt}'")
    print(f"  - Competência: {valor}")
    return valor


def contador_carregados(painel):
    t = " ".join(painel.inner_text().split())
    m = re.search(r"(\d+)\s*Arquivos? carregados?", t, re.I)
    return int(m.group(1)) if m else None


def anexar_arquivo(pg, tela, painel, caminho):
    antes = contador_carregados(painel) or 0
    botao = painel.locator("button, .v-btn").filter(has_text=rx("Carregar arquivos")).first
    try:
        with pg.expect_file_chooser(timeout=15000) as fc:
            botao.click()
        fc.value.set_files(str(caminho))
    except Exception:
        entrada = painel.locator("input[type=file]").first     # plano B: input escondido
        if entrada.count() == 0:
            entrada = tela.locator("input[type=file]").first
        entrada.set_input_files(str(caminho))
    for _ in range(30):
        time.sleep(0.5)
        depois = contador_carregados(painel)
        if depois is not None and depois > antes:
            print(f"  - arquivo anexado ({depois} arquivo(s) carregado(s))")
            return depois
    raise RuntimeError("O arquivo nao apareceu como carregado ('Arquivos carregados' nao aumentou).")


def esperar_resultado_upload(pg, tela, painel, timeout_s):
    """Espera o aviso verde de sucesso (ou um aviso de erro)."""
    fim = time.time() + timeout_s
    while time.time() < fim:
        avisos = tela.locator(".v-snack, .v-snack__content, .v-alert, [role=alert], [role=status], .toast, [class*=toast]")
        for i in range(avisos.count()):
            try:
                a = avisos.nth(i)
                if not a.is_visible():
                    continue
                t = " ".join(a.inner_text().split())
                if RE_SUCESSO.search(t):
                    return True, t
                if t and RE_ERRO_TOAST.search(t):
                    return False, t
            except Exception:
                pass
        time.sleep(0.5)
    return None, "sem aviso de sucesso ou erro dentro do prazo"


# ----------------------------------------------------------------- lista (conferencia)
JS_LINHAS_NOME = """(nome) => {
  const alvo = nome.toLowerCase();
  const folhas = [...document.querySelectorAll('body *')].filter(e => e.children.length === 0 &&
                   (e.textContent || '').toLowerCase().includes(alvo) && e.offsetParent !== null);
  const out = [];
  for (const f of folhas) {
    let l = f;
    while (l.parentElement) {
      const p = l.parentElement, t = (p.innerText || '').toLowerCase();
      if (t.split(alvo).length > 2 || /linhas por p[aá]gina|nome do arquivo|arquivos carregados/i.test(t)) break;
      l = p;
    }
    const t = l.innerText || '';
    if (!out.includes(t)) out.push(t);
  }
  return out;
}"""


def procurar_na_lista(pg, tela, nome_base):
    """Usa o filtro 'Nome do arquivo' da lista (secao Filtro) e devolve as linhas que contem o nome."""
    linhas = []
    try:
        filtro = tela.locator(".v-input").filter(has_text=rx("Nome do arquivo")).locator("input").last
        filtro.wait_for(state="visible", timeout=8000)
        filtro.fill(nome_base)
        filtro.press("Enter")
        esperar(pg, 2.5)
        for texto in tela.evaluate(JS_LINHAS_NOME, nome_base):
            partes = [x.strip() for x in re.split(r"[\n\t]+", texto) if x.strip()]
            if not partes:
                continue
            junto = " ".join(partes)
            mp = re.search(r"(?<![\d/_])(\d{5,9})(?![\d/_])", junto.split(nome_base)[0])
            md = re.search(r"\d{2}/\d{2}/\d{4}(?:\s+\d{2}:\d{2})?", junto)
            prot = mp.group(1) if mp else ""
            data = md.group(0) if md else ""
            linhas.append({"protocolo": prot, "data_hora": data, "texto": " | ".join(partes)[:400]})
        filtro.fill("")
        filtro.press("Enter")
    except Exception as e:
        print(f"    (nao consegui procurar na lista: {e})")
    return linhas


# ----------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Carrega arquivo no SDI (Carga de Dados > Novo Upload)")
    ap.add_argument("--tipo", required=True, help='ex.: "Posição Cadastral" ou "Fatura Técnica"')
    ap.add_argument("--grupo", required=True, help="Grupo financeiro, como aparece na lista (ex.: Prio)")
    ap.add_argument("--operadora", required=True, help='ex.: "Bradesco Saude S/A"')
    ap.add_argument("--competencia", required=True, help="MM/AAAA (ex.: 10/2026)")
    ap.add_argument("--arquivo", required=True, help="caminho completo do arquivo no PC")
    ap.add_argument("--contrato", default="")
    ap.add_argument("--subcontrato", default="")
    ap.add_argument("--enviar", action="store_true", help="sem isto o script so simula (nao clica em Upload)")
    ap.add_argument("--permitir-repetido", action="store_true")
    ap.add_argument("--timeout-upload", type=int, default=300)
    ap.add_argument("--cred", default=str(AQUI / "credenciais.env"))
    ap.add_argument("--visivel", action="store_true")
    ap.add_argument("--discover", action="store_true")
    a = ap.parse_args()

    # ---- validacao do pedido (antes de abrir o navegador)
    arq = Path(a.arquivo.strip().strip('"'))
    if not arq.is_file():
        print(f"\nERRO: arquivo nao encontrado: {arq}")
        sys.exit(1)
    m = re.fullmatch(r"\s*(\d{1,2})\s*[/\-]\s*(\d{4})\s*", a.competencia)
    if not m or not 1 <= int(m.group(1)) <= 12:
        print(f"\nERRO: competencia invalida '{a.competencia}' (use MM/AAAA, ex.: 10/2026)")
        sys.exit(1)
    mes, ano = int(m.group(1)), int(m.group(2))

    env = ler_env(a.cred)
    px_url = env.get("ODOO_URL", PX_URL_PADRAO).rstrip("/")
    dbg = Debug(a.discover)
    resultado = {"modo": "enviar" if a.enviar else "simulacao", "arquivo": str(arq), "nome_arquivo": arq.name,
                 "tamanho_kb": round(arq.stat().st_size / 1024, 1), "tipo_arquivo": a.tipo, "grupo": a.grupo,
                 "operadora": a.operadora, "competencia": f"{mes:02d}/{ano}", "enviado": False}
    print(f"Carregar arquivo: {arq.name} | {a.tipo} | {a.grupo} | {a.operadora} | {mes:02d}/{ano} | "
          f"{'ENVIAR' if a.enviar else 'SIMULACAO (nao clica em Upload)'}")

    with sync_playwright() as p:
        b = p.chromium.launch(headless=not a.visivel)
        kw = {"viewport": {"width": 1600, "height": 1000}, "locale": "pt-BR"}
        if STATE.exists():
            kw["storage_state"] = str(STATE)
        c = b.new_context(**kw)
        c.on("request", dbg.rede)
        pg = c.new_page()
        try:
            abrir_sdi(pg, px_url, env)
            tela = tela_sdi(pg)
            dbg.passo(pg, "menu SDI")
            clicar(tela, "Carga de Dados", "Carga de Dados")
            tela.get_by_text(rx("Novo Upload")).first.wait_for(state="visible", timeout=60000)
            esperar(pg, 2)

            # ---- ja foi enviado antes?
            repetidos = procurar_na_lista(pg, tela, arq.stem)
            if repetidos:
                resultado["ja_na_lista"] = repetidos[:5]
                print(f"  - ja existe(m) {len(repetidos)} linha(s) com '{arq.stem}' na lista (periodo padrao da tela)")
                if a.enviar and not a.permitir_repetido:
                    raise RuntimeError(f"O arquivo '{arq.stem}' ja aparece na lista (protocolo "
                                       f"{repetidos[0]['protocolo'] or '?'}). Nao enviei de novo. "
                                       "Se for para reenviar mesmo, peca com permitir_repetido=true.")

            painel = abrir_painel_upload(pg, tela)
            dbg.passo(pg, "novo upload")
            resultado["tipo_arquivo"] = escolher_no_painel(pg, tela, painel, "Tipo de arquivo", a.tipo)
            resultado["grupo"] = escolher_no_painel(pg, tela, painel, "Grupo financeiro", a.grupo)
            if a.contrato:
                resultado["contrato"] = escolher_no_painel(pg, tela, painel, "Contrato", a.contrato)
            if a.subcontrato:
                resultado["subcontrato"] = escolher_no_painel(pg, tela, painel, "Subcontrato", a.subcontrato)
            resultado["operadora"] = escolher_no_painel(pg, tela, painel, "Operadora", a.operadora)
            resultado["competencia"] = escolher_competencia(pg, tela, painel, mes, ano)
            anexar_arquivo(pg, tela, painel, arq)
            dbg.passo(pg, "formulario preenchido")

            if not a.enviar:
                resultado["observacao"] = ("SIMULACAO: formulario preenchido e arquivo anexado, mas NAO cliquei em "
                                           "Upload. Para enviar de verdade, peca com enviar=true.")
            else:
                botao = painel.locator("button, .v-btn").filter(has_text=re.compile(r"^\s*Upload\s*$", re.I)).first
                botao.click()
                print("  - Upload clicado, aguardando confirmacao...")
                ok, msg = esperar_resultado_upload(pg, tela, painel, a.timeout_upload)
                resultado["mensagem_tela"] = msg
                dbg.passo(pg, "depois do upload")
                if ok is not True:
                    raise RuntimeError(f"O upload nao confirmou sucesso: {msg}")
                resultado["enviado"] = True
                print(f"  - {msg}")
                esperar(pg, 4)
                achados = procurar_na_lista(pg, tela, arq.stem)
                resultado["na_lista"] = achados[:5]
                if not achados:
                    resultado["observacao"] = ("Upload confirmado pela tela; o arquivo ainda nao apareceu na lista "
                                               "(pode levar alguns minutos). Consultar depois pelo nome.")
            try:                                  # salvar a sessao nunca pode transformar um envio feito em erro
                SESSAO_DIR.mkdir(exist_ok=True)
                c.storage_state(path=str(STATE))
            except Exception as e:
                print(f"    (nao consegui salvar a sessao: {e})")
        except Exception as e:
            dbg.passo(pg, "erro")
            print("\nERRO:", e)
            print("RESULTADO_JSON: " + json.dumps(resultado, ensure_ascii=True))
            sys.exit(1)
        finally:
            dbg.salvar()
            b.close()
    print("RESULTADO_JSON: " + json.dumps(resultado, ensure_ascii=True))


if __name__ == "__main__":
    main()
