#!/usr/bin/env python3
"""Relatorio diario de atendimentos de CARGA e LAYOUT (SOMENTE LEITURA na plataforma.xipp.com.br).
Aba extra "Dados Operacionais": todos os abertos da fila (sem Xipp bot), qualquer responsavel exceto EXCLUIR_DO.
Uso:
  python3 relatorio_carga_layout.py --cred credenciais.env --saida <arquivo.xlsx> [--json resumo.json]
Filtro: fila contem "Dados operacionais", etapa nao dobrada, solicitante nao contem "Xipp bot",
responsavel = Julio Alves / Renan Silva / Joao Lourenco / Vitor Matsuoka.
Classifica por palavras-chave (titulo, tipo, solicitacao, descricao) em Carga / Layout; o resto fica fora.
Importa agente_atendimentos.py (mesma pasta) - que so permite search_read/read/search_count/fields_get.
"""
import argparse, json, os, re, sys, collections
from datetime import datetime, date, timedelta
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import agente_atendimentos as A
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.formatting.rule import CellIsRule

RESP = ["Julio Alves", "Renan Silva", "João Lourenço", "Vitor Matsuoka"]
# Responsaveis que NAO entram na aba "Dados Operacionais" (pedido do Julio em 15/10/2026)
EXCLUIR_DO = ["Felipe Aranda", "Francisco Augusto Souza", "Kennedy Pardinho", "Marcello Nascimento", "Marlon Ferreira"]
# Plataforma (Pré-análise e Fila completa) — pedido do Julio de 11/11/2026: tirar também Jonas Vidal e Matheus Bessa.
# O relatório Excel continua usando só EXCLUIR_DO.
FORA_DA_PLATAFORMA = EXCLUIR_DO + ["Jonas Vidal", "MATHEUS DA SILVA BESSA"]
FORA = re.compile(r"relatorio gerencial|relatorios gerenciais|solicitacao de relatorios|sinistr|fatura|termo de sigilo|estudo")
LAYOUT = re.compile(r"layout|criticador|validador|bate cadastral")
CARGA = re.compile(r"carga|carregar|atualiza\w* (da |de )?base|posicao cadastral|base de ativos|\bsdi\b|extracao de pc")


def _pascoa(y):
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    g = (8 * b + 13) // 25
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    return date(y, mes, (h + l - 7 * m + 114) % 31 + 1)


def feriados(anos):
    """Feriados nacionais + Carnaval (seg/ter) e Corpus Christi."""
    out = {}
    for y in anos:
        p = _pascoa(y)
        for dt, nome in [(date(y, 1, 1), "Confraternização Universal"), (p - timedelta(48), "Carnaval"),
                         (p - timedelta(47), "Carnaval"), (p - timedelta(2), "Sexta-feira Santa"),
                         (date(y, 4, 21), "Tiradentes"), (date(y, 5, 1), "Dia do Trabalho"),
                         (p + timedelta(60), "Corpus Christi"), (date(y, 9, 7), "Independência"),
                         (date(y, 10, 12), "Nossa Senhora Aparecida"), (date(y, 11, 2), "Finados"),
                         (date(y, 11, 15), "Proclamação da República"), (date(y, 11, 20), "Consciência Negra"),
                         (date(y, 12, 25), "Natal")]:
            out[dt] = nome
    return dict(sorted(out.items()))


def dias_uteis(ini, fim, fer):
    """Dias úteis decorridos de ini (exclusive) até fim (inclusive), sem fins de semana e feriados."""
    n, d = 0, ini + timedelta(1)
    while d <= fim:
        if d.weekday() < 5 and d not in fer:
            n += 1
        d += timedelta(1)
    return n


SINISTRO = re.compile(r"relatorio\s+gerencial|sinistr")  # regra do Julio (27/10/2026): pelo título


def classifica(t):
    titulo = A._sem_acento(t["name"])
    if SINISTRO.search(titulo):
        return "Sinistro"
    s = A._sem_acento(" ".join([t["name"] or "", A.m2o(t["ticket_type_id"]) or "", A.m2o(t["xipp_request_id"]) or "",
                                A.txt(t["description"] or "")[:1500]]))
    if FORA.search(titulo):
        return None
    if re.search(r"posicao cadastral|extracao de pc", titulo):
        return "Carga"
    if LAYOUT.search(s):
        return "Layout"
    if CARGA.search(s):
        return "Carga"
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--json")
    a = ap.parse_args()
    o = A.Odoo(A.load_env(a.cred))
    dom = [["team_id", "ilike", "Dados operacionais"], ["stage_id.fold", "=", False],
           ["xipp_requester_id", "not ilike", "Xipp bot"]] + ["|"] * (len(RESP) - 1) + [["user_id", "ilike", n] for n in RESP]
    ts = o.call("helpdesk.ticket", "search_read", [dom], {
        "fields": ["id", "name", "number", "protocol_code", "stage_id", "user_id", "ticket_type_id", "xipp_request_id",
                   "description", "create_date", "write_date", "xipp_requester_id"], "limit": 3000})
    ids = [t["id"] for t in ts]
    mm = o.call("mail.message", "search_read", [[["model", "=", "helpdesk.ticket"], ["res_id", "in", ids],
                                                  ["message_type", "in", ["comment", "email"]]]],
                {"fields": ["res_id", "date", "author_id"], "limit": 200000}) if ids else []
    ult = {}
    for m in mm:
        if m["res_id"] not in ult or m["date"] > ult[m["res_id"]]["date"]:
            ult[m["res_id"]] = m
    rows = []
    for t in ts:
        tipo = classifica(t)
        if tipo not in ("Carga", "Layout"):  # Sinistro/Outro ficam só na aba Dados Operacionais
            continue
        m = ult.get(t["id"])
        data = A.brt(m["date"]) if m else A.brt(t["write_date"])
        rows.append([A.m2o(t["user_id"]), t["number"] if t["number"] and t["number"] != "/" else "", t["protocol_code"] or "",
                     tipo, A.m2o(t["stage_id"]), datetime.strptime(data, "%d/%m/%Y %H:%M"),
                     (A.m2o(m["author_id"]) if m else "") or "", A.m2o(t["xipp_requester_id"]), (t["name"] or "").strip(), t["id"],
                     datetime.strptime(A.brt(t["create_date"]), "%d/%m/%Y %H:%M").date()])
    ordem = {n: i for i, n in enumerate(RESP)}
    rows.sort(key=lambda r: (ordem.get(r[0], 9), -r[5].timestamp()))

    hoje_d = datetime.now(A.BRT).date()
    anos = range(min([r[5].year for r in rows] + [hoje_d.year]), hoje_d.year + 2)
    fer = feriados(anos)

    wb = Workbook()
    ws = wb.active
    ws.title = "Atendimentos"
    ws.append(["Responsável", "Atendimento", "Protocolo", "Tipo", "Etapa", "Última atualização", "Atualizado por",
               "Solicitante", "Título", "Link", "Dias úteis sem interação", "Dias úteis desde a abertura"])
    nf = len(fer) + 1
    for i, r in enumerate(rows, start=2):
        ab = r[10]
        ws.append(r[:9] + ["Abrir", f"=MAX(0,NETWORKDAYS(INT(F{i}),TODAY(),Feriados!$A$2:$A${nf})-1)",
                            f"=MAX(0,NETWORKDAYS(DATE({ab.year},{ab.month},{ab.day}),TODAY(),Feriados!$A$2:$A${nf})-1)"])
        ws.cell(i, 6).number_format = "dd/mm/yyyy hh:mm"
        c = ws.cell(i, 10)
        c.hyperlink = f"https://plataforma.xipp.com.br/web#id={r[9]}&model=helpdesk.ticket&view_type=form"
        c.font = Font(color="0563C1", underline="single")
    n = max(len(rows) + 1, 2)
    tab = Table(displayName="Atendimentos", ref=f"A1:L{n}")
    tab.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    ws.add_table(tab)
    for col, w in zip("ABCDEFGHIJKL", [16, 12, 11, 8, 13, 17, 22, 20, 60, 8, 14, 14]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    ws.conditional_formatting.add(f"K2:K{n}", CellIsRule(operator="greaterThan", formula=["30"],
                                                         fill=PatternFill("solid", fgColor="F8CBAD")))
    ws.conditional_formatting.add(f"K2:K{n}", CellIsRule(operator="between", formula=["8", "30"],
                                                         fill=PatternFill("solid", fgColor="FFE699")))
    fs = wb.create_sheet("Feriados")
    fs.append(["Data", "Feriado"])
    for dt, nome in fer.items():
        fs.append([dt, nome])
        fs.cell(fs.max_row, 1).number_format = "dd/mm/yyyy"
    fs.column_dimensions["A"].width = 12
    fs.column_dimensions["B"].width = 28
    s = wb.create_sheet("Resumo")
    s.append(["Responsável", "Carga", "Layout", "Total", "Parados > 30 dias"])
    for i, nm in enumerate(RESP, start=2):
        s.append([nm, f'=COUNTIFS(Atendimentos!A:A,A{i},Atendimentos!D:D,"Carga")',
                  f'=COUNTIFS(Atendimentos!A:A,A{i},Atendimentos!D:D,"Layout")', f"=B{i}+C{i}",
                  f'=COUNTIFS(Atendimentos!A:A,A{i},Atendimentos!K:K,">30")'])
    t = len(RESP) + 2
    s.append(["Total"] + [f"=SUM({c}2:{c}{t - 1})" for c in "BCDE"])
    for c in s[1]:
        c.fill = PatternFill("solid", fgColor="1F4E78")
        c.font = Font(bold=True, color="FFFFFF")
    for c in s[t]:
        c.font = Font(bold=True)
    for col, w in zip("ABCDE", [18, 10, 10, 10, 18]):
        s.column_dimensions[col].width = w
    agora = datetime.now(A.BRT).strftime("%d/%m/%Y %H:%M")
    s.cell(t + 2, 1, f"Fonte: plataforma.xipp.com.br (fila Dados Operacionais, abertos, sem Xipp bot), extraído em {agora}. "
                     "Classificação por palavras-chave; dias sem interação e dias desde a abertura em dias úteis (sem fins de semana e feriados da aba Feriados).")
    # --- Aba extra: todos os atendimentos abertos da fila Dados Operacionais ---
    dom2 = [["team_id", "ilike", "Dados operacionais"], ["stage_id.fold", "=", False],
            ["xipp_requester_id", "not ilike", "Xipp bot"]]
    ts2 = o.call("helpdesk.ticket", "search_read", [dom2], {
        "fields": ["id", "name", "number", "protocol_code", "stage_id", "user_id", "ticket_type_id", "xipp_request_id",
                   "description", "create_date", "write_date", "xipp_requester_id"], "limit": 5000})
    _exc = {A._sem_acento(n).lower() for n in EXCLUIR_DO}
    ts2 = [tk for tk in ts2 if A._sem_acento(A.m2o(tk["user_id"]) or "").lower() not in _exc]
    ids2 = [t["id"] for t in ts2 if t["id"] not in ult]
    mm2 = []
    for k in range(0, len(ids2), 500):
        mm2 += o.call("mail.message", "search_read", [[["model", "=", "helpdesk.ticket"], ["res_id", "in", ids2[k:k+500]],
                                                        ["message_type", "in", ["comment", "email"]]]],
                      {"fields": ["res_id", "date", "author_id"], "limit": 200000})
    for m in mm2:
        if m["res_id"] not in ult or m["date"] > ult[m["res_id"]]["date"]:
            ult[m["res_id"]] = m
    rows2 = []
    for tk in ts2:
        m = ult.get(tk["id"])
        data = A.brt(m["date"]) if m else A.brt(tk["write_date"])
        rows2.append([A.m2o(tk["user_id"]) or "Sem responsável", tk["number"] if tk["number"] and tk["number"] != "/" else "",
                      tk["protocol_code"] or "", classifica(tk) or "Outro", A.m2o(tk["stage_id"]),
                      datetime.strptime(data, "%d/%m/%Y %H:%M"), (A.m2o(m["author_id"]) if m else "") or "",
                      A.m2o(tk["xipp_requester_id"]), (tk["name"] or "").strip(), tk["id"],
                      datetime.strptime(A.brt(tk["create_date"]), "%d/%m/%Y %H:%M").date()])
    rows2.sort(key=lambda r: (ordem.get(r[0], 8 if r[0] != "Sem responsável" else 9), r[0], -r[5].timestamp()))
    ws2 = wb.create_sheet("Dados Operacionais", 1)
    ws2.append(["Responsável", "Atendimento", "Protocolo", "Tipo", "Etapa", "Última atualização", "Atualizado por",
                "Solicitante", "Título", "Link", "Dias úteis sem interação", "Dias úteis desde a abertura"])
    for i, r in enumerate(rows2, start=2):
        ab = r[10]
        ws2.append(r[:9] + ["Abrir", f"=MAX(0,NETWORKDAYS(INT(F{i}),TODAY(),Feriados!$A$2:$A${nf})-1)",
                            f"=MAX(0,NETWORKDAYS(DATE({ab.year},{ab.month},{ab.day}),TODAY(),Feriados!$A$2:$A${nf})-1)"])
        ws2.cell(i, 6).number_format = "dd/mm/yyyy hh:mm"
        c = ws2.cell(i, 10)
        c.hyperlink = f"https://plataforma.xipp.com.br/web#id={r[9]}&model=helpdesk.ticket&view_type=form"
        c.font = Font(color="0563C1", underline="single")
    n2 = max(len(rows2) + 1, 2)
    tab2 = Table(displayName="DadosOperacionais", ref=f"A1:L{n2}")
    tab2.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    ws2.add_table(tab2)
    for col, w in zip("ABCDEFGHIJKL", [16, 12, 11, 8, 13, 17, 22, 20, 60, 8, 14, 14]):
        ws2.column_dimensions[col].width = w
    ws2.freeze_panes = "A2"
    ws2.conditional_formatting.add(f"K2:K{n2}", CellIsRule(operator="greaterThan", formula=["30"],
                                                          fill=PatternFill("solid", fgColor="F8CBAD")))
    ws2.conditional_formatting.add(f"K2:K{n2}", CellIsRule(operator="between", formula=["8", "30"],
                                                          fill=PatternFill("solid", fgColor="FFE699")))
    s.cell(len(RESP) + 5, 1, f"Aba Dados Operacionais: todos os {len(rows2)} atendimentos abertos da fila (todos os responsáveis exceto {', '.join(EXCLUIR_DO)}; sem Xipp bot); "
                     "Tipo 'Sinistro' = título com 'Relatório gerencial' ou 'Sinistro'; 'Outro' = não classificado como Carga/Layout/Sinistro.")
    resumo_do = collections.Counter(r[0] for r in rows2)
    resumo_tipo = collections.Counter(r[3] for r in rows2)
    print("DADOS_OPERACIONAIS", len(rows2), dict(resumo_do), dict(resumo_tipo),
          "parados_30d", sum(1 for r in rows2 if dias_uteis(r[5].date(), hoje_d, fer) > 30))
    wb.move_sheet(fs, offset=len(wb.sheetnames) - 1 - wb.index(fs))
    os.makedirs(os.path.dirname(os.path.abspath(a.saida)), exist_ok=True)
    wb.save(a.saida)

    cont = collections.Counter((r[0], r[3]) for r in rows)
    resumo = {"extraido_em": agora, "total": len(rows),
              "por_responsavel": {nm: {"Carga": cont[(nm, "Carga")], "Layout": cont[(nm, "Layout")],
                                       "parados_30d": sum(1 for r in rows if r[0] == nm and dias_uteis(r[5].date(), hoje_d, fer) > 30)}
                                  for nm in RESP}}
    if a.json:
        json.dump(resumo, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(resumo, ensure_ascii=False))


if __name__ == "__main__":
    main()
