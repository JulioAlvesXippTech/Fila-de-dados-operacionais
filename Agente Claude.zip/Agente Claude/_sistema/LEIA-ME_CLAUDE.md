# Agente de Atendimentos — guia para uma conversa nova do Claude

Leia este arquivo inteiro antes de qualquer rotina. Ele substitui o histórico das conversas anteriores.
Pasta de tudo: `C:\Users\JulioCesardaSilvaAlv\Downloads\Claude\Agente Claude\_sistema\` (no PC do Julio).
Plataforma (Vue + servidor.py): `...\Agente Claude\Plataforma\`. Pastas de trabalho: `...\Downloads\Claude\Layouts` e `...\Downloads\Claude\Carga SDI`.

## Como trabalhar (o Claude não tem terminal no PC do Julio)
1. **Preparar** (`device_stage_files`) os arquivos de `_sistema` necessários para a nuvem e rodar os scripts lá.
2. **Gravar de volta** com `device_commit_files`, **sempre a partir de um arquivo com nome NOVO** na nuvem
   (ex.: `envio/preanalise_<MMDD_HHMM>.json`) e com `expectedMtimeMs` do stage. Reenviar com o mesmo nome de origem
   já gravou versão antiga (12/11/2026). **Depois de gravar, preparar de novo e comparar (cmp)** para confirmar.
3. Nunca ler/exibir `credenciais.env`, `.env`, `state.json`, senhas. Nunca apagar arquivos do Julio. Nunca mudar a fila pelo Odoo
   (só o Vigia, com aprovação). Sem CPF/dados pessoais nos resumos.
4. Odoo: API via `credenciais.env` (`agente_atendimentos.Odoo`). Se der `ERRO_AUTENTICACAO`, a chave expirou: pedir ao Julio para
   renovar (Preferências → Segurança da conta → Nova chave de API). Alternativa cara: conector MCP da PX.

## Rotina 1 — "atualiza os atendimentos" (~2 min)
```
python3 preanalise_coleta.py --cred credenciais.env --saida coleta.json      # abertos da fila Dados Operacionais
python3 fila_completa.py     --cred credenciais.env --saida fila_completa.json
python3 novidades.py coleta.json                                              # só o que precisa de texto novo
```
- Escrever os textos dos NOVOS/MUDARAM em `preanalise_textos.json`: `{"id": [pedido, situacao, sugestao, acao, prioridade]}`.
  Ações válidas: Maninha, Carregador, Baixar/enviar PC, Cobrar operadora, Cobrar solicitante, Responder solicitante,
  Devolver ao solicitante, Repassar responsável (pessoa da MESMA fila), Reatribuir fila (outra fila, via Vigia),
  Aguardar terceiro, Tech/sistema, Carga sem arquivo – dados do contrato, Avançar para Em andamento, Encerrar, Outro.
- Xipp Bot com padrão conhecido recebe texto automático por `regras_bot.py` (códigos/senhas e divulgações → Encerrar;
  boletos/faturas/NF/pagamento → Reatribuir fila Faturamento; relatórios → sem sugestão fixa). Padrão novo → acrescentar lá.
- `python3 monta_pre.py coleta.json preanalise.json` e gravar `preanalise.json`, `fila_completa.json` e `preanalise_textos.json`.
- Responder ao Julio com HT + protocolo (nunca só o id interno).

## Rotina 2 — "roda as aprovações"
```
python3 aprovados.py --dirs direcionamentos.json listar
```
- **Encerrar**: `mudar_status.py --cred credenciais.env --id N --para fechar --out <pasta> --confirmar-producao`
- **Repassar responsável**: `acoes_manuais.py --cred credenciais.env --out <pasta> delegar --id N --para "Nome" --confirmar-producao`
  (só membros da fila Dados Operacionais; "João" é ambíguo → "João Lourenço").
- **Reatribuir fila**: `vigia_fila.py pedir --dirs direcionamentos.json --out pedidos --filas filas_px.json --cred credenciais.env --lote 28`
  e gravar cada pedido em `_sistema\_fila\`. O Vigia corta cada pedido em 60 min (~65 s por atendimento + 1,5 min).
  **Uma conferência só**, no horário estimado (`send_later`): `vigia_fila.py conferir --dirs ... --status-dir <_fila preparada>`.
  Se terminar em "Tempo esgotado", conferir pela API quem ainda está em Dados Operacionais e reenviar só esses.
- **Maninha**: `executar_maninha.py` → gravar a pasta em Layouts → `postar_criticador.py ... --confirmar-producao`.
- **Carregador**: `preparar_carregador.py` (aceita PDF) + skill "o-carregador-do-futuro" / "regras-carga-sdi-xipp" no formato
  escolhido na Plataforma (sdi/pc). **Não acionar o Vigia para baixar a base do SDI** (Julio, 13/11/2026): sem base em
  `Arquivo Origem`, gerar o arquivo `_PENDENTE` e deixar as perguntas em `Arquivo Final\Duvidas.txt` (aparecem na Plataforma).
- Depois de cada ação: `aprovados.py --dirs direcionamentos.json marcar --id N --status executado|falhou|manual --nota "..."`
  e gravar `direcionamentos.json` (log só de acréscimo; o Julio também grava nele pela Plataforma → sempre preparar antes).

## Regras e aprendizados
Ver `aprendizado.txt` (obrigatório). Destaques: contratos só Ativo/Em Implantação; API de carga só Bradesco Saúde/Dental e com
contrato Ativo; Encerrar preenche Assunto/Solicitação quando pedido; criticador vazio → pedir a base ao solicitante.
Fora da Plataforma (não trazer): Kennedy Pardinho, Marlon Ferreira, Marcello Nascimento, Jonas Vidal, Matheus Bessa,
Felipe Aranda, Francisco Souza (`relatorio_carga_layout.FORA_DA_PLATAFORMA`). Xipp Bot de Posição Cadastral/Faturamento: só contagem.

## Vigia (programa no PC do Julio)
Documentação: `Vigia_SDI_PX_Documentacao.md` (seção 9 = regras de uso pelo chat). Vivo se `_fila\vigia_ativo.txt` for recente.
O PC não pode suspender durante um lote (PowerToys Awake ou `powercfg /change standby-timeout-ac 0`).

## Pendências em 16/11/2026
- Morumbi Sul HT129917 (575387-1, 159 vidas) e HT129916 (575395-1, 5 vidas): layouts _PENDENTE em Carga SDI; dúvidas
  (base SDI/implantação, matrícula, sexo) na Plataforma.
- 5 Carregadores T-Systems e o 600883 (Uniodonto): falta o Julio escolher o formato na Plataforma; Saúde travado pelo erro de sub no SDI.
- Tarefa agendada "Executor de aprovados" ainda com instruções antigas: o Julio precisa aprovar a atualização no app do desktop.
- Plataforma: para recompilar a tela, copiar `Plataforma\frontend` para a nuvem, `npm install && npm run build`, gravar `dist`.
