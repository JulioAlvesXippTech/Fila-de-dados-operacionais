@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

rem Uso:  baixar_base.bat "Grupo Financeiro" Contrato "Pasta do cliente" ["Nome solicitante"] [debug]
rem Ex.:  baixar_base.bat "Grupo Caixa CNP" 511312 "C:\Users\JulioCesardaSilvaAlv\Downloads\Claude\Carga SDI\(#488167) Atualização de base - Grupo caixa - Odonto Empresas"

if "%~3"=="" (
  echo Uso: baixar_base.bat "Grupo Financeiro" Contrato "Pasta do cliente" ["Nome solicitante"] [debug]
  goto fim
)

set "PY=C:\Users\JulioCesardaSilvaAlv\AppData\Local\Programs\Python\Python311\python.exe"
if not exist "%PY%" set "PY=py -3"

set "EXTRA="
if not "%~4"=="" set EXTRA=--solicitante "%~4"
set "DBG="
if /i "%~5"=="debug" set "DBG=--discover"

echo Baixando base do SDI: %~1 / contrato %~2
%PY% sdi_baixar_base.py --grupo "%~1" --contrato %~2 --pasta "%~3" %EXTRA% %DBG% --visivel

:fim
echo.
pause
