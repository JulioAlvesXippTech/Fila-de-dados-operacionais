#!/usr/bin/env python3
"""Posta o Criticador de layout como NOTA INTERNA no atendimento, marcando o solicitante.

Escrita em PRODUÇÃO — só roda de verdade com --confirmar-producao (sem isso é sempre simulação/preview).
Escritas permitidas por este script (e nenhuma outra):
  1. ir.attachment.create  (o arquivo do criticador, vinculado ao helpdesk.ticket)
  2. helpdesk.ticket.message_post  (nota interna, subtype mail.mt_note, com @menção ao solicitante)
  3. (opcional, só com --encaminhar) helpdesk.ticket.write {team_id: Implantação, user_id: solicitante}
Nunca unlink. Backup/registro gravado antes de qualquer escrita.

Uso:
  python3 postar_criticador.py --cred credenciais.env --protocolo 566478-1 --arquivo "<criticador.xlsx>" --out <pasta>
        [--texto "Segue layout validado com inconsistências"] [--encaminhar] [--confirmar-producao]
"""
import re
import argparse, base64, html, json, os, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agente_atendimentos import Odoo, load_env, BRT

TEXTO = "Segue layout validado com inconsistências"
FILA_DESTINO = "Implantação"
# Mudança de fila/atribuído ainda NÃO liberada pelo Julio (07/10/2026: "por enquanto sem mudar a fila e atribuído").
ENCAMINHAR_LIBERADO = False


def rpc_write(o, model, method, args, kw=None):
    """Única porta de escrita deste script."""
    if (model, method) not in {("ir.attachment", "create"), ("helpdesk.ticket", "message_post"),
                               ("helpdesk.ticket", "write")}:
        sys.exit(f"Escrita não permitida: {model}.{method}")
    if o.uid is None:
        o.call("res.users", "search_count", [[["id", "=", -1]]])
    return o._post("/jsonrpc", {"service": "object", "method": "execute_kw",
                                "args": [o.db, o.uid, o.key, model, method, args, kw or {}]})


def solicitante(o, t):
    """Resolve o solicitante -> (partner_id, nome, user_id ou None)."""
    campo = t.get("xipp_requester_id") or t.get("partner_id")
    if not campo:
        return None, None, None
    rel = o.call("helpdesk.ticket", "fields_get", [], {"allfields": ["xipp_requester_id"], "attributes": ["relation"]})
    modelo = (rel.get("xipp_requester_id") or {}).get("relation") if t.get("xipp_requester_id") else "res.partner"
    rid, nome = campo
    if modelo == "res.users":
        u = o.call("res.users", "read", [[rid]], {"fields": ["partner_id", "name"]})[0]
        return u["partner_id"][0], u["name"], rid
    if modelo == "res.partner":
        us = o.call("res.users", "search_read", [[["partner_id", "=", rid]]], {"fields": ["id"], "limit": 1})
        return rid, nome, (us[0]["id"] if us else None)
    rec = o.call(modelo, "read", [[rid]], {"fields": ["display_name", "partner_id", "user_id"]})[0]
    pid = rec.get("partner_id") and rec["partner_id"][0]
    uid = rec.get("user_id") and rec["user_id"][0]
    if not pid and uid:
        pid = o.call("res.users", "read", [[uid]], {"fields": ["partner_id"]})[0]["partner_id"][0]
    return pid, rec.get("display_name") or nome, uid


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--protocolo", required=True)
    ap.add_argument("--arquivo", required=True, nargs="+")
    ap.add_argument("--out", required=True)
    ap.add_argument("--texto", default=TEXTO)
    ap.add_argument("--encaminhar", action="store_true")
    ap.add_argument("--confirmar-producao", action="store_true")
    ap.add_argument("--controle", default="", help="json com postagens já feitas (evita postar o mesmo arquivo 2x)")
    a = ap.parse_args()
    if a.encaminhar and a.confirmar_producao and not ENCAMINHAR_LIBERADO:
        sys.exit("Mudança de fila/atribuído ainda não liberada pelo Julio")
    ctrl = {}
    if a.controle and os.path.exists(a.controle):
        ctrl = json.load(open(a.controle, encoding="utf-8"))
    if a.protocolo in ctrl.get("_bloqueados", []):
        print(json.dumps({"pulado": "protocolo na lista _bloqueados de _controle_postagens.json - não postar"}, ensure_ascii=False))
        return
    chave_ctrl = f"{a.protocolo}|" + "+".join(sorted(os.path.basename(x) for x in a.arquivo))
    if chave_ctrl in ctrl:
        print(json.dumps({"pulado": "já postado", "em": ctrl[chave_ctrl]}, ensure_ascii=False))
        return
    os.makedirs(a.out, exist_ok=True)
    o = Odoo(load_env(a.cred))
    ts = o.call("helpdesk.ticket", "search_read", [[["protocol_code", "=", a.protocolo]]],
                {"fields": ["id", "number", "protocol_code", "name", "user_id", "team_id", "stage_id",
                            "xipp_requester_id", "partner_id"], "limit": 2})
    if len(ts) != 1:
        sys.exit(f"Esperava 1 atendimento com protocolo {a.protocolo}, achei {len(ts)}")
    t = ts[0]
    pid, nome, uid_sol = solicitante(o, t)
    if not pid:
        sys.exit("Solicitante sem contato (partner) - não dá para marcar")
    fila = o.call("helpdesk.ticket.team", "search_read", [[["name", "=", FILA_DESTINO]]], {"fields": ["id"], "limit": 2})
    corpo = (f'<p><a href="/odoo/res.partner/{pid}" class="o_mail_redirect" data-oe-id="{pid}" '
             f'data-oe-model="res.partner" target="_blank">@{html.escape(nome)}</a></p>'
             + "".join(f"<p>{html.escape(p)}</p>" for p in a.texto.replace("\\n", "\n").split("\n") if p.strip()))
    plano = {"atendimento": t["number"], "protocolo": t["protocol_code"], "titulo": t["name"],
             "solicitante": nome, "partner_id": pid, "user_id_solicitante": uid_sol,
             "nota_interna": f"@{nome}\n{a.texto}", "anexos": [os.path.basename(x) for x in a.arquivo],
             "antes": {"fila": t["team_id"], "atribuido": t["user_id"], "etapa": t["stage_id"]}}
    if a.encaminhar:
        plano["depois"] = {"fila": FILA_DESTINO, "fila_id": fila[0]["id"] if len(fila) == 1 else None,
                           "atribuido": nome, "user_id": uid_sol}
        if len(fila) != 1:
            plano["bloqueio"] = f"Fila '{FILA_DESTINO}' não encontrada de forma única"
        if not uid_sol:
            plano["bloqueio"] = "Solicitante não é usuário interno do Odoo - não pode ser 'Atribuído a'"
    agora = datetime.now(BRT)
    bpath = os.path.join(a.out, f"backup_nota_{t['protocol_code']}_{agora.strftime('%Y%m%d_%H%M')}.json")
    plano["modo"] = "PRODUÇÃO" if a.confirmar_producao else "SIMULAÇÃO (nada gravado)"
    json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    if not a.confirmar_producao:
        print(json.dumps(plano, ensure_ascii=False, indent=1, default=str))
        return
    if plano.get("bloqueio") and a.encaminhar:
        sys.exit(plano["bloqueio"])
    atts = []
    for arq in a.arquivo:
        dados = base64.b64encode(open(arq, "rb").read()).decode()
        att = rpc_write(o, "ir.attachment", "create", [{"name": os.path.basename(arq), "datas": dados,
                                                         "res_model": "helpdesk.ticket", "res_id": t["id"]}])
        atts.append(att[0] if isinstance(att, list) else att)
    msg = rpc_write(o, "helpdesk.ticket", "message_post", [[t["id"]]],
                    {"body": corpo, "body_is_html": True, "message_type": "comment", "subtype_xmlid": "mail.mt_note",
                     "partner_ids": [pid], "attachment_ids": atts})
    if not isinstance(msg, int):  # 29/10/2026: o Odoo passou a devolver "mail.message(123,)"
        m_id = re.search(r"\d+", str(msg))
        msg = int(m_id.group()) if m_id else msg
    plano["resultado"] = {"attachment_ids": atts, "message_id": msg}
    lido = o.call("mail.message", "read", [[msg]], {"fields": ["body"]})[0]["body"] or ""
    plano["resultado"]["corpo_ok"] = "&lt;p&gt;" not in lido and "<p>" in lido
    if a.controle:
        ctrl[chave_ctrl] = {"quando": datetime.now(BRT).isoformat(), "atendimento": t["number"], "message_id": msg}
        json.dump(ctrl, open(a.controle, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if a.encaminhar:
        rpc_write(o, "helpdesk.ticket", "write", [[t["id"]], {"team_id": fila[0]["id"], "user_id": uid_sol}])
        d = o.call("helpdesk.ticket", "read", [[t["id"]]], {"fields": ["team_id", "user_id"]})[0]
        plano["resultado"]["depois_lido"] = d
    json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(plano["resultado"], ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
