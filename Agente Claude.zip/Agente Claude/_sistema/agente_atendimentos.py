#!/usr/bin/env python3
"""Agente de Atendimentos - leitura (SOMENTE LEITURA) dos atendimentos da plataforma.xipp.com.br (PROD_18).

Uso:
  python3 agente_atendimentos.py --cred credenciais.env --state _controle_atendimentos.json --out <pasta_saida>

Gera em <pasta_saida>:
  novos_atendimentos.json        -> atendimentos novos ou com atualizacao desde a ultima execucao
  _controle_atendimentos.json    -> estado atualizado (so deve substituir o anterior DEPOIS de gravar o TXT)

Filtro (igual a tela do Odoo do Julio):
  Fila contem "Dados operacionais", status nao dobrado no kanban, solicitante nao contem "Xipp bot",
  responsavel = Julio Alves / Renan Silva / Joao Lourenco / sem responsavel.
Nunca escreve nada no Odoo: so search_read / read / search_count.
"""
import argparse, base64, html, json, os, re, sys, urllib.request
from datetime import datetime, timezone, timedelta

READ_ONLY = {"search_read", "read", "search_count", "fields_get"}
RESPONSAVEIS = ["Julio Alves", "Renan Silva", "João Lourenço"]
BRT = timezone(timedelta(hours=-3))


def load_env(path):
    env = {}
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return env


class Odoo:
    def __init__(self, env):
        self.url = env.get("ODOO_URL", "https://plataforma.xipp.com.br").rstrip("/")
        self.db, self.login = env.get("ODOO_DB"), env.get("ODOO_LOGIN")
        self.key, self.sid = env.get("ODOO_API_KEY"), env.get("ODOO_SESSION_ID")
        if not self.sid and not (self.db and self.login and self.key):
            sys.exit("CREDENCIAL_AUSENTE: preencha ODOO_DB, ODOO_LOGIN e ODOO_API_KEY em credenciais.env")
        self.uid = None

    def _post(self, path, params, cookie=None):
        req = urllib.request.Request(self.url + path,
                                     json.dumps({"jsonrpc": "2.0", "method": "call", "params": params}).encode(),
                                     {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0 (agente-atendimentos)"})
        if cookie:
            req.add_header("Cookie", f"session_id={cookie}")
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read())
        if data.get("error"):
            e = data["error"].get("data", {})
            sys.exit(f"ERRO_ODOO {e.get('name', '')}: {e.get('message', data['error'].get('message'))}")
        return data["result"]

    def call(self, model, method, args, kw=None):
        if method not in READ_ONLY:
            sys.exit(f"Metodo {method} bloqueado (somente leitura)")
        kw = dict(kw or {}, context={"lang": "pt_BR"})
        if self.sid:
            return self._post("/web/dataset/call_kw", {"model": model, "method": method, "args": args, "kwargs": kw}, self.sid)
        if self.uid is None:
            self.uid = self._post("/jsonrpc", {"service": "common", "method": "authenticate",
                                               "args": [self.db, self.login, self.key, {}]})
            if not self.uid:
                sys.exit("ERRO_AUTENTICACAO: login ou API key invalidos/revogados")
        return self._post("/jsonrpc", {"service": "object", "method": "execute_kw",
                                       "args": [self.db, self.uid, self.key, model, method, args, kw]})


def txt(h):
    t = html.unescape(re.sub(r"<br\s*/?>|</p>|</div>|</li>", "\n", h or "", flags=re.I))
    t = re.sub(r"<[^>]+>", "", t)
    return re.sub(r"\n\s*\n+", "\n", re.sub(r"[ \t\xa0]+", " ", t)).strip()


def brt(s):
    if not s:
        return ""
    return datetime.strptime(s, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).astimezone(BRT).strftime("%d/%m/%Y %H:%M")


def m2o(v):
    return v[1] if v else ""


def d(v):
    return datetime.strptime(v, "%Y-%m-%d").strftime("%d/%m/%Y") if v else ""


STATUS_OK = ("Ativo", "Em Implantação")  # regra do Julio (28/10/2026): só usar contrato/sub ativo ou em implantação


def contrato_info(o, cid):
    """Dados do contrato vinculado ao atendimento (somente leitura). Nunca le senhas de portal."""
    if not cid:
        return None
    try:
        c = o.call("xipp.contract", "read", [[cid]], {"fields": [
            "name", "policy", "carrier_id", "benefit_id", "cnpj", "business_name", "state_name", "start_date",
            "end_date", "sum_lives", "lives", "financial_group_id", "subcontract", "parent_contract",
            "subcontract_ids", "plan", "portal_access_ids", "cut_off_date"]})[0]
    except SystemExit as e:
        return {"erro": str(e)[:200]}
    info = {"id": cid, "contrato": c["name"], "apolice": c["policy"] or "", "operadora": m2o(c["carrier_id"]),
            "beneficio": m2o(c["benefit_id"]), "razao_social": c["business_name"] or "", "cnpj": c["cnpj"] or "",
            "status": c["state_name"] or "", "inicio": d(c["start_date"]), "fim": d(c["end_date"]),
            "vidas": c["sum_lives"] or c["lives"] or 0, "grupo_financeiro": m2o(c["financial_group_id"]),
            "contrato_pai": m2o(c["parent_contract"]), "dia_corte": c["cut_off_date"] or "",
            "planos": [], "subcontratos": [], "portais": [], "subcontratos_ignorados": []}
    info["status_ok"] = info["status"] in STATUS_OK
    if c["plan"]:
        for p in o.call("xipp.contract.plan", "read", [c["plan"][:30]], {"fields": [
                "plan_id_name", "plan_policy", "accommodation_id", "plan_id_geographic_scope_xipp_id", "start_date", "end_date"]}):
            cod = p["plan_policy"] or ""
            info["planos"].append({"nome": p["plan_id_name"] or "", "codigo": cod,
                                   "codigo_plano": cod.split("-", 1)[1] if "-" in cod else cod,
                                   "acomodacao": m2o(p["accommodation_id"]), "abrangencia": p["plan_id_geographic_scope_xipp_id"] or "",
                                   "inicio": d(p["start_date"]), "fim": d(p["end_date"])})
    if c["subcontract_ids"]:
        for sc in o.call("xipp.contract", "read", [c["subcontract_ids"][:30]], {"fields": ["name", "cnpj", "state_name", "subcontract_number", "business_name"]}):
            reg = {"nome": sc["name"], "cnpj": sc["cnpj"] or "", "status": sc["state_name"] or "",
                   "codigo": (sc["subcontract_number"] or "").strip(), "razao_social": sc["business_name"] or ""}
            # subempresas fora de Ativo/Em Implantação (Fechado, Cancelado...) ficam só como contagem
            (info["subcontratos"] if reg["status"] in STATUS_OK else info["subcontratos_ignorados"]).append(reg)
        info["total_subcontratos"] = len(c["subcontract_ids"])
    if c["portal_access_ids"]:
        # campos sem senha (a senha fica só no Odoo: use o link do acesso)
        for pa in o.call("xipp.portal.access", "read", [c["portal_access_ids"][:20]], {"fields": ["name", "portal_name", "site", "login"]}):
            info["portais"].append({"id": pa["id"], "codigo": pa["name"], "portal": pa["portal_name"] or "", "site": pa["site"] or "",
                                    "login": pa["login"] or "",
                                    "link": f"https://plataforma.xipp.com.br/web#id={pa['id']}&model=xipp.portal.access&view_type=form"})
    return info



def dominio_filtro():
    resp = ["|"] * len(RESPONSAVEIS) + [["user_id", "=", False]] + [["user_id", "ilike", n] for n in RESPONSAVEIS]
    return [["team_id", "ilike", "Dados operacionais"], ["stage_id.fold", "=", False],
            ["xipp_requester_id", "not ilike", "Xipp bot"]] + resp


def _sem_acento(s):
    import unicodedata
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()


def contrato_por_cnpj(o, texto):
    """Procura CNPJ (14 digitos, com ou sem mascara) no texto e escolhe o contrato cuja operadora/beneficio aparece no titulo."""
    for raw in re.findall(r"\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}", texto):
        d = re.sub(r"\D", "", raw)
        if len(d) != 14:
            continue
        fmt = f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"
        try:
            cs = o.call("xipp.contract", "search_read", [[["cnpj", "in", [fmt, d]], ["subcontract", "=", False]]],
                        {"fields": ["id", "name", "carrier_id", "benefit_id", "state_name", "policy"], "limit": 30})
        except SystemExit:
            return None
        if not cs:
            continue
        tn = _sem_acento(texto)
        def score(c):
            pts = 0
            for campo in (c["carrier_id"], c["benefit_id"]):
                if campo:
                    nome = _sem_acento(campo[1].split(" - ")[0])
                    if nome and nome.split()[0] in tn:
                        pts += 2
            if c["policy"] and c["policy"] in texto:
                pts += 1
            if c["state_name"] in STATUS_OK:
                pts += 3
            return pts
        cs.sort(key=score, reverse=True)
        info = contrato_info(o, cs[0]["id"])
        if info and not info.get("erro"):
            info["identificado_pelo_texto"] = True
            outros = [c["name"] + " (" + (c["benefit_id"][1] if c["benefit_id"] else "") + ")" for c in cs[1:6]]
            if outros:
                info["outros_contratos_citados"] = outros
        return info
    return None


GENERICOS = {"atualizacao", "base", "de", "da", "do", "posicao", "cadastral", "carga", "sdi", "saude", "odonto", "vida",
             "time", "atendimento", "xipp", "rh", "protegido", "ativacao", "beneficios", "layout", "enc", "res", "fw", "ajuste",
             "ajustes", "implantacao", "operadora", "amil", "bradesco", "sulamerica", "unimed", "porto", "gndi", "hapvida",
             "odontoprev", "metlife", "seguros", "ltda", "s.a.", "sa", "pj", "dental"}


def contrato_pelo_nome(o, t):
    """Último recurso: procura o nome do cliente citado no título (ex.: 'Atualização de base - Ecran')."""
    titulo = re.sub(r"\s+", " ", (t.get("name") or "").replace("|", " - ")).strip()
    tn = _sem_acento(titulo)
    cand = []
    for seg in re.split(r"\s[-–]\s|:", titulo):
        palavras = [w for w in re.findall(r"[\wÀ-ú&]+", seg) if _sem_acento(w) not in GENERICOS and len(w) >= 3 and not w.isdigit()]
        if palavras:
            cand.append(" ".join(palavras[:3]))
    for termo in cand:
        try:
            cs = o.call("xipp.contract", "search_read", [[["name", "ilike", termo], ["subcontract", "=", False]]],
                        {"fields": ["id", "name", "carrier_id", "benefit_id", "state_name"], "limit": 30})
        except SystemExit:
            return None
        if not cs:
            continue
        def score(c):
            pts = sum(2 for campo in (c["carrier_id"], c["benefit_id"]) if campo and _sem_acento(campo[1].split(" - ")[0]).split()[0] in tn)
            return pts + (3 if c.get("state_name") in ("Ativo", "Em Implantação") else 0)
        cs.sort(key=score, reverse=True)
        info = contrato_info(o, cs[0]["id"])
        if info and not info.get("erro"):
            info["identificado_pelo_texto"] = True
            info["identificado_pelo_nome"] = termo
            if len(cs) > 1:
                info["outros_contratos_citados"] = [c["name"] + " (" + (c["benefit_id"][1] if c["benefit_id"] else "") + ")" for c in cs[1:6]]
        return info
    return None


def contrato_pelo_texto(o, t):
    """Sem contrato vinculado: procura numeros de apolice no titulo/descricao (ex.: 'Carga SDI - 8360 - Liceu')."""
    texto = f"{t['name']} {txt(t['description'])[:600]}"
    por_cnpj = contrato_por_cnpj(o, texto)
    if por_cnpj:
        return por_cnpj
    nums = list(dict.fromkeys(re.findall(r"(?<![\d./-])(\d{4,9}[A-Z0-9]{0,3})(?![\d./-])", texto)))[:6]
    nums += [c for c in re.findall(r"\b([0-9A-Z]{5,6})\b", t["name"] or "") if re.search(r"\d", c) and re.search(r"[A-Z]", c)][:3]
    if not nums:
        return contrato_pelo_nome(o, t)
    try:
        achados = o.call("xipp.contract", "search_read", [[["policy", "in", nums], ["subcontract", "=", False]]],
                         {"fields": ["id", "state_name"], "limit": 10})
        achados.sort(key=lambda c: 0 if c.get("state_name") in STATUS_OK else 1)  # prefere ativo/em implantação
        achados = achados[:3]
    except SystemExit:
        return None
    if not achados:
        return contrato_pelo_nome(o, t)
    info = contrato_info(o, achados[0]["id"])
    if info and not info.get("erro"):
        info["identificado_pelo_texto"] = True
        if len(achados) > 1:
            info["outros_contratos_citados"] = [contrato_info(o, x["id"])["contrato"] for x in achados[1:]]
    return info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--state", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    o = Odoo(load_env(a.cred))
    state = {}
    if os.path.exists(a.state):
        state = json.load(open(a.state, encoding="utf-8"))
    vistos = state.get("atendimentos", {})

    domain = dominio_filtro()
    tickets = o.call("helpdesk.ticket", "search_read", [domain], {
        "fields": ["id", "name", "number", "protocol_code", "stage_id", "user_id", "xipp_requester_id", "partner_id",
                   "ticket_type_id", "xipp_request_id", "xipp_contract_id", "create_date", "sla_deadline", "sla_fail",
                   "description"], "limit": 2000, "order": "create_date asc"})
    ids = [t["id"] for t in tickets]
    msgs = o.call("mail.message", "search_read", [[["model", "=", "helpdesk.ticket"], ["res_id", "in", ids]]],
                  {"fields": ["id", "res_id"], "limit": 100000}) if ids else []
    atts = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "in", ids]]],
                  {"fields": ["id", "res_id"], "limit": 100000}) if ids else []
    sig = {i: {"msg": 0, "att": 0} for i in ids}
    for m in msgs:
        sig[m["res_id"]]["msg"] = max(sig[m["res_id"]]["msg"], m["id"])
    for x in atts:
        sig[x["res_id"]]["att"] = max(sig[x["res_id"]]["att"], x["id"])

    novos = []
    for t in tickets:
        s, ant = sig[t["id"]], vistos.get(str(t["id"]))
        if ant and ant.get("msg") == s["msg"] and ant.get("att") == s["att"] and ant.get("status") == m2o(t["stage_id"]):
            continue
        motivo = "novo" if not ant else "atualizado"
        ultimo_msg_visto = ant.get("msg", 0) if ant else 0
        mm = o.call("mail.message", "search_read", [[["model", "=", "helpdesk.ticket"], ["res_id", "=", t["id"]]]],
                    {"fields": ["id", "date", "author_id", "message_type", "subtype_id", "body", "attachment_ids"],
                     "order": "date asc", "limit": 300})
        historico = [{"data": brt(m["date"]), "autor": m2o(m["author_id"]), "tipo": m2o(m["subtype_id"]) or m["message_type"],
                      "texto": txt(m["body"])[:2000], "anexos": m["attachment_ids"], "novo": m["id"] > ultimo_msg_visto}
                     for m in mm if txt(m["body"]) or m["attachment_ids"]]
        aa = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "=", t["id"]]]],
                    {"fields": ["id", "name", "mimetype", "file_size", "create_date", "create_uid"],
                     "order": "create_date desc", "limit": 50})
        novos.append({
            "id": t["id"], "motivo": motivo, "numero": t["number"], "protocolo": t["protocol_code"], "titulo": t["name"],
            "status": m2o(t["stage_id"]), "responsavel": m2o(t["user_id"]) or "Sem responsável",
            "solicitante": m2o(t["xipp_requester_id"]), "cliente": m2o(t["partner_id"]),
            "assunto": m2o(t["ticket_type_id"]), "solicitacao": m2o(t["xipp_request_id"]),
            "contrato": m2o(t["xipp_contract_id"]),
            "contrato_info": contrato_info(o, t["xipp_contract_id"][0]) if t["xipp_contract_id"] else contrato_pelo_texto(o, t), "criado_em": brt(t["create_date"]),
            "sla_estourado": t["sla_fail"], "descricao": txt(t["description"])[:4000],
            "link": f"{o.url}/web#id={t['id']}&model=helpdesk.ticket&view_type=form",
            "arquivos": [{"id": x["id"], "nome": x["name"], "tipo": x["mimetype"], "kb": round((x["file_size"] or 0) / 1024, 1),
                          "enviado_em": brt(x["create_date"]), "enviado_por": m2o(x["create_uid"]),
                          "novo": x["id"] > (ant.get("att", 0) if ant else 0)} for x in aa],
            "historico": historico})

    agora = datetime.now(BRT).strftime("%d/%m/%Y %H:%M")
    novo_state = {"ultima_execucao": agora, "atendimentos": {
        str(t["id"]): {"msg": sig[t["id"]]["msg"], "att": sig[t["id"]]["att"], "status": m2o(t["stage_id"]),
                       "numero": t["number"]} for t in tickets}}
    # mantem historico de atendimentos que sairam do filtro (para nao reabrir se voltarem sem novidade)
    for k, v in vistos.items():
        novo_state["atendimentos"].setdefault(k, v)
    # preserva as demais chaves do controle (ex.: "encaminhados" gravado pelo encaminhar.py)
    for k, v in state.items():
        if k not in novo_state:
            novo_state[k] = v
    json.dump({"execucao": agora, "total_no_filtro": len(tickets), "novos_ou_atualizados": novos},
              open(os.path.join(a.out, "novos_atendimentos.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(novo_state, open(os.path.join(a.out, "_controle_atendimentos.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps({"execucao": agora, "total_no_filtro": len(tickets), "novos_ou_atualizados": len(novos)}))


if __name__ == "__main__":
    main()
