"""Uso: python3 monta_pre.py <coleta.json> <saida preanalise.json>
Monta preanalise.json = coleta (preanalise_coleta.py) + textos do Claude (textos.json) + regras aprendidas.
Regras: _sistema/aprendizado.txt. textos.json: {id: [pedido, situacao, sugestao, acao, prioridade]} (sem os prefixos automáticos)."""
import json, re, sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from regras_bot import regra
from datetime import datetime
col, saida = sys.argv[1], sys.argv[2]
AQUI = __import__('os').path.dirname(__import__('os').path.abspath(__file__))
T = {int(k): v for k, v in json.load(open(__import__('os').path.join(AQUI, 'preanalise_textos.json'), encoding='utf-8')).items()}


def api_bradesco(dc):
    op = (dc.get('operadora') or '').lower()
    return op.startswith(('bradesco saude', 'bradesco saúde', 'bradesco dental'))


c = json.load(open(col, encoding='utf-8'))
faltam = []
for i in c['itens']:
    t = T.get(i['id'])
    r = regra(i['titulo'], bool(i.get('bot'))) if not t else None
    if r:   # 11/11/2026: Xipp Bot com padrão conhecido -> texto por regra (sem o Claude escrever um a um)
        n, acao, prio, pedido, sug = r
        d = (i.get('abertura') or '')[:5]
        t = [f"{pedido} — {i['titulo'][:90]}", f"Aberto pelo Xipp Bot em {d}; etapa {i['etapa']}, {i['responsavel']}.", sug, acao, prio]
        i['regra_bot'] = n
    if not t:
        faltam.append(i['id']); continue
    pa = dict(zip(['pedido', 'situacao', 'sugestao', 'acao', 'prioridade'], t))
    dc = i.get('dados_contrato')
    if dc and not dc.get('erro'):
        pa['acao_original'] = pa['acao']
        if dc.get('status') == 'Em Implantação' and i.get('tipo') == 'Carga' and i.get('etapa') == 'Novo' and api_bradesco(dc):
            # aprendizado 29/10/2026: API de carga só Bradesco Saúde/Dental, e só com contrato Ativo
            pa['acao'] = 'Devolver ao solicitante'
            pa['sugestao'] = f"Contrato {dc['contrato']} Em Implantação (Bradesco, carga via API só com contrato Ativo) — devolver ao solicitante. " + pa['sugestao']
        elif dc.get('status_ok') is False:
            pa['sugestao'] = f"Contrato {dc['contrato']} está '{dc['status']}' (não está Ativo nem Em Implantação) — confirmar o contrato antes da carga. " + pa['sugestao']
        else:
            pa['acao'] = 'Carga sem arquivo – dados do contrato'
            dedu = dc.get('identificado_pelo_texto') or dc.get('identificado_pelo_nome')
            if dc['portais']: extra = f"Carga sem arquivo: {len(dc['portais'])} acesso(s) cadastrado(s) no contrato para baixar a base no portal (dados abaixo)."
            elif dedu: extra = "Carga sem arquivo e contrato (deduzido do título) sem acesso cadastrado — vincular o contrato no atendimento para eu pedir a base/acesso ao solicitante."
            else: extra = "Carga sem arquivo e contrato SEM acesso cadastrado — ao executar, posto nota interna pedindo a base/acesso ao solicitante."
            pa['sugestao'] = extra + ' ' + pa['sugestao']
    i['pre_analise'] = pa
if faltam:
    sys.exit(f"faltam textos para: {faltam}")
c['gerado_em'] = datetime.now().strftime('%d/%m/%Y %H:%M')
json.dump(c, open(saida, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('ok', len(c['itens']))
