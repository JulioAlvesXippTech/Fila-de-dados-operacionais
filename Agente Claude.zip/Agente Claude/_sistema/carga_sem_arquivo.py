#!/usr/bin/env python3
"""Ação "Carga sem arquivo – dados do contrato" (direcionamento do Julio, 27/10/2026).

Para atendimento de CARGA sem planilha anexada:
  1. levanta do contrato: apólice, subempresas com código, planos com código e acessos cadastrados
     (site e login; a SENHA nunca é lida — o arquivo traz o link do acesso no Odoo);
  2. monta Carga SDI\\(#<protocolo>) <título>\\_Dados do contrato.txt em --out (para gravar no computador);
  3. se o contrato NÃO tiver acesso cadastrado: nota interna marcando o solicitante
     (só com --confirmar-producao; única escrita no Odoo: helpdesk.ticket.message_post).

Uso: python3 carga_sem_arquivo.py --cred credenciais.env --id 591930 --out <pasta> [--controle _controle_postagens.json]
                                  [--json res.json] [--confirmar-producao]
Saída 4 = atendimento já tem planilha (não se aplica); 5 = contrato não identificado ou fora de Ativo/Em Implantação.
"""
import argparse, html, json, os, re, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import encaminhar as E
from agente_atendimentos import Odoo, load_env, BRT, contrato_info, contrato_pelo_texto
from postar_criticador import solicitante, rpc_write

# planilhas, compactados e e-mails/PDF (podem trazer a base dentro) contam como "tem arquivo"
ARQ = re.compile(r"\.(xlsx|xlsm|xls|xlsb|ods|csv|txt|zip|rar|7z|eml|msg|pdf)$", re.I)
NOTA = ("O contrato {contrato} não possui acesso ao portal da operadora cadastrado. "
        "Favor anexar a base no atendimento ou cadastrar o acesso no contrato.")


def levantar(o, t):
    """Dados do contrato do atendimento (somente leitura). Retorna dict ou None."""
    if t.get("xipp_contract_id"):
        return contrato_info(o, t["xipp_contract_id"][0])
    return contrato_pelo_texto(o, t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--id", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--controle", default="")
    ap.add_argument("--json", default="")
    ap.add_argument("--confirmar-producao", action="store_true")
    a = ap.parse_args()
    o = Odoo(load_env(a.cred))
    t = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["number", "protocol_code", "name", "description",
                                                               "xipp_contract_id", "xipp_requester_id", "partner_id"]})[0]
    prot, titulo = t["protocol_code"], (t["name"] or "").strip()
    res = {"id": a.id, "atendimento": t["number"], "protocolo": prot, "gravar": []}
    atts = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "=", a.id]]],
                  {"fields": ["name"]})
    arqs = [x["name"] for x in atts if ARQ.search(x["name"] or "")]
    if arqs:
        res["erro"] = "atendimento já tem arquivo anexado: " + ", ".join(arqs[:5])
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(4)
    ci = levantar(o, t)
    if not ci or ci.get("erro"):
        res["erro"] = "contrato não identificado no atendimento" + (f" ({ci['erro']})" if ci and ci.get("erro") else "")
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(5)
    if not ci.get("status_ok"):
        # regra do Julio (28/10/2026): só seguir com contrato Ativo ou Em Implantação
        res["erro"] = f"contrato {ci['contrato']} está '{ci['status']}' (não está Ativo nem Em Implantação) - confirmar o contrato"
        res["contrato"] = ci
        if a.json:
            json.dump(res, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(json.dumps({k: v for k, v in res.items() if k != "contrato"}, ensure_ascii=False))
        sys.exit(5)
    res["contrato"] = ci
    pasta = E.nome_pasta(prot, titulo)
    base = os.path.join(a.out, "Carga SDI", pasta)
    os.makedirs(base, exist_ok=True)
    txt = E.texto_contrato(t["number"], titulo, ci) + (
        "\nCARGA SEM ARQUIVO: o atendimento não tem base anexada. Use os acessos acima para baixar a base no portal da operadora.\n"
        if ci["portais"] else
        "\nCARGA SEM ARQUIVO e contrato SEM ACESSO cadastrado: nota interna postada pedindo a base/acesso ao solicitante.\n")
    p = os.path.join(base, "_Dados do contrato.txt")
    open(p, "w", encoding="utf-8-sig", newline="\r\n").write(txt)
    res["gravar"].append({"local": p, "relativo": os.path.relpath(p, a.out).replace("/", "\\")})
    res["sem_acesso"] = not ci["portais"]
    if res["sem_acesso"]:
        pid, nome, _ = solicitante(o, t)
        texto = NOTA.format(contrato=ci["contrato"])
        res["nota_interna"] = f"@{nome}\n{texto}" if pid else None
        chave = f"{prot}|sem_acesso"
        ctrl = json.load(open(a.controle, encoding="utf-8")) if a.controle and os.path.exists(a.controle) else {}
        if not t.get("xipp_contract_id"):
            res["erro_nota"] = ("contrato não está vinculado no atendimento (foi deduzido do título/texto) - "
                                "nota não postada; confirmar o contrato")
        elif not pid:
            res["erro_nota"] = "solicitante sem contato no Odoo - nota não postada"
        elif chave in ctrl:
            res["nota_pulada"] = "já postada em " + str(ctrl[chave].get("quando"))
        elif a.confirmar_producao:
            corpo = (f'<p><a href="/odoo/res.partner/{pid}" class="o_mail_redirect" data-oe-id="{pid}" '
                     f'data-oe-model="res.partner" target="_blank">@{html.escape(nome)}</a></p><p>{html.escape(texto)}</p>')
            bk = os.path.join(a.out, f"backup_nota_{prot}_{datetime.now(BRT):%Y%m%d_%H%M}_sem_acesso.json")
            json.dump({"atendimento": t["number"], "protocolo": prot, "nota": res["nota_interna"]},
                      open(bk, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            try:
                msg = rpc_write(o, "helpdesk.ticket", "message_post", [[a.id]],
                                {"body": corpo, "body_is_html": True, "message_type": "comment",
                                 "subtype_xmlid": "mail.mt_note", "partner_ids": [pid]})
            except SystemExit as e:
                res["erro_nota"] = "RECUSADO PELO ODOO: " + str(e)[:200]
            else:
                res["message_id"] = msg
                if a.controle:
                    ctrl[chave] = {"quando": datetime.now(BRT).isoformat(), "atendimento": t["number"], "message_id": msg}
                    json.dump(ctrl, open(a.controle, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        else:
            res["modo"] = "SIMULAÇÃO (nota não postada)"
    if a.json:
        json.dump(res, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in res.items() if k != "contrato"}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
