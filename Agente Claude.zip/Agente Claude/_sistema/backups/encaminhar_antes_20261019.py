#!/usr/bin/env python3
"""Encaminha atendimentos respondidos no TXT para o Maninha (Layouts) ou para o Carregador do Futuro (Carga SDI).
SOMENTE LEITURA no Odoo: apenas le o atendimento e baixa os anexos (ir.attachment.datas).

Uso:
  python3 encaminhar.py --cred credenciais.env --state _controle_atendimentos.json \
      --modelo Modelo_Carga_SDI.xlsx --out <pasta_saida> TXT1 [TXT2 ...]

Resposta no "R:" de cada atendimento:
  1 / maninha            -> Layouts
  2 / carregador         -> Carga SDI
  3 / sem acao           -> nada
  ok / sim / de acordo   -> aceita a "Sugestão do Claude"
  Se o texto citar o nome de um anexo (ex.: "1 usar 8060.xlsx"), baixa so esse(s) arquivo(s).
  Qualquer outro texto -> "Outro": nada e automatico, vai para o relatorio.

ATUALIZACAO DE BASE (regra confirmada pelo Julio em 06/10/2026):
  Com --auto-atualizacao, todo atendimento do filtro identificado como atualizacao de base / posicao
  cadastral e encaminhado AUTOMATICAMENTE (sem esperar o R:) para a Carga SDI, desde que tenha base anexada.
  Os anexos de planilha sao separados pelo conteudo do cabecalho:
    - exportacao da plataforma (RELATORIO_BENEFICIARIOS: Contrato/Subcontrato/Nome do Titular/Codigo da Familia)
      -> "Base Complementar" (base atual, usada para cruzar inclusao/alteracao/exclusao)
    - base da operadora/cliente (nome + CPF ou nascimento) -> "Arquivo Origem"
    - outras planilhas -> nao baixadas, apenas listadas no _Dados do contrato.txt
  Sem base da operadora/cliente -> nao cria pasta; vai para o relatorio como "atualizacao sem base".
  A mesma separacao vale quando o Julio responde 2 num atendimento de atualizacao de base.

Gera em <pasta_saida>:
  arquivos/Layouts/<pasta>/Arquivo Origem/<anexos>
  arquivos/Carga SDI/<pasta>/Arquivo Origem/<anexos> e Arquivo Modelo/<modelo>
  pastas.json   -> lista de pastas (com subpastas vazias) a criar no computador
  relatorio.json, _controle_atendimentos.json (estado atualizado, gravar so depois dos arquivos)
"""
import argparse, base64, json, os, re, shutil, sys, unicodedata
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agente_atendimentos import Odoo, load_env, BRT, contrato_info, contrato_pelo_texto, dominio_filtro, txt as html_txt

IMG = re.compile(r"^image\d*(\.\w+)?$|\.(png|jpe?g|gif|bmp)$", re.I)
SUB = {"Layouts": ["Modelo Operadora", "Arquivo Origem", "Arquivo Validado", "Base Complementar"],
       "Carga SDI": ["Arquivo Final", "Arquivo Origem", "Arquivo Modelo", "Base Complementar"]}
DEST = {"1": "Layouts", "2": "Carga SDI"}


def norm(s):
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower().strip()


def nome_pasta(protocolo, titulo):
    """Padrão do Julio: (#<protocolo>) <título do atendimento>"""
    s = re.sub(r'[\\/:*?"<>|\t\r\n]+', " ", f"(#{protocolo}) {titulo}")
    s = re.sub(r"\s+", " ", s).strip()[:110]
    return s.rstrip(" .")


def nome_arquivo(n):
    n = re.sub(r'[\\/:*?"<>|\t\r\n]+', "_", n or "arquivo").strip().rstrip(" .")
    return n[:150] or "arquivo"

PLANILHA = re.compile(r"\.(xlsx|xlsm|xls|csv)$", re.I)


def eh_atualizacao(t):
    s = norm(" ".join([str(t.get("name") or ""), m2(t.get("ticket_type_id")), m2(t.get("xipp_request_id"))]))
    if any(w in s for w in ("telemedicina", "eu protegido")):
        return False  # arquivos de telemedicina/Eu Protegido não são carga de beneficiários no SDI
    return ("atualiza" in s and "base" in s) or "posicao cadastral" in s


def m2(v):
    return v[1] if isinstance(v, list) and len(v) > 1 else ""


def cabecalho(nome, dados):
    """Retorna a lista de cabecalhos normalizados da primeira linha com 3+ celulas (ou None se nao der para ler)."""
    import io
    ext = os.path.splitext(nome)[1].lower()
    try:
        if ext == ".csv":
            t = dados.decode("utf-8-sig", errors="ignore") if dados[:3] == b"\xef\xbb\xbf" else dados.decode("latin-1")
            sep = ";" if t.count(";") > t.count(",") else ","
            for linha in t.splitlines()[:30]:
                cols = [c.strip().strip('"') for c in linha.split(sep)]
                if sum(1 for c in cols if c) >= 3:
                    return [norm(c) for c in cols]
            return None
        if ext == ".xls":
            try:
                import xlrd
            except ImportError:
                return None
            sh = xlrd.open_workbook(file_contents=dados).sheet_by_index(0)
            for r in range(min(sh.nrows, 30)):
                cols = [str(c).strip() for c in sh.row_values(r)]
                if sum(1 for c in cols if c) >= 3:
                    return [norm(c) for c in cols]
            return None
        import openpyxl, warnings
        warnings.filterwarnings("ignore")
        ws = openpyxl.load_workbook(io.BytesIO(dados), read_only=True, data_only=True).worksheets[0]
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i > 30:
                break
            cols = [str(c).strip() if c is not None else "" for c in row]
            if sum(1 for c in cols if c) >= 3:
                return [norm(c) for c in cols]
    except Exception:
        return None
    return None


def classificar(nome, dados):
    if norm(nome).startswith("relatorio_beneficiarios"):
        return "plataforma"
    h = cabecalho(nome, dados)
    if not h:
        return "base?"  # nao foi possivel ler; tratado como base da operadora
    hs = " | ".join(h)
    if "codigo da familia" in hs and "nome do titular" in hs and "subcontrato" in hs:
        return "plataforma"
    tem_nome = any("nome" in c or c in ("name", "employee name", "beneficiario", "segurado") for c in h)
    tem_id = any("cpf" in c or "nascimento" in c or "national id" in c or "birth" in c for c in h)
    return "base" if (tem_nome and tem_id) else "outro"


LAYOUT_RE = re.compile(r"(criac\w*|cria|criar)\s+(do|de|o|um)?\s*layout|valid\w*\s+(o|do|de)?\s*layout|"
                       r"layout\s+(validador|operadora|implantacao)|validacao\s+(de\s+)?layout|preenchimento\s+de\s+layout")


def eh_layout(t):
    """Pedido de criação/validação de layout (regra do Julio em 07/10/2026) -> Maninha (pasta Layouts)."""
    s = norm(" ".join([str(t.get("name") or ""), html_txt(t.get("description") or "")[:600],
                       m2(t.get("ticket_type_id")), m2(t.get("xipp_request_id"))]))
    if any(w in s for w in ("telemedicina", "eu protegido")):
        return False
    return bool(LAYOUT_RE.search(s)) or "layout" in norm(m2(t.get("ticket_type_id")))


def linhas_de_dados(nome, dados):
    """Conta linhas preenchidas depois do cabeçalho (para separar template vazio de base com vidas)."""
    import io
    ext = os.path.splitext(nome)[1].lower()
    try:
        if ext == ".csv":
            t = dados.decode("utf-8-sig", errors="ignore")
            return max(0, sum(1 for l in t.splitlines() if l.strip(" ;,\t")) - 1)
        if ext == ".xls":
            import xlrd
            sh = xlrd.open_workbook(file_contents=dados).sheet_by_index(0)
            return max(0, sum(1 for r in range(sh.nrows) if any(str(c).strip() for c in sh.row_values(r))) - 1)
        import openpyxl, warnings
        warnings.filterwarnings("ignore")
        wb = openpyxl.load_workbook(io.BytesIO(dados), read_only=True, data_only=True)
        total = 0
        for ws in wb.worksheets[:3]:
            n = 0
            for row in ws.iter_rows(values_only=True):
                if sum(1 for c in row if c not in (None, "")) >= 3:
                    n += 1
                if n > 30:
                    break
            total = max(total, n)
        return max(0, total - 12)  # templates costumam ter ~10 linhas de instrução/cabeçalho
    except Exception:
        return -1


def lote_recente(itens):
    if not itens:
        return []
    topo = datetime.strptime(itens[0]["create_date"], "%Y-%m-%d %H:%M:%S")
    return [x for x in itens if (topo - datetime.strptime(x["create_date"], "%Y-%m-%d %H:%M:%S")).total_seconds() <= 600]


def ler_txt(path):
    """Retorna lista de {chave, id, sugestao, resposta}."""
    t = open(path, encoding="utf-8-sig").read().replace("\r\n", "\n")
    itens = []
    for bloco in re.split(r"\n(?=\[[^\]\n]+\] Protocolo)", t):
        m = re.match(r"\[([^\]]+)\] Protocolo", bloco.strip())
        if not m:
            continue
        mid = re.search(r"[#?&]id=(\d+)", bloco)
        sug = re.search(r"Sugestão do Claude:\s*([123])", bloco)
        resp = re.search(r"^\s*R:[ \t]*(.*)$", bloco, re.M)
        itens.append({"chave": m.group(1), "id": int(mid.group(1)) if mid else None,
                      "sugestao": sug.group(1) if sug else None,
                      "resposta": (resp.group(1).strip() if resp else "")})
    return itens


def interpretar(resp, sug):
    r = norm(resp)
    if not r:
        return None, "sem resposta"
    if re.match(r"^(ok|sim|de acordo|aceito|concordo|pode)\b", r):
        return (sug, "aceitou a sugestão") if sug else (None, "respondeu 'ok' mas não havia sugestão")
    if re.match(r"^1\b|^maninha", r):
        return "1", "Maninha"
    if re.match(r"^2\b|^carregador", r):
        return "2", "Carregador do Futuro"
    if re.match(r"^3\b|^sem acao", r):
        return "3", "sem ação"
    return "outro", "orientação em texto livre"


def texto_contrato(numero, titulo, ci):
    titulo = (titulo or "").strip()
    L = [f"Atendimento {numero} - {titulo}", ""]
    if not ci or ci.get("erro"):
        L.append("Nenhum contrato vinculado ou identificado no atendimento.")
        return "\n".join(L) + "\n"
    if ci.get("identificado_pelo_nome"):
        L.append(f"(contrato identificado pelo nome \"{ci['identificado_pelo_nome']}\" citado no título - CONFIRA, pode haver outros contratos do mesmo cliente)")
    elif ci.get("identificado_pelo_texto"):
        L.append("(contrato identificado pelo número citado no atendimento - confira)")
    L += [f"Contrato: {ci['contrato']}", f"Apólice: {ci['apolice']}", f"Operadora: {ci['operadora']}",
          f"Benefício: {ci['beneficio']}", f"Razão social: {ci['razao_social']}", f"CNPJ: {ci['cnpj']}",
          f"Status: {ci['status']}", f"Início: {ci['inicio']}" + (f" | Fim: {ci['fim']}" if ci['fim'] else ""),
          f"Vidas: {ci['vidas']}", f"Grupo financeiro: {ci['grupo_financeiro']}", "", "Planos:"]
    L += [f"  - {p['nome']} | código {p['codigo']} | {p['acomodacao']} | {p['abrangencia']} | início {p['inicio']}" for p in ci["planos"]] or ["  (nenhum)"]
    if ci["subcontratos"]:
        L += ["", f"Subcontratos ({ci.get('total_subcontratos', len(ci['subcontratos']))}):"]
        L += [f"  - {sc['nome']} | CNPJ {sc['cnpj']} | {sc['status']}" for sc in ci["subcontratos"]]
    if ci["portais"]:
        L += ["", "Portais da operadora (senha consultar na plataforma):"]
        L += [f"  - {pa['portal']} | {pa['site'] if len(pa['site']) < 120 else pa['site'][:117] + '...'} | login {pa['login']} | acesso {pa['codigo']}" for pa in ci["portais"]]
    if ci.get("outros_contratos_citados"):
        L += ["", "Outros contratos citados: " + "; ".join(ci["outros_contratos_citados"])]
    return "\n".join(L) + "\n"


def texto_extra(atualizacao, separacao, layout=False):
    if layout and separacao:
        L = ["", "PEDIDO DE LAYOUT (Maninha) - arquivos baixados:"]
        L += [f"  - {n} -> {'Modelo Operadora (template sem vidas)' if tp == 'modelo' else 'Arquivo Origem'}" for n, tp in separacao]
        return "\n".join(L) + "\n"
    if not atualizacao:
        return ""
    L = ["", "ATUALIZAÇÃO DE BASE - como os anexos foram separados:"]
    for nome, tipo in separacao:
        destino = {"base": "Arquivo Origem (base da operadora/cliente)", "base?": "Arquivo Origem (não foi possível ler o cabeçalho - confira)",
                   "plataforma": "Base Complementar (exportação da plataforma = base atual)",
                   "outro": "não baixado (planilha que não parece base de beneficiários)",
                   "antigo": "não baixado (versão mais antiga)"}[tipo]
        L.append(f"  - {nome} -> {destino}")
    L += ["", "Objetivo: comparar a base da operadora (Origem) com a base atual da plataforma (Complementar)",
          "e gerar o layout de movimentação com inclusões, alterações (ex.: plano) e exclusões."]
    return "\n".join(L) + "\n"


def processar(o, tid, raiz, resposta, info, enc, out_arq, modelo, agora, pastas, rel, auto=False):
    t = o.call("helpdesk.ticket", "read", [[tid]], {"fields": ["number", "name", "description", "xipp_contract_id",
                                                               "ticket_type_id", "xipp_request_id", "protocol_code"]})[0]
    numero = t["number"] if str(t["number"]).startswith("HT") else str(tid)
    pasta = nome_pasta(t["protocol_code"] or numero, (t["name"] or "").strip())
    atualizacao = raiz == "Carga SDI" and eh_atualizacao(t) and not eh_layout(t)
    layout = raiz == "Layouts"
    anterior = enc.get(str(tid), {})
    baixados = set(anterior.get("anexos", [])) if anterior.get("destino") == raiz else set()
    atts = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "=", tid]]],
                  {"fields": ["id", "name", "create_date", "file_size", "create_uid"], "order": "create_date desc", "limit": 100})
    atts = [x for x in atts if not IMG.search(x["name"] or "")]
    citados = [x for x in atts if norm(os.path.splitext(x["name"])[0]) and norm(os.path.splitext(x["name"])[0]) in norm(resposta)]
    conteudo = {}

    def baixar(x):
        if x["id"] not in conteudo:
            d = o.call("ir.attachment", "read", [[x["id"]]], {"fields": ["datas"]})[0].get("datas")
            conteudo[x["id"]] = base64.b64decode(d) if d else None
        return conteudo[x["id"]]

    destino_de = {}  # id -> subpasta
    separacao = []
    if atualizacao:
        planilhas = [x for x in (citados or atts) if PLANILHA.search(x["name"] or "")]
        tipos = {}
        for x in planilhas:
            dados = baixar(x)
            tipos[x["id"]] = classificar(x["name"], dados) if dados else "outro"
        bases = lote_recente([x for x in planilhas if tipos[x["id"]] in ("base", "base?")])
        plat = [x for x in planilhas if tipos[x["id"]] == "plataforma"][:1]
        for x in bases:
            destino_de[x["id"]] = "Arquivo Origem"
        for x in plat:
            destino_de[x["id"]] = "Base Complementar"
        for x in planilhas:
            tp = tipos[x["id"]] if x["id"] in destino_de or tipos[x["id"]] == "outro" else "antigo"
            separacao.append((x["name"], tp))
        if not bases:
            rel.setdefault("atualizacao_sem_base", []).append(
                dict(info, motivo="nenhuma planilha de beneficiários da operadora/cliente anexada" +
                     (" (só a exportação da plataforma)" if plat else "")))
            if auto:
                # Regra do Julio (07/10/2026): sem arquivo, cria a pasta só com o "_Dados do contrato.txt"
                if anterior.get("destino") != raiz:
                    base = os.path.join(out_arq, raiz, pasta)
                    os.makedirs(base, exist_ok=True)
                    ci = contrato_info(o, t["xipp_contract_id"][0]) if t["xipp_contract_id"] else contrato_pelo_texto(o, t)
                    aviso = ("\nAGUARDANDO BASE: o atendimento ainda não tem planilha de beneficiários anexada.\n"
                             "Quando a base chegar no atendimento, o agente baixa automaticamente para esta pasta\n"
                             "(Arquivo Origem / Base Complementar) e copia o Arquivo Modelo.\n")
                    open(os.path.join(base, "_Dados do contrato.txt"), "w", encoding="utf-8-sig", newline="\r\n").write(
                        texto_contrato(numero, t["name"], ci) + aviso)
                    pastas.append({"raiz": raiz, "pasta": pasta, "subpastas": []})
                    enc[str(tid)] = {"destino": raiz, "pasta": pasta, "data": agora, "resposta": "", "anexos": [],
                                     "atualizacao_de_base": True, "automatico": True, "status": "aguardando_base"}
                    rel.setdefault("pastas_so_dados", []).append(dict(info, pasta=f"{raiz}\\{pasta}"))
                return
    elif layout:
        # Maninha: arquivos do solicitante (não os entregues pelo Julio/Dados) no lote mais recente;
        # planilha sem linhas de dados (template vazio da operadora) -> "Modelo Operadora"
        planilhas = [x for x in (citados or atts) if PLANILHA.search(x["name"] or "")]
        do_solic = [x for x in planilhas if not (x["create_uid"] and x["create_uid"][0] == 275)]
        escolhidos = citados or lote_recente(do_solic or planilhas) or lote_recente(atts)
        for x in escolhidos:
            sub = "Arquivo Origem"
            nn = norm(x["name"])
            operadoras = ("hapvida", "amil", "bradesco", "sulamerica", "sul america", "odontoprev", "unimed", "porto", "metlife", "gndi", "notre")
            if "layout" in nn and any(op in nn for op in operadoras) and not any(w in nn for w in ("criticador", "validad", "preenchid", "ativos", "inativos", "implantacao", "bate", "_v1_", "ajustad")):
                sub = "Modelo Operadora"  # ex.: "Layout HapVida_V1.5.2.xlsm" = modelo exigido pela operadora
            elif PLANILHA.search(x["name"] or ""):
                dados = baixar(x)
                if dados is not None and 0 <= linhas_de_dados(x["name"], dados) <= 1:
                    sub = "Modelo Operadora"
            destino_de[x["id"]] = sub
            separacao.append((x["name"], "modelo" if sub == "Modelo Operadora" else "base"))
        if not escolhidos:
            rel.setdefault("layout_sem_arquivo", []).append(dict(info, motivo="pedido de layout sem arquivo anexado"))
            if auto:
                return
    else:
        escolhidos = citados or lote_recente(atts)
        for x in escolhidos:
            destino_de[x["id"]] = "Arquivo Origem"
    novos = [x for x in atts if x["id"] in destino_de and x["id"] not in baixados]
    if anterior.get("destino") == raiz and not novos:  # inclui "aguardando_base" sem base nova
        rel["ja_feitos"] += 1
        return
    base = os.path.join(out_arq, raiz, pasta)
    salvos = []
    for x in novos:
        dados = baixar(x)
        if not dados:
            rel["erros"].append(f"{numero}: anexo {x['name']} sem conteúdo")
            continue
        dst = os.path.join(base, destino_de[x["id"]], nome_arquivo(x["name"]))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        open(dst, "wb").write(dados)
        salvos.append(f"{destino_de[x['id']]}\\{x['name']}")
        baixados.add(x["id"])
    aguardava = anterior.get("status") == "aguardando_base"
    if anterior.get("destino") != raiz or aguardava:
        ci = contrato_info(o, t["xipp_contract_id"][0]) if t["xipp_contract_id"] else contrato_pelo_texto(o, t)
        os.makedirs(base, exist_ok=True)
        open(os.path.join(base, "_Dados do contrato.txt"), "w", encoding="utf-8-sig", newline="\r\n").write(
            texto_contrato(numero, t["name"], ci) + texto_extra(atualizacao, separacao, layout))
        if raiz == "Carga SDI":  # (re)grava Dados do contrato acima e copia o modelo
            dst = os.path.join(base, "Arquivo Modelo", os.path.basename(modelo))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(modelo, dst)
    pastas.append({"raiz": raiz, "pasta": pasta, "subpastas": SUB[raiz]})
    enc[str(tid)] = {"destino": raiz, "pasta": pasta, "data": agora, "resposta": resposta,
                     "anexos": sorted(baixados), "atualizacao_de_base": atualizacao, "automatico": auto, "status": "com_base"}
    rel["encaminhados"].append(dict(info, destino="Maninha" if raiz == "Layouts" else "Carregador do Futuro",
                                    tipo=("layout (automático)" if layout else "atualização de base (automático)") if auto else ("atualização de base" if atualizacao else ""),
                                    pasta=f"{raiz}\\{pasta}", arquivos=salvos,
                                    aviso="" if salvos or anterior else "atendimento sem anexo utilizável: pasta criada vazia"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--state", required=True)
    ap.add_argument("--modelo", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--auto-atualizacao", action="store_true",
                    help="encaminha automaticamente: atualização de base -> Carga SDI; pedido de layout -> Layouts (Maninha)")
    ap.add_argument("--somente", type=int, action="append", default=[], help="processa só estes ids (teste)")
    ap.add_argument("txts", nargs="*")
    a = ap.parse_args()
    state = json.load(open(a.state, encoding="utf-8")) if os.path.exists(a.state) else {"atendimentos": {}}
    enc = state.setdefault("encaminhados", {})
    out_arq = os.path.join(a.out, "arquivos")
    os.makedirs(out_arq, exist_ok=True)
    o = Odoo(load_env(a.cred))
    pastas, rel = [], {"encaminhados": [], "sem_acao": [], "outros": [], "pendentes": 0, "erros": [], "ja_feitos": 0,
                       "atualizacao_sem_base": [], "layout_sem_arquivo": []}
    agora = datetime.now(BRT).strftime("%d/%m/%Y %H:%M")

    respostas = {}
    for txt in sorted(a.txts):  # TXT mais recente vence
        for it in ler_txt(txt):
            if it["id"] and it["resposta"]:
                respostas[it["id"]] = dict(it, txt=os.path.basename(txt))
            elif it["id"] and it["id"] not in respostas:
                respostas.setdefault(it["id"], None)
    if a.somente:
        respostas = {k: v for k, v in respostas.items() if k in a.somente}
    rel["pendentes"] = sum(1 for v in respostas.values() if v is None)

    for tid, it in respostas.items():
        if not it:
            continue
        op, desc = interpretar(it["resposta"], it["sugestao"])
        info = {"atendimento": it["chave"], "resposta": it["resposta"], "txt": it["txt"]}
        if op == "3":
            if enc.get(str(tid), {}).get("destino") != "sem ação":
                enc[str(tid)] = {"destino": "sem ação", "data": agora, "resposta": it["resposta"]}
                rel["sem_acao"].append(info)
            else:
                rel["ja_feitos"] += 1
            continue
        if op not in DEST:
            if enc.get(str(tid), {}).get("resposta") != it["resposta"]:
                enc[str(tid)] = {"destino": "outro", "data": agora, "resposta": it["resposta"]}
                rel["outros"].append(dict(info, motivo=desc))
            else:
                rel["ja_feitos"] += 1
            continue
        processar(o, tid, DEST[op], it["resposta"], info, enc, out_arq, a.modelo, agora, pastas, rel)

    if a.auto_atualizacao:
        dom = dominio_filtro() + ([["id", "in", a.somente]] if a.somente else [])
        tickets = o.call("helpdesk.ticket", "search_read", [dom],
                         {"fields": ["id", "number", "name", "ticket_type_id", "xipp_request_id", "description"], "limit": 2000})
        for t in tickets:
            if t["id"] in respostas and respostas[t["id"]]:
                continue  # respondido no TXT: vale a resposta do Julio
            t2 = dict(t, description=t.get("description") or "")
            if eh_layout(t2):
                raiz, rotulo, outros = "Layouts", "(automático: pedido de layout)", ("sem ação", "outro", "Carga SDI")
            elif eh_atualizacao(t2):
                raiz, rotulo, outros = "Carga SDI", "(automático: atualização de base)", ("sem ação", "outro", "Layouts")
            else:
                continue
            ant = enc.get(str(t["id"]), {})
            if ant.get("destino") in outros:
                continue  # Julio já decidiu outra coisa
            info = {"atendimento": t["number"] if str(t["number"]).startswith("HT") else str(t["id"]),
                    "resposta": rotulo, "txt": ""}
            processar(o, t["id"], raiz, "", info, enc, out_arq, a.modelo, agora, pastas, rel, auto=True)

    json.dump(pastas, open(os.path.join(a.out, "pastas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(rel, open(os.path.join(a.out, "relatorio.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(state, open(os.path.join(a.out, "_controle_atendimentos.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: (len(v) if isinstance(v, list) else v) for k, v in rel.items()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
