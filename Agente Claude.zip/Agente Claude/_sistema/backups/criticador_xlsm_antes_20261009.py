#!/usr/bin/env python3
"""Maninha - Criticador de Layout no MODELO .xlsm (Power Query + VBA) do Julio.

Edição cirúrgica do ZIP/XML (NUNCA openpyxl load->save no .xlsm): só reescreve
  xl/worksheets/sheet3.xml (Dados), xl/tables/table2.xml (TabelaDados),
  xl/worksheets/sheet2.xml (Relatório de Crítica), xl/tables/table1.xml (Crítica),
  xl/worksheets/sheet1.xml (Resumo: valores em cache + Metodologia) e xl/calcChain.xml (fórmulas IDADE).
Todas as demais partes são copiadas byte a byte. As regras vêm de criticador.py (processo único).

Uso:
  python3 criticador_xlsm.py --modelo Modelo_Criticador.xlsm --entrada arq1 [arq2...] \
      --saida "AAAAMMDD_Criticador de layout_V1.xlsm" [--titulo "..."] [--json res.json]
"""
import argparse, json, re, sys, os, zipfile, datetime as dt
from collections import Counter, defaultdict
from xml.sax.saxutils import escape
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import criticador as C

# mapeamento das partes no modelo do Julio (verificado no workbook.xml/rels)
P_DADOS, P_TDADOS = "xl/worksheets/sheet3.xml", "xl/tables/table2.xml"
P_CRIT, P_TCRIT = "xl/worksheets/sheet2.xml", "xl/tables/table1.xml"
P_RESUMO, P_CALC = "xl/worksheets/sheet1.xml", "xl/calcChain.xml"
SHEETID_DADOS = "6"
RED = {"30": "59", "32": "60", "33": "61", "34": "62", "35": "63"}
CAT_AC = {"Obrigatório ausente": "45", "Formato inválido": "46", "Duplicidade": "47", "Consistência": "48"}
CAT_D = {"Obrigatório ausente": "58", "Formato inválido": "56", "Duplicidade": "55", "Consistência": "57"}
EPOCH = dt.date(1899, 12, 30)


def col_letra(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


LET = [col_letra(i) for i in range(len(C.COLS))]
IDX_IDADE = C.COLS.index("IDADE")


def t(v):
    return f'<is><t xml:space="preserve">{escape(v)}</t></is>'


def estilos_modelo(xml):
    """estilo (s=) de cada coluna na linha 2 do modelo."""
    r2 = re.search(r'<row r="2"[^>]*>(.*?)</row>', xml, re.S).group(1)
    st = {}
    for col, s in re.findall(r'<c r="([A-Z]+)2" s="(\d+)"', r2):
        st[col] = next((k for k, v in RED.items() if v == s), s)
    return st


def montar_dados(xml, regs, crit):
    st = estilos_modelo(xml)
    marcar = defaultdict(set)
    for ln, _, m, cat in crit:
        if cat == "Obrigatório ausente":
            marcar[ln].add(C.MSG_COL[m])
    linhas = []
    for i, r in enumerate(C.ordenar(regs), start=2):
        cel = []
        for j, c in enumerate(C.COLS):
            L = LET[j]
            s = st.get(L, "30")
            if c in marcar[r["Linha"]]:
                s = RED.get(s, "59")
            ref = f"{L}{i}"
            if j == IDX_IDADE:
                f = (f'DATEDIF(K{i}, TODAY(), "Y") &amp; " anos, " &amp; DATEDIF(K{i}, TODAY(), "YM") &amp; '
                     f'" meses e " &amp; DATEDIF(K{i}, TODAY(), "MD") &amp; " dias"')
                v = escape(f"{r['_idade']} anos") if r.get("_idade") is not None else ""
                cel.append(f'<c r="{ref}" s="{s}" t="str"><f ca="1">{f}</f><v>{v}</v></c>')
                continue
            v = r[c]
            d = r.get("_d_" + c) if c in C.DATAS else None
            if v and d and st.get(L) == "34":
                cel.append(f'<c r="{ref}" s="{s}"><v>{(d - EPOCH).days}</v></c>')
            elif v:
                cel.append(f'<c r="{ref}" s="{s}" t="inlineStr">{t(v)}</c>')
            else:
                cel.append(f'<c r="{ref}" s="{s}"/>')
        linhas.append(f'<row r="{i}" spans="1:47">' + "".join(cel) + "</row>")
    n = len(regs)
    cab = re.search(r'<row r="1"[^>]*>.*?</row>', xml, re.S).group(0)
    xml = re.sub(r"<sheetData>.*</sheetData>", lambda _: "<sheetData>" + cab + "".join(linhas) + "</sheetData>", xml, flags=re.S)
    xml = re.sub(r'<dimension ref="[^"]*"/>', f'<dimension ref="A1:AU{n + 1}"/>', xml)
    return xml


def montar_critica(xml, crit):
    linhas = []
    for k, (ln, nome, m, cat) in enumerate(crit, start=15):
        a, d = CAT_AC[cat], CAT_D[cat]
        linhas.append(f'<row r="{k}" spans="1:4"><c r="A{k}" s="{a}"><v>{ln}</v></c>'
                      f'<c r="B{k}" s="{a}" t="inlineStr">{t(nome or "")}</c>'
                      f'<c r="C{k}" s="{a}" t="inlineStr">{t(m)}</c>'
                      f'<c r="D{k}" s="{d}" t="inlineStr">{t(cat)}</c></row>')
    if not crit:
        linhas.append('<row r="15" spans="1:4"/>')
    def sub(sd):
        corpo = sd.group(1)
        manter = [r for r in re.findall(r'<row [^>]*>.*?</row>|<row [^>]*/>', corpo, re.S)
                  if int(re.search(r'r="(\d+)"', r).group(1)) <= 14]
        return "<sheetData>" + "".join(manter) + "".join(linhas) + "</sheetData>"
    xml = re.sub(r"<sheetData>(.*)</sheetData>", sub, xml, flags=re.S)
    fim = 14 + max(1, len(crit))
    xml = re.sub(r'<dimension ref="[^"]*"/>', f'<dimension ref="A1:D{fim}"/>', xml)
    return xml


def ajustar_tabela(xml, ref):
    xml = re.sub(r'(<table [^>]*?\bref=")[^"]*(")', rf"\g<1>{ref}\g<2>", xml, count=1)
    return re.sub(r'(<autoFilter ref=")[^"]*(")', rf"\g<1>{ref}\g<2>", xml, count=1)


def montar_resumo(xml, regs, crit, notas, titulo):
    por_msg = Counter(m for _, _, m, _ in crit)
    por_cat = Counter(c for *_, c in crit)
    tit = sum(1 for r in regs if r["PARENTESCO"] == "TITULAR")
    def cache(cel, val):
        nonlocal xml
        xml = re.sub(rf'(<c r="{cel}"[^>]*>.*?<f>[^<]*</f>)<v>[^<]*</v>', rf"\g<1><v>{val}</v>", xml, count=1, flags=re.S)
    xml = xml.replace("ROWS(TabelaDados)", "ROWS(TabelaDados[#Data])").replace("ROWS(Crítica)", "ROWS(Crítica[#Data])")
    cache("B4", len(regs)); cache("C4", len(crit)); cache("D4", tit)
    for m in re.finditer(r'<c r="(C\d+)"[^>]*><f>IFERROR\(COUNTIF\(Crítica\[(Crítica|Categoria)\],(?:&quot;|")(.*?)(?:&quot;|")\),0\)</f>', xml):
        cel, campo, alvo = m.groups()
        cache(cel, (por_cat if campo == "Categoria" else por_msg).get(alvo, 0))
    gerado = f"Gerado em {C.HOJE.strftime('%d/%m/%Y')} — validação executada pela Maninha" + (f" • {titulo}" if titulo else "")
    xml = re.sub(r'(<c r="B2" s="\d+")[^>]*>.*?</c>', lambda mm: f'{mm.group(1)} t="inlineStr">{t(gerado)}</c>', xml, count=1, flags=re.S)
    # Metodologia: linhas após o título "METODOLOGIA" (linha 61 no modelo) são substituídas
    rows = re.findall(r'<row [^>]*>.*?</row>|<row [^>]*/>', re.search(r"<sheetData>(.*)</sheetData>", xml, re.S).group(1), re.S)
    num = lambda r: int(re.search(r'r="(\d+)"', r).group(1))
    lin_tit = max(num(r) for r in rows if 's="44"' in r)
    est = re.search(r'<c r="B\d+" s="(\d+)" t="inlineStr"', "".join(r for r in rows if num(r) > lin_tit))
    s_nota = est.group(1) if est else "49"
    novas = [r for r in rows if num(r) <= lin_tit]
    for k, n in enumerate(notas, start=lin_tit + 1):
        novas.append(f'<row r="{k}" spans="2:3"><c r="B{k}" s="{s_nota}" t="inlineStr">{t("• " + n)}</c></row>')
    xml = re.sub(r"<sheetData>.*</sheetData>", lambda _: "<sheetData>" + "".join(novas) + "</sheetData>", xml, flags=re.S)
    return xml


def montar_calc(xml, n):
    # entradas sem i herdam a última; para segurança, explicita i em todas
    ult, fixas = None, []
    for c in re.findall(r"<c [^>]*/>", xml):
        m = re.search(r'i="(\d+)"', c)
        ult = m.group(1) if m else ult
        if ult != SHEETID_DADOS:
            fixas.append(c if m else c.replace("<c ", f'<c i="{ult}" ', 1))
    fixas = [re.sub(r'\sl="1"', "", c) for c in fixas]
    novas = [f'<c r="{LET[IDX_IDADE]}{i}" i="{SHEETID_DADOS}"/>' for i in range(2, n + 2)]
    cab = xml[: xml.find("<c ")]
    return cab + "".join(fixas + novas) + "</calcChain>"


def gerar_xlsm(modelo, saida, regs, crit, notas, titulo):
    zin = zipfile.ZipFile(modelo)
    novo = {
        P_DADOS: montar_dados(zin.read(P_DADOS).decode("utf-8"), regs, crit),
        P_TDADOS: ajustar_tabela(zin.read(P_TDADOS).decode("utf-8"), f"A1:AU{len(regs) + 1}"),
        P_CRIT: montar_critica(zin.read(P_CRIT).decode("utf-8"), crit),
        P_TCRIT: ajustar_tabela(zin.read(P_TCRIT).decode("utf-8"), f"A14:D{14 + max(1, len(crit))}"),
        P_RESUMO: montar_resumo(zin.read(P_RESUMO).decode("utf-8"), regs, crit, notas, titulo),
        P_CALC: montar_calc(zin.read(P_CALC).decode("utf-8"), len(regs)),
    }
    import xml.dom.minidom
    for k, v in novo.items():
        xml.dom.minidom.parseString(v.encode("utf-8"))  # valida XML
    with zipfile.ZipFile(saida, "w") as zout:
        for info in zin.infolist():
            if info.filename in novo:
                zout.writestr(info, novo[info.filename].encode("utf-8"), compress_type=zipfile.ZIP_DEFLATED)
            else:
                zout.writestr(info, zin.read(info.filename), compress_type=info.compress_type)
    # verificação: mesma lista de partes e partes não tocadas idênticas
    a, b = zipfile.ZipFile(modelo), zipfile.ZipFile(saida)
    assert a.namelist() == b.namelist()
    for n in a.namelist():
        if n not in novo:
            assert a.read(n) == b.read(n), n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--modelo", required=True)
    ap.add_argument("--entrada", nargs="+", required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--titulo", default="")
    ap.add_argument("--json", default="")
    a = ap.parse_args()
    regs, presentes, params, notas = [], set(), {}, []
    for f in a.entrada:
        r, p, prm, aba = C.ler_fonte(f)
        regs += r
        presentes |= set(p)
        notas.append(f"Fonte: {os.path.basename(f)} (aba '{aba}'), {len(r)} linha(s).")
    notas.append("Sem Base Complementar: validação feita só com o arquivo de origem.")
    try:
        lim = int(params.get("IDADE LIMITE") or 100)
    except (TypeError, ValueError):
        lim = 100
    notas.append(f"Idade calculada na data de hoje ({C.HOJE.strftime('%d/%m/%Y')}); limite de idade usado: {lim}.")
    tit = C.preparar(regs, notas)
    if not tit:
        notas.append("Nenhuma linha com PARENTESCO = TITULAR: as regras só-titular não se aplicam e todas as linhas com "
                     "matrícula aparecem como 'Dependente sem titular' (mesmo comportamento do botão 'Levantar críticas'). "
                     "Preencher o PARENTESCO resolve.")
    notas.append("Peso/Altura não exigidos (Plano PME = Não no painel Criticador); Vínculo empregatício só criticado quando preenchido.")
    crit = C.criticar(regs, tit, presentes, lim, notas)
    notas.append("NASCIMENTO/ADMISSÃO gravados como data real (a coluna IDADE é fórmula). Linhas ordenadas por CNPJ → matrícula → titular primeiro.")
    notas.append("Células em vermelho na aba Dados = campo obrigatório ausente. Modelo .xlsm com Power Query/VBA preservado; "
                 "no Excel, os botões 'Levantar críticas'/'Criticar tabela' continuam funcionando.")
    gerar_xlsm(a.modelo, a.saida, regs, crit, notas, a.titulo)
    res = {"linhas": len(regs), "titulares": sum(1 for r in regs if r["PARENTESCO"] == "TITULAR"), "criticas": len(crit),
           "por_tipo": Counter(m for _, _, m, _ in crit).most_common(),
           "por_categoria": Counter(c for *_, c in crit).most_common(), "saida": a.saida}
    if a.json:
        json.dump(res, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    main()
