# -*- coding: utf-8 -*-
"""
px_consulta_carga_api.py - consulta, na PX, o andamento de uma carga enviada por API (Bradesco).

Caminho automatizado (mapeado do video do Julio, 28/10/2026):
  1. Login na PX -> Automacao Operacional -> menu "SDI - Movimentacao Cadastral" (/odoo/action-7906)
  2. Card "Carga de Dados" (grupo "Servicos")
  3. Filtros: Tipo de arquivo (Posicao Cadastral) e Operadora (as 3 opcoes de "Bradesco")
  4. Tabela: Protocolo | Data e hora | Criado por | Nome do arquivo | Operadora | Atendimento | Etapa | Status | Acoes
     O codigo do contrato aparece no nome do arquivo (ex.: 20261027_200158_PC_74109.json).
     Procura o codigo, passando as paginas (rodape "Linhas por pagina / 1-10 de N").
  5. Lê Etapa e Status; se tiver o icone de critica (status "Finalizado com criticas"), abre a janela
     "Criticas" e le "Total de erros" e cada mensagem.

Saida: uma linha  RESULTADO_JSON: {...}  (ASCII, sem acento corrompido) que o vigia grava no status.

Uso (manual):
    python px_consulta_carga_api.py --contrato 74109 [--operadora Bradesco] [--tipo "Posição Cadastral"]
Opcoes: --todos (nao para no primeiro arquivo encontrado), --max-paginas N, --sem-filtro-nome,
        --visivel, --discover (capturas de tela em .\\sdi_debug)
Nada e alterado na PX: so consulta.
"""
import argparse
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sdi_baixar_base import (sync_playwright, PWTimeout, PX_URL_PADRAO, STATE, SESSAO_DIR, AQUI,  # noqa: E402
                             Debug, rx, sem_acento, ler_env, abrir_sdi, tela_sdi, clicar, esperar,
                             escolher_opcao)


# ----------------------------------------------------------------- filtros
def abrir_campo(tela, rotulo):
    campo = tela.locator(".v-input, .v-select, .v-autocomplete, [class*=select]").filter(has_text=rx(rotulo)).first
    campo.wait_for(state="visible", timeout=30000)
    return campo


def listar_operadoras(pg, tela, texto):
    """Abre o campo Operadora, digita o texto (ex.: Bradesco) e devolve os nomes de todas as opcoes que casam."""
    campo = abrir_campo(tela, "Operadora")
    campo.click()
    time.sleep(0.8)
    try:
        entrada = campo.locator("input[type=text], input:not([type])").first
        if entrada.is_visible():
            entrada.fill("")
            entrada.type(texto, delay=40)
            time.sleep(1.0)
    except Exception:
        pass
    opcoes = tela.locator(".v-menu__content .v-list-item, [role=option], .v-list-item")
    nomes = []
    for t in opcoes.all_inner_texts():
        t = " ".join(t.split())
        if t and sem_acento(texto) in sem_acento(t) and t not in nomes:
            nomes.append(t)
    pg.keyboard.press("Escape")
    time.sleep(0.5)
    return nomes


def filtrar_nome(tela, texto):
    """Digita no filtro 'Nome do arquivo' (se existir). Devolve True se conseguiu."""
    try:
        campo = tela.locator(".v-input").filter(has_text=rx("Nome do arquivo")).locator("input").first
        campo.wait_for(state="visible", timeout=8000)
        campo.fill(texto)
        campo.press("Enter")
        return True
    except Exception:
        return False


def limpar_nome(tela):
    try:
        campo = tela.locator(".v-input").filter(has_text=rx("Nome do arquivo")).locator("input").first
        campo.fill("")
        campo.press("Enter")
    except Exception:
        pass


def aumentar_linhas_por_pagina(pg, tela):
    """Tenta passar de 10 para o maior valor numerico <= 100 (menos paginas para varrer)."""
    try:
        rodape = tela.locator(".v-data-footer, [class*=footer]").filter(has_text=rx("Linhas por página")).first
        rodape.locator(".v-select, [role=button], .v-input").first.click()
        time.sleep(0.8)
        ops = tela.locator(".v-menu__content .v-list-item, [role=option]")
        melhor, valor = None, 0
        for i in range(ops.count()):
            t = " ".join(ops.nth(i).inner_text().split())
            if t.isdigit() and valor < int(t) <= 100:
                melhor, valor = ops.nth(i), int(t)
        if melhor is not None:
            melhor.click()
            esperar(pg, 1.5)
            return valor
        pg.keyboard.press("Escape")
    except Exception:
        pass
    return 10


# ----------------------------------------------------------------- tabela
RE_ARQ = re.compile(r"\d{8}_\d{6}_\S+\.[A-Za-z0-9]{2,5}")

JS_LINHAS = """() => {
  const re = /\\d{8}_\\d{6}_\\S+\\.[A-Za-z0-9]{2,5}/;
  const reAll = /\\d{8}_\\d{6}_\\S+\\.[A-Za-z0-9]{2,5}/g;
  document.querySelectorAll('[data-px-linha]').forEach(e => e.removeAttribute('data-px-linha'));
  const folhas = [...document.querySelectorAll('body *')].filter(e => e.children.length === 0 && !/^(SCRIPT|STYLE|NOSCRIPT)$/.test(e.tagName) && re.test(e.textContent || ''));
  const out = [], vistos = new Set();
  for (const folha of folhas) {
    let linha = folha;
    while (linha.parentElement) {
      const p = linha.parentElement, t = p.innerText || '';
      if ((t.match(reAll) || []).length > 1 || /Linhas por p[aá]gina/i.test(t) || /Nome do arquivo/i.test(t)) break;
      linha = p;
    }
    if (vistos.has(linha)) continue;
    vistos.add(linha);
    linha.setAttribute('data-px-linha', String(out.length));
    out.push(linha.innerText || '');
  }
  return out;
}"""


def ler_linhas(tela):
    """Le as linhas da lista sem depender de <table> (a tela usa divs). Acha cada nome de arquivo
    (AAAAMMDD_HHMMSS_...json), sobe ate a linha que o contem e separa os campos pelo texto:
    protocolo, data/hora, criado por, nome do arquivo | operadora, atendimento, etapa, status."""
    saida = []
    for i, texto in enumerate(tela.evaluate(JS_LINHAS)):
        partes = [x.strip() for x in re.split(r"[\n\t]+", texto) if x.strip()]
        k = next((n for n, x in enumerate(partes) if RE_ARQ.search(x)), None)
        if k is None:
            continue
        antes, resto = partes[:k], partes[k + 1:]
        data = next((x for x in antes if re.match(r"\d{2}/\d{2}/\d{4}", x)), "")
        protocolo = next((x for x in antes if re.fullmatch(r"\d{4,9}", x)), "")
        criado = next((x for x in reversed(antes) if x not in (data, protocolo)), "")
        if len(resto) >= 4:
            operadora, atend, etapa, status = resto[:4]
        else:
            operadora = resto[0] if resto else ""
            atend = ""
            etapa = resto[1] if len(resto) > 1 else ""
            status = resto[2] if len(resto) > 2 else ""
        saida.append({"protocolo": protocolo, "data_hora": data, "criado_por": criado, "arquivo": partes[k],
                      "operadora": operadora, "atendimento": atend, "etapa": etapa, "status": status,
                      "tr": tela.locator(f'[data-px-linha="{i}"]')})
    return saida


def posicao_rodape(tela):
    rodape = tela.locator(".v-data-footer, [class*=footer]").filter(has_text=rx("Linhas por página")).first
    try:
        m = re.search(r"(\d+)\s*-\s*(\d+)\s+de\s+(\d+)", rodape.inner_text())
        if m:
            return rodape, int(m.group(2)), int(m.group(3))
    except Exception:
        pass
    return rodape, None, None


def assinatura_lista(tela):
    """Primeiro e ultimo nome de arquivo da lista: muda quando a pagina realmente recarrega."""
    try:
        nomes = [l["arquivo"] for l in ler_linhas(tela)]
    except Exception:
        nomes = []
    return (nomes[0], nomes[-1], len(nomes)) if nomes else None


def proxima_pagina(pg, tela):
    """Avanca uma pagina e so devolve True quando a LISTA mudou (nao basta o rodape mudar:
    no teste de 28/10 o rodape foi para 101-200 e a lista ainda mostrava a pagina 1)."""
    rodape, fim, total = posicao_rodape(tela)
    if fim is not None and total is not None and fim >= total:
        return False
    for tentativa in range(3):
        rodape, _f, _t = posicao_rodape(tela)
        botao = rodape.locator("button").last
        try:
            if botao.is_disabled():
                return False
            antes_rod = rodape.inner_text()
            antes_lista = assinatura_lista(tela)
            botao.click()
            mudou_rod = mudou_lista = False
            for _ in range(50):                     # ate ~20 s
                time.sleep(0.4)
                if not mudou_rod and rodape.inner_text() != antes_rod:
                    mudou_rod = True
                agora = assinatura_lista(tela)
                if agora and agora != antes_lista:
                    mudou_lista = True
                if mudou_rod and mudou_lista:
                    break
            time.sleep(0.6)
            if mudou_lista:
                return True
            print(f"    aviso: a lista nao mudou apos clicar em proxima (tentativa {tentativa + 1}/3)")
            if mudou_rod:
                # rodape andou mas a lista nao: espera mais antes de desistir; nao clica de novo
                time.sleep(3)
                return assinatura_lista(tela) != antes_lista
        except Exception as e:
            print(f"    aviso: erro ao passar de pagina ({e}), tentativa {tentativa + 1}/3")
            time.sleep(2)
    return False


# ----------------------------------------------------------------- criticas
def parse_criticas(texto):
    total = re.search(r"Total de erros:\s*(\d+)", texto or "")
    itens = [{"data": d, "mensagem": " ".join(m.split()), "linha": int(l)}
             for d, m, l in re.findall(r"(\d{2}/\d{2}/\d{4})\s*(.*?)\s*Linha\s*(\d+)", texto or "", re.S)]
    return int(total.group(1)) if total else None, itens


def ler_criticas(pg, tela, tr):
    """Clica no icone de critica da linha e le a janela 'Criticas'. Devolve dict ou None se nao houver icone."""
    btn = tr.locator("button:has([class*='open-in-new']), a:has([class*='open-in-new'])")
    if btn.count() == 0:
        todos = tr.locator("button, [role=button]")
        caixas = []
        for n in range(todos.count()):
            bb = todos.nth(n).bounding_box()
            if bb:
                caixas.append((bb["x"], n))
        if len(caixas) < 2:
            return None
        caixas.sort()
        btn = todos.nth(caixas[-2][1])               # o icone de critica fica antes do menu (⋮), o mais a direita
    btn.first.click()
    time.sleep(1.5)
    dialogo = tela.locator(".v-dialog, [role=dialog]").filter(has_text=rx("Críticas")).last
    try:
        dialogo.wait_for(state="visible", timeout=15000)
    except PWTimeout:
        # nao abriu janela: a informacao pode estar na propria tela
        texto = ""
        try:
            texto = " ".join(tela.locator("body").inner_text().split())[:3000]
        except Exception:
            pass
        try:
            clicar(tela, "Voltar", "Voltar", espera=3000)
        except Exception:
            pass
        return {"janela": False, "texto_tela": texto}
    vistos, total = {}, None
    for _ in range(6):                               # rola a lista (pode ter mais itens que a altura da janela)
        texto = dialogo.inner_text()
        total, itens = parse_criticas(texto)
        for it in itens:
            vistos[(it["data"], it["mensagem"], it["linha"])] = it
        if total is None or len(vistos) >= total:
            break
        dialogo.evaluate("el => el.querySelectorAll('*').forEach(e => { if (e.scrollHeight > e.clientHeight + 5) e.scrollTop = e.scrollHeight; })")
        time.sleep(0.6)
    res = {"janela": True, "total_erros": total, "itens": list(vistos.values()),
           "texto_bruto": " ".join(dialogo.inner_text().split())[:3000]}
    try:                                             # fecha a janela
        dialogo.locator("button").first.click()
        time.sleep(0.6)
        if dialogo.is_visible():
            pg.keyboard.press("Escape")
            time.sleep(0.5)
    except Exception:
        pg.keyboard.press("Escape")
    return res


# ----------------------------------------------------------------- varredura
def casa_contrato(nome, padrao):
    m = re.match(r"^\d{8}_\d{6}_(.*)$", nome or "")
    return bool(padrao.search(m.group(1) if m else (nome or "")))


def varrer(pg, tela, dbg, contrato, operadora, max_paginas, todos, usar_filtro_nome):
    padrao = re.compile(rf"(?<!\d){re.escape(contrato)}(?!\d)")
    achados, paginas = [], 0
    filtrou_nome = False
    if usar_filtro_nome and filtrar_nome(tela, contrato):
        filtrou_nome = True
        esperar(pg, 2)
        if not any(casa_contrato(l["arquivo"], padrao) for l in ler_linhas(tela)):
            limpar_nome(tela)                        # o filtro de nome nao ajudou: volta a varrer as paginas
            esperar(pg, 2)
            filtrou_nome = False
    if not filtrou_nome:
        aumentar_linhas_por_pagina(pg, tela)
    if dbg.ativo:
        try:
            html = tela.evaluate("() => { const e = document.querySelector('[data-px-linha=\"0\"]'); "
                                 "return e ? e.parentElement.outerHTML.slice(0, 20000) : ''; }")
            if not ler_linhas(tela):
                html = tela.evaluate("() => document.body.innerHTML.slice(0, 60000)")
            (AQUI / "sdi_debug").mkdir(exist_ok=True)
            (AQUI / "sdi_debug" / "dom_lista.html").write_text(html or "", encoding="utf-8")
        except Exception:
            pass
    dbg.passo(pg, "lista " + re.sub(r"[^a-z0-9]+", "_", sem_acento(operadora))[:20])
    vistos, total_rodape = set(), None
    while paginas < max_paginas:
        paginas += 1
        linhas = ler_linhas(tela)
        _r, _fim, _tot = posicao_rodape(tela)
        if _tot is not None:
            total_rodape = _tot
        novos = {l["arquivo"] for l in linhas} - vistos
        if linhas and not novos:
            print("    aviso: pagina repetida (mesmos arquivos da anterior)")
        vistos |= {l["arquivo"] for l in linhas}
        print(f"    pagina {paginas}: {len(linhas)} linha(s) lidas, rodape até {_fim} de {_tot}; "
              f"primeiro arquivo: {linhas[0]['arquivo'] if linhas else '-'}")
        for l in linhas:
            if not casa_contrato(l["arquivo"], padrao):
                continue
            reg = {k: l[k] for k in ("protocolo", "data_hora", "criado_por", "arquivo", "operadora",
                                     "atendimento", "etapa", "status")}
            if "critica" in sem_acento(l["status"]):
                try:
                    reg["criticas"] = ler_criticas(pg, tela, l["tr"])
                except Exception as e:
                    reg["criticas"] = {"erro": f"nao consegui ler as criticas: {e}"}
                dbg.passo(pg, "criticas " + l["protocolo"])
            achados.append(reg)
        if achados and not todos:
            break
        if not proxima_pagina(pg, tela):
            dbg.passo(pg, "fim da paginacao")
            break
        esperar(pg, 0.5)
    if filtrou_nome:
        limpar_nome(tela)
    # Cobertura: so faz sentido quando varreu sem achar (com achado, parar cedo e normal).
    # Nomes de arquivo podem repetir na lista (reenvio no mesmo segundo e raro), entao tolera 1%.
    lidos = len(vistos)
    if filtrou_nome:
        completa = True
    elif total_rodape is None:
        completa = None
    else:
        completa = lidos >= total_rodape * 0.99
    cobertura = {"operadora": operadora, "lidos": lidos, "total_tela": total_rodape,
                 "completa": completa, "filtro_nome": filtrou_nome}
    print(f"    cobertura: {lidos} arquivo(s) distintos lidos de {total_rodape} na tela"
          f"{'' if completa or achados else '  <-- VARREDURA INCOMPLETA'}")
    return achados, paginas, cobertura


def main():
    ap = argparse.ArgumentParser(description="Consulta carga API (Bradesco) na PX - Carga de Dados")
    ap.add_argument("--contrato", required=True, help="codigo do contrato que aparece no nome do arquivo")
    ap.add_argument("--operadora", default="Bradesco")
    ap.add_argument("--tipo", default="Posição Cadastral")
    ap.add_argument("--max-paginas", type=int, default=300)
    ap.add_argument("--todos", action="store_true")
    ap.add_argument("--sem-filtro-nome", action="store_true")
    ap.add_argument("--cred", default=str(AQUI / "credenciais.env"))
    ap.add_argument("--visivel", action="store_true")
    ap.add_argument("--discover", action="store_true")
    a = ap.parse_args()

    contrato = re.sub(r"\D", "", str(a.contrato)) or str(a.contrato).strip()
    env = ler_env(a.cred)
    px_url = env.get("ODOO_URL", PX_URL_PADRAO).rstrip("/")
    dbg = Debug(a.discover)
    resultado = {"contrato": contrato, "tipo_arquivo": a.tipo, "operadoras_consultadas": [], "paginas_varridas": 0,
                 "encontrados": []}
    print(f"Consultando carga API: contrato={contrato} tipo='{a.tipo}' operadora~'{a.operadora}'")
    with sync_playwright() as p:
        b = p.chromium.launch(headless=not a.visivel)
        kw = {"viewport": {"width": 1600, "height": 1000}, "locale": "pt-BR"}
        if STATE.exists():
            kw["storage_state"] = str(STATE)
        c = b.new_context(**kw)
        c.on("request", dbg.rede)
        pg = c.new_page()
        try:
            abrir_sdi(pg, px_url, env)
            tela = tela_sdi(pg)
            dbg.passo(pg, "menu SDI")
            clicar(tela, "Carga de Dados", "Carga de Dados")
            tela.get_by_text(rx("Tipo de arquivo")).first.wait_for(state="visible", timeout=60000)
            esperar(pg, 2)
            dbg.passo(pg, "carga de dados")
            escolher_opcao(pg, tela, "Tipo de arquivo", a.tipo, rx(a.tipo), f"tipo de arquivo '{a.tipo}'")
            esperar(pg, 1.5)
            operadoras = listar_operadoras(pg, tela, a.operadora)
            if not operadoras:
                raise RuntimeError(f"Nao achei nenhuma operadora com '{a.operadora}' no filtro. Rode com --discover.")
            print("  Operadoras:", " | ".join(operadoras))
            for op in operadoras:
                escolher_opcao(pg, tela, "Operadora", op, re.compile(r"^\s*" + re.escape(op) + r"\s*$", re.I),
                               f"operadora '{op}'")
                esperar(pg, 2)
                achados, pags, cob = varrer(pg, tela, dbg, contrato, op, a.max_paginas, a.todos,
                                            not a.sem_filtro_nome)
                resultado["operadoras_consultadas"].append(op)
                resultado["paginas_varridas"] += pags
                resultado.setdefault("cobertura", []).append(cob)
                for r in achados:
                    r["operadora_filtro"] = op
                resultado["encontrados"] += achados
                print(f"  {op}: {len(achados)} arquivo(s) em {pags} pagina(s)")
                if achados and not a.todos:
                    break
            SESSAO_DIR.mkdir(exist_ok=True)
            c.storage_state(path=str(STATE))
        except Exception as e:
            dbg.passo(pg, "erro")
            print("\nERRO:", e)
            sys.exit(1)
        finally:
            dbg.salvar()
            b.close()
    if not resultado["encontrados"]:
        incompletas = [c["operadora"] for c in resultado.get("cobertura", []) if c["completa"] is not True]
        resultado["varredura_completa"] = not incompletas
        if incompletas:
            resultado["observacao"] = ("NAO ENCONTRADO, MAS A VARREDURA FICOU INCOMPLETA em: " + ", ".join(incompletas)
                                       + ". O arquivo pode existir; conferir manualmente ou repetir com --operadora exata.")
        else:
            resultado["observacao"] = ("Nenhum arquivo com esse contrato nas operadoras consultadas (todas as linhas da "
                                       "tela foram lidas), no periodo do filtro (padrao da tela: ultimos 30 dias).")
    print("RESULTADO_JSON: " + json.dumps(resultado, ensure_ascii=True))


if __name__ == "__main__":
    main()
