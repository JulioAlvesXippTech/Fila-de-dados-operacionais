#!/usr/bin/env python3
"""Fila de execução dos direcionamentos APROVADOS na Plataforma (aba Pré-análise).

Regra do Julio (26/10/2026): aprovar na Plataforma = confirmação de produção, executada pela tarefa
agendada "Executor de aprovados" (de hora em hora, dias úteis 8h-18h), só para as ações liberadas:
  - "Maninha"                    -> criticador + nota interna com @menção e anexo (sem mudar fila/atribuído)
  - "Avançar para Em andamento"  -> mudar_status.py --para andamento
  - "Encerrar (Fechado)" / "Encerrar" -> mudar_status.py --para fechar
  - "Carga sem arquivo – dados do contrato" -> carga_sem_arquivo.py (pasta Carga SDI + nota se o contrato não tiver acesso)
Qualquer outra ação aprovada NÃO é executada automaticamente: fica para o Julio decidir no chat.

direcionamentos.json é um log só de acréscimo: o último registro de cada id é o estado atual.

Uso:
  python3 aprovados.py --dirs direcionamentos.json listar
  python3 aprovados.py --dirs direcionamentos.json marcar --id 591930 --status executado --nota "nota postada ..."
  python3 aprovados.py --dirs direcionamentos.json marcar --id 591930 --status falhou --nota "motivo"
  python3 aprovados.py --dirs direcionamentos.json marcar --id 591930 --status manual --nota "precisa do Julio: ..."
"""
import argparse, json, os, shutil
from datetime import datetime

AUTO = {"Repassar responsável": "repassar", "Maninha": "maninha", "Carga sem arquivo – dados do contrato": "carga_sem_arquivo", "Avançar para Em andamento": "andamento", "Encerrar (Fechado)": "fechar", "Encerrar": "fechar"}
EM_EXEC_MAX_H = 2  # "em execução" mais antigo que isso é considerado travado e volta para a fila


def ler(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def gravar(p, dirs):
    bk = os.path.join(os.path.dirname(os.path.abspath(p)), "..", "Plataforma", "_backups")
    if os.path.isdir(bk):
        shutil.copy2(p, os.path.join(bk, f"direcionamentos_antes_{datetime.now():%Y%m%d_%H%M%S}.json"))
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(dirs, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def ultimos(dirs):
    u = {}
    for d in dirs:
        u[d.get("id")] = d
    return u


def listar(dirs):
    agora = datetime.now()
    out = []
    for cid, d in ultimos(dirs).items():
        st = str(d.get("status", ""))
        if st.startswith("em execução"):
            try:
                desde = datetime.fromisoformat(d.get("quando"))
                if (agora - desde).total_seconds() < EM_EXEC_MAX_H * 3600:
                    continue
            except Exception:
                pass
        elif not st.startswith("aprovado") or "precisa de decisão" in st:
            continue  # já marcado como manual: não relistar a cada rodada
        acao = d.get("acao") or ""
        out.append({"id": cid, "numero": d.get("numero"), "protocolo": d.get("protocolo"), "titulo": d.get("titulo"),
                    "solicitante": d.get("solicitante"), "acao": acao, "texto": d.get("texto") or "",
                    "aprovado_em": d.get("aprovado_em"), "automatico": AUTO.get(acao) or None})
    return out


def marcar(p, cid, status, nota):
    dirs = ler(p)
    ult = ultimos(dirs).get(cid)
    if not ult:
        raise SystemExit(f"id {cid} sem direcionamento")
    agora = datetime.now()
    rot = {"em_execucao": "em execução desde " + agora.strftime("%d/%m/%Y %H:%M"),
           "executado": "executado em " + agora.strftime("%d/%m/%Y %H:%M"),
           "falhou": "falhou em " + agora.strftime("%d/%m/%Y %H:%M") + " — aprove de novo para repetir",
           "manual": "aprovado — precisa de decisão do Julio no chat"}[status]
    reg = dict(ult, quando=agora.isoformat(timespec="seconds"), status=rot)
    if nota:
        reg["execucao"] = nota
    dirs.append(reg)
    gravar(p, dirs)
    print(json.dumps({"id": cid, "status": rot}, ensure_ascii=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dirs", required=True)
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("listar")
    m = sp.add_parser("marcar")
    m.add_argument("--id", type=int, required=True)
    m.add_argument("--status", choices=["em_execucao", "executado", "falhou", "manual"], required=True)
    m.add_argument("--nota", default="")
    a = ap.parse_args()
    if a.cmd == "listar":
        print(json.dumps(listar(ler(a.dirs)), ensure_ascii=False, indent=1))
    else:
        marcar(a.dirs, a.id, a.status, a.nota)


if __name__ == "__main__":
    main()
