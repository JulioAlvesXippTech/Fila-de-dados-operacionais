#!/usr/bin/env python3
"""Devolve um atendimento ao SOLICITANTE: Atribuído a = solicitante; Fila = a única fila (helpdesk.ticket.team)
em que o solicitante é membro. Ação "Devolver ao solicitante" da Plataforma, criada a pedido do Julio em 26/10/2026.

Escrita em PRODUÇÃO só com --confirmar-producao e só depois de o Julio aprovar o direcionamento.
Única escrita: helpdesk.ticket.write {user_id, team_id}. Nunca unlink. Backup antes; relê depois.
Se o solicitante não for usuário interno ou não tiver exatamente UMA fila, não altera nada e relata.

Uso: python3 devolver_solicitante.py --cred credenciais.env --id 587633 --out <pasta> [--confirmar-producao]
"""
import argparse, json, os, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agente_atendimentos import Odoo, load_env, BRT

CAMPOS = ["number", "protocol_code", "name", "user_id", "team_id", "stage_id", "xipp_requester_id"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--id", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--confirmar-producao", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    o = Odoo(load_env(a.cred))
    t = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": CAMPOS})[0]
    sol = t.get("xipp_requester_id")
    plano = {"atendimento": t["number"], "protocolo": t["protocol_code"], "titulo": t["name"],
             "antes": {"atribuido": t["user_id"], "fila": t["team_id"], "etapa": t["stage_id"]}, "solicitante": sol}
    if not sol:
        sys.exit("BLOQUEIO: atendimento sem solicitante")
    us = o.call("res.users", "search_read", [[["id", "=", sol[0]]]], {"fields": ["id", "name"], "limit": 1})
    if not us:
        sys.exit(f"BLOQUEIO: solicitante {sol[1]} não é usuário interno do Odoo")
    filas = o.call("helpdesk.ticket.team", "search_read", [[["member_ids", "in", [sol[0]]]]], {"fields": ["id", "name"]})
    if len(filas) != 1:
        sys.exit(f"BLOQUEIO: solicitante {sol[1]} está em {len(filas)} filas ({', '.join(f['name'] for f in filas)}) — fila não é única")
    plano["depois"] = {"atribuido": [us[0]["id"], us[0]["name"]], "fila": [filas[0]["id"], filas[0]["name"]]}
    agora = datetime.now(BRT)
    plano["modo"] = "PRODUÇÃO" if a.confirmar_producao else "SIMULAÇÃO (nada gravado)"
    bpath = os.path.join(a.out, f"backup_devolucao_{t['protocol_code']}_{agora:%Y%m%d_%H%M}.json")
    json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if not a.confirmar_producao:
        print(json.dumps(plano, ensure_ascii=False, indent=1))
        return
    if o.uid is None:
        o.call("res.users", "search_count", [[["id", "=", -1]]])
    try:
        o._post("/jsonrpc", {"service": "object", "method": "execute_kw",
                             "args": [o.db, o.uid, o.key, "helpdesk.ticket", "write",
                                      [[a.id], {"user_id": us[0]["id"], "team_id": filas[0]["id"]}]]})
    except SystemExit as e:  # o Odoo desfaz a gravação inteira quando recusa (ex.: sem permissão na fila de destino)
        plano["ok"] = False
        plano["erro"] = str(e)[:300]
        json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        sys.exit("RECUSADO PELO ODOO (nada foi alterado): " + str(e)[:200])
    d = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["user_id", "team_id", "stage_id"]})[0]
    plano["depois_lido"] = d
    plano["ok"] = d["user_id"] and d["user_id"][0] == us[0]["id"] and d["team_id"] and d["team_id"][0] == filas[0]["id"]
    json.dump(plano, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"ok": plano["ok"], "depois": d, "backup": os.path.basename(bpath)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
