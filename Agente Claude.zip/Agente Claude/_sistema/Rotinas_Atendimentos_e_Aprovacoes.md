# Agente de Atendimentos — Atualização e Aprovações

Resumo das rotinas "atualiza os atendimentos" e "roda as aprovações" (fila Dados Operacionais), com o registro da execução de 18/11/2026.

> Fontes: `_sistema\LEIA-ME_CLAUDE.md`, `aprendizado.txt`, as skills `atendimentos-atualizar` e `atendimentos-aprovacoes`, e a execução agendada desta conversa.

---

## 1. Regras gerais (valem para as duas rotinas)

- Pasta de tudo: `C:\Users\JulioCesardaSilvaAlv\Downloads\Claude\Agente Claude\_sistema\`.
- O Claude não tem terminal no PC: **prepara** (`device_stage_files`) os arquivos para a nuvem, roda os scripts lá e **grava de volta** (`device_commit_files`).
- Gravar sempre **a partir de uma cópia com nome NOVO** (ex.: `envio/preanalise_MMDD_HHMM.json`) e com `expectedMtimeMs` do stage. Reenviar com o mesmo nome já gravou versão antiga (12/11/2026).
- Depois de gravar: **preparar de novo e comparar com `cmp`**.
- Se a gravação for recusada por mudança (o Julio mexeu na Plataforma): preparar de novo, reaplicar só as alterações do Claude e gravar outra vez.
- Nunca ler/exibir `credenciais.env`, `.env`, `state.json` ou senhas. Nunca apagar arquivos do Julio. Sem CPF/dados pessoais nos textos.
- `ERRO_AUTENTICACAO` = chave de API do Odoo expirada → renovar em **Preferências → Segurança da conta → Nova chave de API** e atualizar `credenciais.env`.
- Ao citar um atendimento: sempre **HT + protocolo**, nunca só o id interno.

---

## 2. Rotina 1 — "atualiza os atendimentos" (somente leitura no Odoo)

### Arquivos preparados
`LEIA-ME_CLAUDE.md`, `credenciais.env`, `agente_atendimentos.py`, `relatorio_carga_layout.py`, `carga_sem_arquivo.py`, `encaminhar.py`, `postar_criticador.py`, `preanalise_coleta.py`, `fila_completa.py`, `regras_bot.py`, `monta_pre.py`, `novidades.py`, `preanalise.json`, `preanalise_textos.json`, `fila_completa.json`, `aprendizado.txt`.

### Passos
```
python3 preanalise_coleta.py --cred credenciais.env --saida coleta.json
python3 fila_completa.py     --cred credenciais.env --saida fila_completa.json
python3 novidades.py coleta.json          # mostra só NOVOS e MUDARAM
```
1. Para cada NOVO/MUDOU, escrever em `preanalise_textos.json`:
   `{"<id>": [pedido, situação, sugestão, ação, prioridade]}` — textos curtos, seguindo `aprendizado.txt`.
2. `python3 monta_pre.py coleta.json preanalise.json`
3. Gravar `preanalise.json`, `fila_completa.json`, `preanalise_textos.json` (e `regras_bot.py` se mudou).
4. Responder: total, novos que pedem atenção, novidades relevantes, e lembrar de apertar **↻ Recarregar** na Plataforma.

### Ações válidas
Maninha · Carregador · Baixar/enviar PC · Cobrar operadora · Cobrar solicitante · Responder solicitante · Devolver ao solicitante · Repassar responsável (pessoa da MESMA fila) · Reatribuir fila · Aguardar terceiro · Tech/sistema · Carga sem arquivo – dados do contrato · Avançar para Em andamento · Encerrar · Outro.
Prioridade: Alta / Média / Baixa.

### Xipp Bot (`regras_bot.py`)
- Códigos de acesso/senhas e divulgações → Encerrar.
- Boletos/faturas/NF/pagamento → Reatribuir fila Faturamento.
- Relatórios → sem sugestão fixa.
- Padrão novo e óbvio → acrescentar o termo à regra certa em `regras_bot.py` (única alteração permitida em scripts).

---

## 3. Rotina 2 — "roda as aprovações"

Aprovar na Plataforma = confirmação de produção para as ações liberadas.

1. Preparar `direcionamentos.json` (guardar mtimeMs), `credenciais.env`, os .py e `filas_px.json`.
   `python3 aprovados.py --dirs direcionamentos.json listar`
2. Executar por tipo:

| Ação | Comando / procedimento |
|---|---|
| Encerrar | `mudar_status.py --cred credenciais.env --id N --para fechar --out <pasta> --confirmar-producao` (um por id). Quando pedido, Assunto = "Base Beneficiários" e Solicitação = "Solicitação". |
| Repassar responsável | `acoes_manuais.py --cred credenciais.env --out <pasta> delegar --id N --para "Nome" --confirmar-producao` — só membros da fila Dados Operacionais; a fila nunca muda. "João" é ambíguo → "João Lourenço". |
| Reatribuir fila | `vigia_fila.py pedir --dirs direcionamentos.json --out pedidos --filas filas_px.json --cred credenciais.env --lote 28`; gravar cada pedido em `_sistema\_fila\`. Agendar **uma** conferência (`send_later`) no horário estimado (1,5 min + ~65 s por atendimento; o Vigia corta cada pedido em 60 min) e rodar `vigia_fila.py conferir`. Se "Tempo esgotado", conferir pela API quem ainda está em Dados Operacionais e reenviar só esses. |
| Maninha | `executar_maninha.py` → gravar a pasta em Layouts → `postar_criticador.py ... --confirmar-producao`. |
| Carregador | `preparar_carregador.py` (aceita PDF) + skills "o-carregador-do-futuro" / "regras-carga-sdi-xipp" no formato escolhido na Plataforma (sdi/pc). **Não acionar o Vigia para baixar a base do SDI** (13/11/2026): sem base em `Arquivo Origem`, gerar `_PENDENTE` e deixar as perguntas em `Arquivo Final\Duvidas.txt`. |

3. Marcar cada um: `aprovados.py --dirs direcionamentos.json marcar --id N --status executado|falhou|manual --nota "..."`.
4. Gravar `direcionamentos.json` (log só de acréscimo; o Julio também grava pela Plataforma → sempre preparar antes; se recusar por mtime, juntar os registros novos do Julio e gravar; conferir com cmp).
5. Responder curto: quantos de cada ação, o que ficou pendente e quando sai o resultado do Vigia.

> O PC não pode suspender durante um lote do Vigia (PowerToys Awake ou `powercfg /change standby-timeout-ac 0`). Vigia vivo se `_fila\vigia_ativo.txt` for recente.

---

## 4. Regras aprendidas (`aprendizado.txt`)

- **28/10** — Dados do contrato: só contrato Ativo ou Em Implantação; subempresas fechadas/canceladas não entram.
- **29/10** — HT114838 (Prio Odonto): carga via API só com contrato ATIVO; Em Implantação → devolver ao solicitante.
- **29/10** — HT116216 (CNA): API de carga de PC só existe para Bradesco Saúde e Bradesco Dental; nas demais operadoras, Carregador do Futuro mesmo com contrato Em Implantação.
- **29/10** — Criticador anexado sem vidas (modelo vazio) → pedir a base ao solicitante.
- **27/10** — Encerrar: quando pedido, Assunto = "Base Beneficiários" e Solicitação = "Solicitação".
- **13/11** — Carregador: não acionar o Vigia para baixar base do SDI; gerar `_PENDENTE` + `Duvidas.txt`.
- Fora da Plataforma: Kennedy Pardinho, Marlon Ferreira, Marcello Nascimento, Jonas Vidal, Matheus Bessa, Felipe Aranda, Francisco Souza. Xipp Bot de Posição Cadastral/Faturamento: só contagem.

---

## 5. Registro da execução — 18/11/2026 (tarefa agendada "Atualizar atendimentos")

- A pasta `_sistema` não estava conectada à sessão; o acesso foi pedido e concedido.
- Coleta OK: **196 abertos**, **2 NOVOS**, 0 MUDARAM (corte 18/11/2026 12:44 UTC).
- Textos escritos:

| HT / protocolo | Pedido | Ação sugerida | Prioridade |
|---|---|---|---|
| HT140630 / 618679 | RTT (Bradesco): base SISA com município/UF de todas as vidas, para a Gestão de Risco analisar sinistralidade por região. Novo, sem responsável. | Baixar/enviar PC | Média |
| HT69136 / 547178 | Central IT (Amil Saúde 2834801): colaborador ativo em duas subs; Julio enviou a análise em 17/11 e Ugor pediu à cliente a regularização em 18/11. | Aguardar terceiro | Baixa |

- `regras_bot.py` não mudou.
- Gravados `preanalise.json`, `fila_completa.json` e `preanalise_textos.json` (cópias `*_1118_0955.json`); conferência com `cmp` OK nos três.
- Nenhuma aprovação foi executada nesta conversa (é outra rotina).

---

## 6. Pendências conhecidas (LEIA-ME, 16/11/2026)

- Morumbi Sul HT129917 (575387-1, 159 vidas) e HT129916 (575395-1, 5 vidas): layouts `_PENDENTE` em Carga SDI; dúvidas na Plataforma.
- 5 Carregadores T-Systems e o 600883 (Uniodonto): falta escolher o formato na Plataforma; Saúde travado pelo erro de sub no SDI.
- Tarefa agendada "Executor de aprovados" com instruções antigas: aprovar a atualização no app do desktop.
