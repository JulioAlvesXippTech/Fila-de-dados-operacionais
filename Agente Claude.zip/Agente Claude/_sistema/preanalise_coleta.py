#!/usr/bin/env python3
"""Coleta (SOMENTE LEITURA) os atendimentos abertos da fila Dados Operacionais para a PRÉ-ANÁLISE.

Mesmo filtro da aba "Dados Operacionais" do relatório (fila Dados Operacionais, etapa não dobrada,
Xipp Bot só fora de Posição Cadastral/Faturamento, exceto responsáveis em FORA_DA_PLATAFORMA). Para cada atendimento traz descrição, últimas
interações, anexos e contrato, para o Claude escrever a pré-análise.
Uso: python3 preanalise_coleta.py --cred credenciais.env --saida preanalise_dados.json
"""
import argparse, json, os, re, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import agente_atendimentos as A
import relatorio_carga_layout as R
import carga_sem_arquivo as CSA
ARQ_BASE = CSA.ARQ

# 28/10/2026: apaga tudo até 40 caracteres depois da palavra (antes só a 1ª palavra, e senhas como "Senha temporária: X" vazavam)
# 03/11/2026: também códigos de acesso/verificação (e-mails de login encaminhados para a fila)
RED = re.compile(r"(?i)(senha|password|pwd|c[óo]digo de acesso|c[óo]digo de verifica[çc][ãa]o|c[óo]digo de seguran[çc]a|token|utilize este c[óo]digo)\b[^\n]{0,40}")
# 11/11/2026: e-mail de código (2º fator etc.) — mascara também números de 4 a 8 dígitos soltos no texto todo
COD_EMAIL = re.compile(r"(?i)c[óo]digo|segundo fator|token|autentica[çc][ãa]o|senha|password")


def red(txt):
    txt = RED.sub(r"\1 ***", txt)
    return re.sub(r"\b\d{4,8}\b", "***", txt) if COD_EMAIL.search(txt) else txt


IMG = re.compile(r"^image\d*(\.\w+)?$|\.(png|jpe?g|gif|bmp)$", re.I)


def filas_dos_solicitantes(o, uids):
    """Fila(s) de atendimento (helpdesk.ticket.team) em que cada solicitante é membro. Só leitura."""
    uids = sorted({u for u in uids if u})
    fil = {u: [] for u in uids}
    if uids:
        for f in o.call("helpdesk.ticket.team", "search_read", [[["member_ids", "in", uids]]],
                        {"fields": ["name", "member_ids"], "limit": 2000}):
            for u in f["member_ids"]:
                if u in fil:
                    fil[u].append(f["name"])
    return {u: sorted(v) for u, v in fil.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--saida", required=True)
    a = ap.parse_args()
    o = A.Odoo(A.load_env(a.cred))
    # 11/11/2026 (Julio): Xipp Bot também entra, exceto solicitação Posição Cadastral / Faturamento (rotinas RPA)
    dom = [["team_id", "ilike", "Dados operacionais"], ["stage_id.fold", "=", False],
           "|", ["xipp_requester_id", "not ilike", "Xipp bot"],
           "|", ["xipp_request_id", "=", False], ["xipp_request_id.name", "not in", ["Posição Cadastral", "Faturamento"]]]
    ts = o.call("helpdesk.ticket", "search_read", [dom], {
        "fields": ["id", "name", "number", "protocol_code", "stage_id", "user_id", "ticket_type_id", "xipp_request_id",
                   "description", "create_date", "write_date", "xipp_requester_id", "xipp_contract_id"], "limit": 5000})
    exc = {A._sem_acento(n).lower() for n in R.FORA_DA_PLATAFORMA}
    ts = [t for t in ts if A._sem_acento(A.m2o(t["user_id"]) or "").lower() not in exc]
    ids = [t["id"] for t in ts]
    msgs, atts = {}, {}
    for k in range(0, len(ids), 300):
        bloco = ids[k:k + 300]
        for m in o.call("mail.message", "search_read", [[["model", "=", "helpdesk.ticket"], ["res_id", "in", bloco],
                                                          ["message_type", "in", ["comment", "email"]]]],
                        {"fields": ["res_id", "date", "author_id", "body", "subtype_id"], "limit": 200000, "order": "id asc"}):
            msgs.setdefault(m["res_id"], []).append(m)
        for x in o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "in", bloco]]],
                        {"fields": ["res_id", "name", "create_date"], "limit": 200000}):
            if not IMG.search(x["name"] or ""):
                atts.setdefault(x["res_id"], []).append(x)
    filas = filas_dos_solicitantes(o, [t["xipp_requester_id"][0] for t in ts if t["xipp_requester_id"]])
    hoje = datetime.now(A.BRT).date()
    fer = R.feriados(range(2024, hoje.year + 2))
    out = []
    for t in ts:
        ms = msgs.get(t["id"], [])
        ult = ms[-1] if ms else None
        ab = datetime.strptime(A.brt(t["create_date"]), "%d/%m/%Y %H:%M")
        ui = datetime.strptime(A.brt(ult["date"] if ult else t["write_date"]), "%d/%m/%Y %H:%M")
        tipo = R.classifica(t) or "Outro"
        dados_contrato = None
        if tipo == "Carga" and not any(ARQ_BASE.search(x["name"] or "") for x in atts.get(t["id"], [])):
            # direcionamento do Julio (27/10/2026): carga sem arquivo -> dados do contrato (sem senha)
            try:
                dados_contrato = CSA.levantar(o, t) or {"erro": "contrato não identificado no atendimento"}
            except SystemExit as e:
                dados_contrato = {"erro": str(e)[:200]}
        out.append({
            "id": t["id"], "numero": t["number"] if t["number"] and t["number"] != "/" else "",
            "protocolo": t["protocol_code"] or "", "titulo": (t["name"] or "").strip(),
            "responsavel": A.m2o(t["user_id"]) or "Sem responsável", "solicitante": A.m2o(t["xipp_requester_id"]) or "",
            "fila_solicitante": (filas.get(t["xipp_requester_id"][0]) if t["xipp_requester_id"] else None) or ["Sem fila"],
            "bot": "xipp bot" in A._sem_acento(A.m2o(t["xipp_requester_id"]) or "").lower(),
            "tipo": tipo, "dados_contrato": dados_contrato, "etapa": A.m2o(t["stage_id"]) or "",
            "tipo_atendimento": A.m2o(t["ticket_type_id"]) or "", "solicitacao": A.m2o(t["xipp_request_id"]) or "",
            "contrato": A.m2o(t["xipp_contract_id"]) or "",
            "abertura": ab.strftime("%d/%m/%Y"), "ultima_interacao": ui.strftime("%d/%m/%Y %H:%M"),
            "ultimo_autor": (A.m2o(ult["author_id"]) if ult else "") or "",
            "dias_uteis_abertura": R.dias_uteis(ab.date(), hoje, fer),
            "dias_uteis_sem_interacao": R.dias_uteis(ui.date(), hoje, fer),
            "descricao": red(A.txt(t["description"] or ""))[:1500],
            "mensagens": [{"data": A.brt(m["date"]), "autor": A.m2o(m["author_id"]) or "", "texto": red(A.txt(m["body"] or ""))[:700]}
                          for m in ms[-6:]],
            "anexos": [{"nome": x["name"], "data": A.brt(x["create_date"])[:10]}
                       for x in sorted(atts.get(t["id"], []), key=lambda x: x["create_date"])][-8:],
            "link": f"https://plataforma.xipp.com.br/web#id={t['id']}&model=helpdesk.ticket&view_type=form",
        })
    json.dump({"coletado_em": datetime.now(A.BRT).strftime("%d/%m/%Y %H:%M"), "itens": out},
              open(a.saida, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"total": len(out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
