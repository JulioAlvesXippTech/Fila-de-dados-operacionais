#!/usr/bin/env python3
"""Coleta (SOMENTE LEITURA) a FILA COMPLETA de Dados Operacionais para a aba "Fila completa" da Plataforma.

Pedido do Julio (11/11/2026): ver todos os atendimentos abertos da fila — só informações, sem pré-análise.
Ficam de fora (inclusive da contagem RPA) os responsáveis em R.FORA_DA_PLATAFORMA
(Kennedy, Marlon, Marcello, Jonas Vidal, Matheus Bessa, Felipe Aranda, Francisco Souza).
Xipp Bot (pedido do Julio de 11/11/2026): entram na lista, EXCETO quando a solicitação é Posição Cadastral
ou Faturamento (rotinas RPA, dezenas de milhares) — esses entram só como contagem por etapa/responsável
no bloco "rpa". Solicitação em branco ou qualquer outra (Atualização, Solicitação, Sinistro...) entra.

Uso: python3 fila_completa.py --cred credenciais.env --saida fila_completa.json
"""
import argparse, json, os, re, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import agente_atendimentos as A
import relatorio_carga_layout as R


def filas_dos_solicitantes(o, uids):
    """Fila(s) de atendimento em que cada solicitante é membro (mesma regra da Pré-análise). Só leitura."""
    uids = sorted({u for u in uids if u})
    fil = {u: [] for u in uids}
    if uids:
        for f in o.call("helpdesk.ticket.team", "search_read", [[["member_ids", "in", uids]]],
                        {"fields": ["name", "member_ids"], "limit": 2000}):
            for u in f["member_ids"]:
                if u in fil:
                    fil[u].append(f["name"])
    return {u: sorted(v) for u, v in fil.items()}

TEAM = 27  # Dados Operacionais
BOT = "Xipp bot"
SOLIC_RPA = ["Posição Cadastral", "Faturamento"]  # do Xipp Bot: só contagem
# mesma regra da Pré-análise: e-mails de login/código encaminhados não podem expor o código no título
RED = re.compile(r"(?i)(senha|password|pwd|c[óo]digo de acesso|c[óo]digo de verifica[çc][ãa]o|c[óo]digo de seguran[çc]a|token|utilize este c[óo]digo)\s*[:=]\s*[A-Za-z0-9]{4,}")
CAMPOS = ["id", "name", "number", "protocol_code", "stage_id", "user_id", "ticket_type_id", "xipp_request_id",
          "create_date", "write_date", "xipp_requester_id", "xipp_contract_id", "description"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--saida", required=True)
    a = ap.parse_args()
    o = A.Odoo(A.load_env(a.cred))
    base = [["team_id", "=", TEAM], ["stage_id.fold", "=", False]]
    ts = o.call("helpdesk.ticket", "search_read",
                [base + ["|", ["xipp_requester_id", "not ilike", BOT], "|", ["xipp_request_id", "=", False],
                         ["xipp_request_id.name", "not in", SOLIC_RPA]]],
                {"fields": CAMPOS, "limit": 50000, "order": "create_date desc"})
    # RPA / Xipp Bot com Posição Cadastral ou Faturamento: só contagem
    fora = {A._sem_acento(n).lower() for n in R.FORA_DA_PLATAFORMA}
    ts = [t for t in ts if A._sem_acento(A.m2o(t["user_id"]) or "").lower() not in fora]
    rpa = {}
    for t in o.call("helpdesk.ticket", "search_read", [base + [["xipp_requester_id", "ilike", BOT],
                                                              ["xipp_request_id.name", "in", SOLIC_RPA]]],
                    {"fields": ["stage_id", "user_id"], "limit": 500000}):
        if A._sem_acento(A.m2o(t["user_id"]) or "").lower() in fora:
            continue
        k = (A.m2o(t["stage_id"]) or "", A.m2o(t["user_id"]) or "Sem responsável")
        rpa[k] = rpa.get(k, 0) + 1
    ids = [t["id"] for t in ts]
    ult = {}
    for k in range(0, len(ids), 300):
        for m in o.call("mail.message", "search_read", [[["model", "=", "helpdesk.ticket"], ["res_id", "in", ids[k:k + 300]],
                                                          ["message_type", "in", ["comment", "email"]]]],
                        {"fields": ["res_id", "date", "author_id"], "limit": 200000, "order": "id asc"}):
            ult[m["res_id"]] = m
    filas = filas_dos_solicitantes(o, [t["xipp_requester_id"][0] for t in ts if t["xipp_requester_id"]])
    exc = fora
    hoje = datetime.now(A.BRT).date()
    fer = R.feriados(range(2024, hoje.year + 2))
    out = []
    for t in ts:
        m = ult.get(t["id"])
        ab = datetime.strptime(A.brt(t["create_date"]), "%d/%m/%Y %H:%M")
        ui = datetime.strptime(A.brt(m["date"] if m else t["write_date"]), "%d/%m/%Y %H:%M")
        resp = A.m2o(t["user_id"]) or ""
        out.append({
            "id": t["id"], "numero": t["number"] if t["number"] and t["number"] != "/" else "",
            "protocolo": t["protocol_code"] or "", "titulo": RED.sub(r"\1: ***", (t["name"] or "").strip()),
            "responsavel": resp or "Sem responsável", "solicitante": A.m2o(t["xipp_requester_id"]) or "",
            "fila_solicitante": (filas.get(t["xipp_requester_id"][0]) if t["xipp_requester_id"] else None) or ["Sem fila"],
            "tipo": R.classifica(t) or "Outro", "etapa": A.m2o(t["stage_id"]) or "",
            "tipo_atendimento": A.m2o(t["ticket_type_id"]) or "", "solicitacao": A.m2o(t["xipp_request_id"]) or "",
            "contrato": A.m2o(t["xipp_contract_id"]) or "",
            "abertura": ab.strftime("%d/%m/%Y %H:%M"), "ultima_interacao": ui.strftime("%d/%m/%Y %H:%M"),
            "ultimo_autor": (A.m2o(m["author_id"]) if m else "") or "",
            "dias_uteis_abertura": R.dias_uteis(ab.date(), hoje, fer),
            "dias_uteis_sem_interacao": R.dias_uteis(ui.date(), hoje, fer),
            "na_preanalise": A._sem_acento(resp).lower() not in exc and "xipp bot" not in A._sem_acento(A.m2o(t["xipp_requester_id"]) or "").lower(),
            "bot": "xipp bot" in A._sem_acento(A.m2o(t["xipp_requester_id"]) or "").lower(),
            "link": f"https://plataforma.xipp.com.br/web#id={t['id']}&model=helpdesk.ticket&view_type=form",
        })
    json.dump({"coletado_em": datetime.now(A.BRT).strftime("%d/%m/%Y %H:%M"), "itens": out,
               "rpa": [{"etapa": e, "responsavel": r, "qtd": n} for (e, r), n in sorted(rpa.items(), key=lambda x: -x[1])]},
              open(a.saida, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"total": len(out), "rpa": sum(rpa.values())}, ensure_ascii=False))


if __name__ == "__main__":
    main()
