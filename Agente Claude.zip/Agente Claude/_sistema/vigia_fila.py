#!/usr/bin/env python3
"""Ação "Reatribuir fila" da Plataforma -> pedido para o Vigia (px_atribuir_fila.py), depois de aprovada pelo Julio.
Pedido do Julio (12/11/2026). Segue as regras da seção 9 do Vigia_SDI_PX_Documentacao.md:
  - vários protocolos da mesma fila = UM pedido só (campo "protocolos");
  - antes de mandar, registra a fila atual (todos estão na fila Dados Operacionais, conferido pela coleta);
  - uma conferência só, no horário estimado.

  pedir    : lê direcionamentos.json, junta os aprovados com acao "Reatribuir fila" ainda não enviados,
             grava 1 pedido por fila de destino em --out (para copiar em _sistema\\_fila\\) e acrescenta em
             direcionamentos.json o status "enviado ao Vigia — pedido <id>".
  conferir : lê <id>.status.json (em _fila ou _fila\\feito, copiados para --status-dir) e marca cada atendimento
             como executado (transferido / já estava) ou falhou.

Uso: python3 vigia_fila.py pedir    --dirs direcionamentos.json --out pedidos/ --filas filas_px.json --cred credenciais.env [--simular]
     python3 vigia_fila.py conferir --dirs direcionamentos.json --status-dir status/
"""
import argparse, glob, json, os, re, shutil, sys, unicodedata
from datetime import datetime

ACAO = "Reatribuir fila"


def ultimos(dirs):
    u = {}
    for d in dirs:
        u[d.get("id")] = d
    return u


def slug(x):
    x = "".join(c for c in unicodedata.normalize("NFD", x) if unicodedata.category(c) != "Mn")
    return re.sub(r"[^A-Za-z0-9]+", "_", x).strip("_")[:30]


def gravar(path, dirs):
    bk = path + f".antes_vigia_{datetime.now():%Y%m%d_%H%M%S}"
    shutil.copy2(path, bk)
    tmp = path + ".tmp"
    json.dump(dirs, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    os.replace(tmp, path)
    return bk


def norm(x):
    x = unicodedata.normalize("NFD", str(x or ""))
    return " ".join("".join(c for c in x if unicodedata.category(c) != "Mn").lower().split())


def fila_do_texto(txt, filas):
    """Aprovados antes de 12/11 não têm fila_destino: tira do texto/sugestão ("fila de Faturamento"), só se exato."""
    m = re.search(r"fila\s+(?:de\s+|da\s+|do\s+)?([A-ZÀ-Úa-zà-ú0-9 ]{3,40}?)(?:\s*[—–(.,;:-]|$)", txt or "")
    if not m:
        return None
    ach = [f for f in filas if norm(f) == norm(m.group(1))]
    return ach[0] if len(ach) == 1 else None


def pedir(a):
    dirs = json.load(open(a.dirs, encoding="utf-8"))
    filas = json.load(open(a.filas, encoding="utf-8"))["filas"] if a.filas else []
    o = None
    if a.cred:   # regra 5 do Vigia: registrar o estado atual antes de mandar (e não mandar o que já saiu da fila)
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import agente_atendimentos as A
        o = A.Odoo(A.load_env(a.cred))
    cand = [d for d in ultimos(dirs).values() if d.get("acao") == ACAO and str(d.get("status", "")).startswith("aprovado")]
    atual = {}
    if a.atual:   # estado atual lido por fora (ex.: conector MCP da PX quando a API key está expirada)
        bruto = json.load(open(a.atual, encoding="utf-8"))
        atual = {int(k): tuple(v) for k, v in bruto.items()}
        for d in cand:
            atual.setdefault(d["id"], ("fora da visão do seu usuário — provavelmente já transferido", "?"))
    if o and cand:
        ids = [d["id"] for d in cand]
        # search_read só devolve o que o usuário enxerga; o que sumiu já foi para uma fila fora da visão dele
        for t in o.call("helpdesk.ticket", "search_read", [[["id", "in", ids]]], {"fields": ["team_id", "stage_id"]}):
            atual[t["id"]] = ((t["team_id"] or [0, ""])[1], (t["stage_id"] or [0, ""])[1])
        for i in ids:
            atual.setdefault(i, ("fora da visão do seu usuário — provavelmente já transferido", "?"))
    grupos, sem_fila, ja = {}, [], []
    for d in cand:
        fila = d.get("fila_destino") or fila_do_texto(d.get("texto"), filas) or fila_do_texto(d.get("sugestao_claude"), filas)
        if not fila:
            sem_fila.append(d)
            continue
        d = dict(d, fila_destino=fila)
        if d["id"] in atual and (atual[d["id"]][0] != "Dados Operacionais" or not atual[d["id"]][0]):
            ja.append((d, atual[d["id"]]))
            continue
        if d["id"] in atual:
            d["fila_antes"] = atual[d["id"]][0]
        grupos.setdefault(fila, []).append(d)
    agora = datetime.now()
    pedidos, novos = [], []
    for d, (team, stage) in ja:
        novos.append(dict(d, quando=agora.isoformat(timespec="seconds"), executado_em=agora.isoformat(timespec="seconds"),
                          status=f"executado — já não estava em Dados Operacionais (fila atual: {team or '?'}, etapa {stage})"))
    # 13/11/2026: o Vigia corta a ação em 60 min (~50 atendimentos); pedidos de no máximo --lote atendimentos
    partes = []
    for fila, ds in sorted(grupos.items()):
        for k in range(0, len(ds), a.lote):
            partes.append((fila, ds[k:k + a.lote], k // a.lote + 1))
    for fila, ds, n in partes:
        pid = f"fila_{slug(fila)}_{agora:%Y%m%d_%H%M%S}" + (f"_p{n}" if len(ds) and n > 1 or len([x for x in partes if x[0] == fila]) > 1 else "")
        prots = [str(d.get("protocolo")) for d in ds if d.get("protocolo")]
        ped = {"id": pid, "acao": "atribuir_fila_atendimento", "protocolos": ",".join(prots), "fila": fila,
               "confirmar": not a.simular, "origem": "Plataforma - Reatribuir fila aprovado pelo Julio"}
        os.makedirs(a.out, exist_ok=True)
        json.dump(ped, open(os.path.join(a.out, pid + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        minutos = round(1.5 + 65 * len(prots) / 60)
        pedidos.append({"id": pid, "fila": fila, "qtd": len(prots), "estimativa_min": minutos})
        for d in ds:
            novos.append(dict(d, quando=agora.isoformat(timespec="seconds"), pedido_vigia=pid,
                              status=f"enviado ao Vigia — pedido {pid} ({'simulação' if a.simular else 'confirmar'})"))
    for d in sem_fila:
        novos.append(dict(d, quando=agora.isoformat(timespec="seconds"),
                          status="precisa de decisão — escolha a fila de destino na Plataforma"))
    if novos:
        dirs.extend(novos)
        gravar(a.dirs, dirs)
    print(json.dumps({"pedidos": pedidos, "ja_fora_da_fila": [d.get("protocolo") for d, _ in ja],
                      "sem_fila": [d.get("protocolo") for d in sem_fila]}, ensure_ascii=False))


def conferir(a):
    dirs = json.load(open(a.dirs, encoding="utf-8"))
    pend = [d for d in ultimos(dirs).values() if str(d.get("status", "")).startswith("enviado ao Vigia")]
    st = {}
    for p in glob.glob(os.path.join(a.status_dir, "**", "*.status.json"), recursive=True):
        st[os.path.basename(p)[:-len(".status.json")]] = json.load(open(p, encoding="utf-8"))
    agora = datetime.now().isoformat(timespec="seconds")
    novos, resumo = [], {"executado": 0, "falhou": 0, "aguardando": 0}
    for d in pend:
        s = st.get(d.get("pedido_vigia"))
        if not s or s.get("estado") == "executando":
            resumo["aguardando"] += 1
            continue
        res = s.get("resultado") or {}
        itens = res.get("itens") or ([res] if res.get("protocolo") else [])
        it = next((x for x in itens if str(x.get("protocolo")) == str(d.get("protocolo"))), None)
        if it and it.get("atribuido"):
            stt = f"executado — transferido para a fila {it.get('fila_escolhida') or d['fila_destino']} pelo Vigia"
            if it.get("aviso_tela"):
                stt += " (a PX avisou campos sem preencher, mas transferiu)"
        elif it and not it.get("erro") and "ja esta" in (it.get("observacao") or ""):
            stt = f"executado — já estava na fila {d['fila_destino']}"
        else:
            motivo = (it or {}).get("erro") or s.get("mensagem") or "sem resultado para este protocolo"
            stt = f"falhou — Vigia: {motivo}"[:400]
        resumo["falhou" if stt.startswith("falhou") else "executado"] += 1
        novos.append(dict(d, quando=agora, status=stt, executado_em=agora))
    if novos:
        dirs.extend(novos)
        gravar(a.dirs, dirs)
    print(json.dumps(resumo, ensure_ascii=False))


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("pedir"); p.add_argument("--dirs", required=True); p.add_argument("--out", required=True)
    p.add_argument("--simular", action="store_true")
    p.add_argument("--lote", type=int, default=40, help="máximo de atendimentos por pedido (o Vigia corta em 60 min)")
    p.add_argument("--filas", default="", help="filas_px.json (nomes exatos das filas da PX)")
    p.add_argument("--atual", default="", help="JSON {id: [fila, etapa]} com o estado atual (alternativa ao --cred)")
    p.add_argument("--cred", default="", help="credenciais.env: confere a fila atual de cada atendimento antes de pedir")
    c = sp.add_parser("conferir"); c.add_argument("--dirs", required=True); c.add_argument("--status-dir", required=True)
    a = ap.parse_args()
    pedir(a) if a.cmd == "pedir" else conferir(a)


if __name__ == "__main__":
    main()
