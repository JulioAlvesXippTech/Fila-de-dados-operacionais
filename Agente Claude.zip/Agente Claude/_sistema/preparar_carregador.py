#!/usr/bin/env python3
"""Prepara a ação "Carregador" de UM atendimento aprovado na Plataforma (SOMENTE LEITURA no Odoo).
Direcionamento do Julio (04/11/2026): "Carregador" funciona igual ao Maninha — aprovou, o Executor roda.

Monta em --out a pasta Carga SDI\\(#<protocolo>) <título> com:
  _Dados do contrato.txt, Arquivo Origem\\<bases mais recentes do atendimento>,
  Arquivo Modelo\\Modelo_Carga_SDI.xlsx (só no formato "sdi"; "pc" = PC Genérica canônica da skill, sem modelo) e
  Base Complementar\\<layout(s) complementar(es) escolhido(s) na Plataforma> (--complementar).
e imprime um JSON com o que gravar no computador. Depois o Executor roda o Carregador do Futuro (skill) SÓ nessa
pasta e grava o resultado em "Arquivo Final". Postar ao solicitante só quando o direcionamento tiver "postar": true
(caixa marcada na Plataforma — 04/11/2026); senão vale a regra de 07/10/2026 (não postar).

Uso: python3 preparar_carregador.py --cred credenciais.env --id 594235 --out <pasta> [--json res.json]
        [--formato sdi|pc] [--complementar <arq1> <arq2> ...]
Saída 2 = atendimento sem planilha/base anexada (ou só arquivos sem vidas).
"""
import argparse, base64, json, os, re, shutil, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import encaminhar as E
from agente_atendimentos import Odoo, load_env, contrato_info, contrato_pelo_texto

JULIO_UID = 275
MODELO = os.path.join(AQUI, "Modelo_Carga_SDI.xlsx")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--id", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--json", default="")
    ap.add_argument("--formato", choices=["sdi", "pc"], default="sdi")
    ap.add_argument("--complementar", nargs="*", default=[])
    a = ap.parse_args()
    for c in a.complementar:
        if not os.path.isfile(c):
            print(json.dumps({"id": a.id, "erro": f"layout complementar não encontrado: {os.path.basename(c)}"}, ensure_ascii=False))
            sys.exit(3)
    o = Odoo(load_env(a.cred))
    t = o.call("helpdesk.ticket", "read", [[a.id]], {"fields": ["number", "protocol_code", "name", "xipp_contract_id",
                                                               "xipp_requester_id", "ticket_type_id", "xipp_request_id", "description"]})[0]
    prot, titulo = t["protocol_code"], (t["name"] or "").strip()
    pasta = E.nome_pasta(prot, titulo)
    atts = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "=", a.id]]],
                  {"fields": ["id", "name", "create_date", "create_uid", "file_size"], "order": "create_date desc"})
    plan = [x for x in atts if E.PLANILHA.search(x["name"] or "") and "criticador de layout" not in E.norm(x["name"])
            and "arquivo_final" not in E.norm(x["name"])]
    if not plan:   # 13/11/2026: operadora que só manda PDF (ex.: Morumbi Sul, Vida) -> o PDF é a base
        plan = [x for x in atts if re.search(r"\.pdf$", x["name"] or "", re.I)]
    do_solic = [x for x in plan if not (x["create_uid"] and x["create_uid"][0] == JULIO_UID)]
    # Carregador: todas as planilhas das últimas 24h antes da mais recente (ex.: PC + fatura enviadas em horários diferentes)
    from datetime import datetime as _dt
    cand = do_solic or plan
    if cand:
        topo = _dt.strptime(cand[0]["create_date"], "%Y-%m-%d %H:%M:%S")
        escolhidos = [x for x in cand if (topo - _dt.strptime(x["create_date"], "%Y-%m-%d %H:%M:%S")).total_seconds() <= 86400]
    else:
        escolhidos = []
    FMT = {"sdi": "Layout SDI (Modelo_Carga_SDI.xlsx)", "pc": "PC Genérica (layout canônico da skill o-carregador-do-futuro)"}
    res = {"id": a.id, "atendimento": t["number"], "protocolo": prot, "pasta": pasta, "formato": a.formato,
           "arquivos": [], "complementar": [], "gravar": []}
    if not escolhidos:
        res["erro"] = "atendimento sem planilha/base anexada"
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(2)
    base = os.path.join(a.out, "Carga SDI", pasta)
    orig = os.path.join(base, "Arquivo Origem")
    os.makedirs(orig, exist_ok=True)
    separacao = []
    for x in escolhidos:
        d = o.call("ir.attachment", "read", [[x["id"]]], {"fields": ["datas"]})[0].get("datas")
        if not d:
            continue
        dados_b = base64.b64decode(d)
        nome = E.nome_arquivo(x["name"])
        if os.path.exists(os.path.join(orig, nome)):  # mesmo nome enviado de novo: guarda as duas versões
            r, ext = os.path.splitext(nome)
            nome = f"{r} ({x['create_date'][:16].replace(':', '').replace(' ', '_')}){ext}"
        open(os.path.join(orig, nome), "wb").write(dados_b)
        res["arquivos"].append(x["name"])
        separacao.append((x["name"], "base"))
    if not res["arquivos"]:
        res["erro"] = "nenhuma planilha com vidas entre os anexos mais recentes"
        print(json.dumps(res, ensure_ascii=False))
        sys.exit(2)
    if a.complementar:
        comp = os.path.join(base, "Base Complementar")
        os.makedirs(comp, exist_ok=True)
        for c in a.complementar:
            shutil.copy2(c, os.path.join(comp, os.path.basename(c)))
            res["complementar"].append(os.path.basename(c))
    if a.formato == "sdi" and os.path.exists(MODELO):
        mod = os.path.join(base, "Arquivo Modelo")
        os.makedirs(mod, exist_ok=True)
        shutil.copy2(MODELO, os.path.join(mod, "Modelo_Carga_SDI.xlsx"))
    ci = contrato_info(o, t["xipp_contract_id"][0]) if t["xipp_contract_id"] else contrato_pelo_texto(o, t)
    res["contrato_status"] = (ci or {}).get("status") if isinstance(ci, dict) else None
    open(os.path.join(base, "_Dados do contrato.txt"), "w", encoding="utf-8-sig", newline="\r\n").write(
        E.texto_contrato(t["number"], titulo, ci) + "\nCARREGADOR (direcionamento aprovado na Plataforma) - arquivos baixados do atendimento:\n"
        + "".join(f"  - {n} -> Arquivo Origem\n" for n, tp in separacao if tp == "base")
        + f"FORMATO DO ARQUIVO FINAL (escolhido na Plataforma): {FMT[a.formato]}\n"
        + "".join(f"  - {n} -> Base Complementar (layout complementar enviado pela Plataforma)\n" for n in res["complementar"]))
    for raiz, _, fs in os.walk(base):
        for f in fs:
            p = os.path.join(raiz, f)
            res["gravar"].append({"local": p, "relativo": os.path.relpath(p, a.out).replace("/", "\\")})
    if a.json:
        json.dump(res, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
