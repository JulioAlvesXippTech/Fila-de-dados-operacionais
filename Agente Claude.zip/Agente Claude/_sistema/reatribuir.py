#!/usr/bin/env python3
"""Reatribui ao Vitor Matsuoka (fila Dados Operacionais) os pedidos de CARGA sem arquivo anexado.

Ajuste do Julio em 08/10/2026: só reatribui se o benefício NÃO for Vida (contrato vinculado com benefício
"Vida"; sem contrato, título contendo "Vida") — cargas de Vida sem arquivo permanecem com o responsável atual.

Regra confirmada pelo Julio Alves no chat em 07/10/2026, com confirmação explícita de escrita em PRODUÇÃO
e autorização para rodar automaticamente em toda execução do Agente de Atendimentos.

ÚNICA escrita permitida neste projeto: model helpdesk.ticket, campos user_id e team_id.
Nunca unlink. Backup do estado anterior gravado ANTES de qualquer write.

Uso:
  python3 reatribuir.py --cred credenciais.env --out <pasta> [--simular]
Gera em <pasta>:
  backup_reatribuicao_AAAAMMDD_HHMM.json  (estado antes, ids, nota de confirmação, resultado)
  reatribuicao.json                       (resumo para a notificação)
"""
import argparse, json, os, re, sys, unicodedata
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from agente_atendimentos import Odoo, load_env, BRT, dominio_filtro

VITOR = "Vitor Matsuoka"
FILA = "Dados Operacionais"
CAMPOS_PERMITIDOS = {"user_id", "team_id"}
NOTA = ("Julio Alves confirmou no chat em 07/10/2026 (produção, plataforma.xipp.com.br): pedidos de carga sem arquivo "
        "-> Fila Dados Operacionais, Atribuído a Vitor Matsuoka; regra automática em toda execução.")
IMG = re.compile(r"^image\d*(\.\w+)?$|\.(png|jpe?g|gif|bmp)$", re.I)


def norm(s):
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()


def eh_carga(t):
    s = norm(" ".join([t["name"] or "", t["ticket_type_id"][1] if t["ticket_type_id"] else "",
                       t["xipp_request_id"][1] if t["xipp_request_id"] else ""]))
    return "carga" in s or "carregar" in s


def eh_vida(t, beneficios):
    """True se o benefício do atendimento for Vida (contrato vinculado; sem contrato, olha o título)."""
    if t.get("xipp_contract_id"):
        b = beneficios.get(t["xipp_contract_id"][0], "")
        if b:
            return re.search(r"\bvida\b", norm(b)) is not None
    return re.search(r"\bvida\b", norm(t["name"] or "")) is not None


def write_confirmado(o, ids, valores):
    if set(valores) - CAMPOS_PERMITIDOS:
        sys.exit("Campo não permitido")
    if o.uid is None:
        o.call("res.users", "search_count", [[["id", "=", -1]]])  # autentica
    return o._post("/jsonrpc", {"service": "object", "method": "execute_kw",
                                "args": [o.db, o.uid, o.key, "helpdesk.ticket", "write", [ids, valores]]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cred", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--simular", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    o = Odoo(load_env(a.cred))
    vitor = o.call("res.users", "search_read", [[["name", "=", VITOR]]], {"fields": ["id"], "limit": 1})
    fila = o.call("helpdesk.ticket.team", "search_read", [[["name", "=", FILA]]], {"fields": ["id"], "limit": 1})
    if not vitor or not fila:
        sys.exit("Usuário Vitor Matsuoka ou fila Dados Operacionais não encontrados")
    vid, fid = vitor[0]["id"], fila[0]["id"]
    campos = ["id", "number", "protocol_code", "name", "user_id", "team_id", "stage_id", "ticket_type_id", "xipp_request_id", "xipp_contract_id"]
    ts = o.call("helpdesk.ticket", "search_read", [dominio_filtro()], {"fields": campos, "limit": 2000})
    ids = [t["id"] for t in ts]
    atts = o.call("ir.attachment", "search_read", [[["res_model", "=", "helpdesk.ticket"], ["res_id", "in", ids]]],
                  {"fields": ["res_id", "name"], "limit": 100000}) if ids else []
    com_arquivo = {x["res_id"] for x in atts if not IMG.search(x["name"] or "")}
    cids = list({t["xipp_contract_id"][0] for t in ts if t.get("xipp_contract_id")})
    beneficios = {c["id"]: (c["benefit_id"][1] if c["benefit_id"] else "")
                  for c in (o.call("xipp.contract", "read", [cids], {"fields": ["benefit_id"]}) if cids else [])}
    vida_mantidos = [t for t in ts if t["id"] not in com_arquivo and eh_carga(t) and eh_vida(t, beneficios)]
    alvo = [t for t in ts if t["id"] not in com_arquivo and eh_carga(t) and not eh_vida(t, beneficios)
            and not (t["user_id"] and t["user_id"][0] == vid and t["team_id"] and t["team_id"][0] == fid)]
    agora = datetime.now(BRT)
    resumo = {"execucao": agora.strftime("%d/%m/%Y %H:%M"), "simulacao": a.simular, "reatribuidos": [], "falhas": [],
              "vida_mantidos": [{"numero": t["number"], "protocolo": t["protocol_code"], "titulo": (t["name"] or "").strip(),
                                 "responsavel": t["user_id"][1] if t["user_id"] else "Sem responsável"} for t in vida_mantidos]}
    if not alvo:
        json.dump(resumo, open(os.path.join(a.out, "reatribuicao.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(json.dumps({"reatribuidos": 0, "vida_mantidos": len(vida_mantidos)}))
        return
    backup = {"quando": agora.isoformat(), "ambiente": "PROD_18", "model": "helpdesk.ticket",
              "valores": {"user_id": vid, "team_id": fid}, "confirmation_note": NOTA,
              "before": [{k: t[k] for k in campos} for t in alvo]}
    bpath = os.path.join(a.out, f"backup_reatribuicao_{agora.strftime('%Y%m%d_%H%M')}.json")
    json.dump(backup, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    resumo["backup_file"] = os.path.basename(bpath)
    for t in alvo:
        item = {"numero": t["number"], "protocolo": t["protocol_code"], "titulo": (t["name"] or "").strip(),
                "antes": t["user_id"][1] if t["user_id"] else "Sem responsável"}
        if a.simular:
            resumo["reatribuidos"].append(item)
            continue
        try:
            write_confirmado(o, [t["id"]], {"user_id": vid, "team_id": fid})
            depois = o.call("helpdesk.ticket", "read", [[t["id"]]], {"fields": ["user_id", "team_id"]})[0]
            ok = depois["user_id"] and depois["user_id"][0] == vid and depois["team_id"] and depois["team_id"][0] == fid
            (resumo["reatribuidos"] if ok else resumo["falhas"]).append(dict(item, depois=depois["user_id"][1] if depois["user_id"] else ""))
        except SystemExit as e:
            resumo["falhas"].append(dict(item, erro=str(e)[:300]))
    backup["resultado"] = resumo
    json.dump(backup, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(resumo, open(os.path.join(a.out, "reatribuicao.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"reatribuidos": len(resumo["reatribuidos"]), "falhas": len(resumo["falhas"]), "vida_mantidos": len(vida_mantidos), "backup": resumo["backup_file"]}))


if __name__ == "__main__":
    main()
