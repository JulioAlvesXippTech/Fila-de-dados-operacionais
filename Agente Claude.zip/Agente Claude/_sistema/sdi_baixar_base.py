#!/usr/bin/env python3
"""
sdi_baixar_base.py - baixa a "Base de beneficiarios" do SDI pela Plataforma Xipp (PX).

Caminho automatizado (mapeado a partir da gravacao de tela do Julio, 27/10/2026):
  1. Login em plataforma.xipp.com.br (e-mail + senha) -> /odoo
  2. /odoo/action-7906  (menu "SDI - Movimentacao Cadastral")
  3. Card "Pesquisa de Beneficiario" -> aba "Beneficiario"
  4. Filtros: Grupo Financeiro + Contrato (opcao "Odonto - Odonto Empresas - 511312") -> Pesquisar
  5. "Exportar Base de Beneficiarios" -> janela "Exportar Relatorio" -> Enviar
  6. "Relatorio solicitado com sucesso!" -> "Ir para Emissao de Relatorios" (aba "Meus Relatorios")
  7. Tabela: Layout | Nome do arquivo | Grupo Financeiro | Solicitado por | Data da Solicitacao |
     Data da Emissao | Status | Erro | Acoes  -> espera "Emitido com Sucesso" e clica no icone de download
  8. Salva em <pasta do cliente>\\Arquivo Origem\\RELATORIO_BENEFICIARIOS_<data>.xlsx

Instalacao (uma vez):
    pip install playwright openpyxl
    playwright install chromium

Primeira execucao (login manual - serve para senha ou "Login Xipp Seguros"; a sessao fica salva):
    python sdi_baixar_base.py --login

Uso normal (reaproveita a sessao salva; roda sem janela):
    python sdi_baixar_base.py --grupo "Grupo Caixa CNP" --contrato 511312 ^
        --pasta "C:\\Users\\JulioCesardaSilvaAlv\\Downloads\\Claude\\Carga SDI\\(#488167) Atualizacao de base - Grupo caixa - Odonto Empresas"

A PX exige codigo de dois fatores (Authenticator). Por isso a primeira execucao deve ser --login, digitando
o codigo e marcando "Nao perguntar novamente neste dispositivo": a sessao salva nao pede o codigo de novo.
Se a sessao expirar, o script tenta entrar com SDI_USUARIO e SDI_SENHA do credenciais.env e, se existir
SDI_TOTP_SECRET (chave do Authenticator, opcional; requer pip install pyotp), gera o codigo sozinho.

Opcoes:
    --visivel      abre o navegador para acompanhar
    --discover     salva capturas de tela, lista de botoes de cada etapa e chamadas de rede do SDI
                   (sem tokens) em .\\sdi_debug - use se o SDI mudar de tela e o script falhar
    --solicitante  nome na coluna "Solicitado por" (padrao: Julio Alves)
    --timeout      segundos esperando o relatorio ficar "Emitido com Sucesso" (padrao 600)

Seguranca: nada de senha/token e impresso. O arquivo .sdi_sessao\\state.json guarda cookies da sua
conta: nao compartilhe essa pasta.
"""
import argparse
import json
import re
import sys
import time
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
except ImportError as _e:
    sys.exit(
        f"Nao consegui importar o Playwright. Erro real: {_e}\n"
        f"Python em uso: {sys.executable} ({sys.version.split()[0]})\n"
        "Instale NESTE mesmo Python:\n"
        f'    "{sys.executable}" -m pip install --upgrade pip playwright openpyxl\n'
        f'    "{sys.executable}" -m playwright install chromium\n'
        "Se o erro citar greenlet ou falhar a instalacao, use Python 3.12 ou 3.13 (o 3.14 ainda pode nao ter pacote pronto)."
    )

PX_URL_PADRAO = "https://plataforma.xipp.com.br"
SDI_PATH = "/odoo/action-7906"          # menu 'SDI - Movimentacao Cadastral'
SDI_HOST = "app.sdi.xipptech.com.br"
SDI_API = "platform.xipptech.com.br/api/sdi"
AQUI = Path(__file__).resolve().parent
SESSAO_DIR = AQUI / ".sdi_sessao"
STATE = SESSAO_DIR / "state.json"
DEBUG_DIR = AQUI / "sdi_debug"


# ----------------------------------------------------------------- utilidades
def sem_acento(s):
    return "".join(c for c in unicodedata.normalize("NFD", s or "") if unicodedata.category(c) != "Mn").lower()


def rx(texto):
    """Regex tolerante a acento e caixa: rx('Emissão de Relatórios') casa com 'emissao de relatorios'."""
    base = sem_acento(texto)
    mapa = {"a": "[aáàâãä]", "e": "[eéèêë]", "i": "[iíìî]", "o": "[oóòôõ]", "u": "[uúùû]", "c": "[cç]"}
    return re.compile("".join(mapa.get(ch, re.escape(ch)) for ch in base), re.I)


def ler_env(caminho):
    d = {}
    if caminho and Path(caminho).exists():
        for linha in Path(caminho).read_text(encoding="utf-8-sig").splitlines():
            linha = linha.strip()
            if linha and not linha.startswith("#") and "=" in linha:
                k, v = linha.split("=", 1)
                d[k.strip()] = v.strip().strip('"').strip("'")
    return d


class Debug:
    def __init__(self, ativo):
        self.ativo, self.n, self.chamadas = ativo, 0, []
        if ativo:
            DEBUG_DIR.mkdir(exist_ok=True)

    def passo(self, pg, nome):
        print(f"  - {nome}")
        if not self.ativo:
            return
        self.n += 1
        base = DEBUG_DIR / f"{self.n:02d}_{re.sub(r'[^a-z0-9]+', '_', sem_acento(nome))[:40]}"
        try:
            pg.screenshot(path=str(base) + ".png", full_page=True)
            itens = []
            for fr in pg.frames:
                try:
                    itens.append({"frame": fr.url, "elementos": fr.evaluate("""() =>
                        [...document.querySelectorAll('button,a,input,label,th,.v-list-item,[role=button],[role=option],[role=tab]')]
                        .filter(e => e.offsetParent !== null)
                        .map(e => e.tagName + ' | ' + (e.innerText || e.placeholder || e.getAttribute('aria-label') || '').trim().slice(0, 80))
                        .slice(0, 200)""")})
                except Exception:
                    pass
            Path(str(base) + ".json").write_text(json.dumps(itens, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:                       # debug nunca derruba a execucao
            print("    (debug falhou:", e, ")")

    def rede(self, req):
        if SDI_API in req.url:
            self.chamadas.append({"metodo": req.method, "url": req.url, "corpo": (req.post_data or "")[:500]})

    def salvar(self):
        if self.ativo and self.chamadas:
            (DEBUG_DIR / "chamadas_api_sdi.json").write_text(
                json.dumps(self.chamadas, ensure_ascii=False, indent=1), encoding="utf-8")


def tela_sdi(pg, espera=120):
    """O SDI pode estar num iframe (app.sdi.xipptech.com.br) ou direto na pagina da PX. Espera ate carregar
    (a tela fica em branco por alguns segundos) e devolve o frame/pagina que mostra o card 'Pesquisa de Beneficiario'
    ou, dentro do SDI, a aba 'Beneficiario'/'Meus Relatorios'."""
    marcador = rx("Pesquisa de Beneficiário")
    fim = time.time() + espera
    while time.time() < fim:
        for fr in pg.frames:
            try:
                if fr.get_by_text(marcador).count():
                    return fr
            except Exception:
                pass
        time.sleep(1)
    raise RuntimeError("A tela do SDI nao carregou (nao apareceu 'Pesquisa de Beneficiario'). "
                       "Sessao expirada ou site lento: rode de novo ou use --discover.")


# ----------------------------------------------------------------- login
def sessao_pede_login(pg):
    return "/web/login" in pg.url or pg.locator("input[name=login]").count() > 0


def abrir_sdi(pg, px_url, env):
    pg.goto(px_url + SDI_PATH, wait_until="domcontentloaded", timeout=90000)
    time.sleep(4)
    if sessao_pede_login(pg) or pg.get_by_text(rx("Entrar na Plataforma")).count():
        usuario, senha = env.get("SDI_USUARIO"), env.get("SDI_SENHA")
        if not (usuario and senha):
            raise RuntimeError("Sessao expirada. Rode  python sdi_baixar_base.py --login  "
                               "(ou preencha SDI_USUARIO e SDI_SENHA no credenciais.env).")
        pg.goto(px_url + "/web/login", wait_until="domcontentloaded")
        pg.fill("input[name=login]", usuario)
        pg.fill("input[name=password]", senha)
        pg.click("button[type=submit]")
        pg.wait_for_load_state("networkidle", timeout=60000)
        if "/totp" in pg.url:                          # autenticacao de dois fatores (app Authenticator)
            passar_2fa(pg, env)
        pg.goto(px_url + SDI_PATH, wait_until="domcontentloaded", timeout=90000)
        time.sleep(4)
        if sessao_pede_login(pg):
            raise RuntimeError("Login por e-mail/senha nao funcionou (senha incorreta ou 2FA). Rode --login.")


def passar_2fa(pg, env):
    """A PX pede o codigo de 6 digitos do Authenticator. Gera o codigo se houver SDI_TOTP_SECRET no
    credenciais.env (precisa de: pip install pyotp). Marca 'Nao perguntar novamente neste dispositivo'
    para a sessao salva nao pedir o codigo de novo."""
    segredo = env.get("SDI_TOTP_SECRET")
    if not segredo:
        raise RuntimeError("A PX pediu o codigo de dois fatores. Rode  python sdi_baixar_base.py --login , digite o codigo "
                           "marcando 'Nao perguntar novamente neste dispositivo' - a sessao fica salva e nao pede mais. "
                           "(Opcional: SDI_TOTP_SECRET no credenciais.env para o script gerar o codigo sozinho.)")
    try:
        import pyotp
    except ImportError:
        raise RuntimeError("Para gerar o codigo de dois fatores instale:  pip install pyotp")
    codigo = pyotp.TOTP(segredo.replace(" ", "")).now()
    campo = pg.locator("input[name=totp_token], input[autocomplete=one-time-code], input[type=text]").first
    campo.fill(codigo)
    caixa = pg.locator("input[type=checkbox]").first
    try:
        if caixa.count() and not caixa.is_checked():
            caixa.check()
    except Exception:
        pass
    pg.locator("button[type=submit]").first.click()
    pg.wait_for_load_state("networkidle", timeout=60000)
    if "/totp" in pg.url:
        raise RuntimeError("O codigo de dois fatores foi recusado (SDI_TOTP_SECRET incorreto ou relogio do PC fora de hora).")


def login_manual(px_url):
    SESSAO_DIR.mkdir(exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch(headless=False)
        c = b.new_context(viewport={"width": 1400, "height": 900})
        pg = c.new_page()
        pg.goto(px_url + "/web/login")
        print("\nFaca o login na janela que abriu (e-mail e senha ou 'Login Xipp Seguros').")
        print("Se pedir o codigo de dois fatores, digite e MARQUE 'Nao perguntar novamente neste dispositivo'.")
        print("Quando aparecer a tela inicial da Plataforma, volte aqui e aperte ENTER.")
        input()
        c.storage_state(path=str(STATE))
        b.close()
    print("Sessao salva em", STATE)


# ----------------------------------------------------------------- etapas do SDI
def esperar(pg, seg=1.5):
    try:
        pg.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        pass
    time.sleep(seg)


def clicar(tela, texto, desc, espera=60000):
    """Clica no elemento visivel cujo texto casa com `texto` (tolerante a acento/caixa)."""
    padrao = rx(texto) if isinstance(texto, str) else texto
    fim = time.time() + espera / 1000
    while time.time() < fim:
        for seletor in ("button, a, [role=button], [role=tab], .v-tab, .v-btn, .v-list-item",
                        ".v-card, div[class*=card], div[class*=item]"):
            cand = tela.locator(seletor).filter(has_text=padrao)
            n = cand.count()
            for i in range(n - 1, -1, -1):          # do mais interno para o mais externo
                el = cand.nth(i)
                try:
                    if el.is_visible():
                        el.click()
                        return
                except Exception:
                    pass
        txt = tela.get_by_text(padrao)
        for i in range(txt.count() - 1, -1, -1):
            try:
                if txt.nth(i).is_visible():
                    txt.nth(i).click()
                    return
            except Exception:
                pass
        time.sleep(1)
    raise RuntimeError(f"Nao achei '{desc}' na tela do SDI. Rode com --discover para ver o que aparece.")


def escolher_opcao(pg, tela, rotulo, texto, valor_rx, desc):
    """Campo de selecao (Vuetify): abre pelo rotulo, digita para filtrar (se houver busca) e clica na opcao."""
    campo = tela.locator(".v-input, .v-select, .v-autocomplete, [class*=select]").filter(has_text=rx(rotulo)).first
    try:
        campo.wait_for(state="visible", timeout=20000)
    except PWTimeout:
        raise RuntimeError(f"Nao achei o campo '{rotulo}'. Rode com --discover.")
    campo.click()
    time.sleep(0.8)
    try:                                              # se for autocomplete, digita para filtrar
        entrada = campo.locator("input[type=text], input:not([type])").first
        if entrada.is_visible():
            entrada.fill("")
            entrada.type(texto, delay=50)
            time.sleep(1.0)
    except Exception:
        pass
    opcoes = tela.locator(".v-menu__content .v-list-item, [role=option], .v-list-item").filter(has_text=valor_rx)
    try:
        opcoes.first.wait_for(state="visible", timeout=20000)
    except PWTimeout:
        raise RuntimeError(f"Nao apareceu a opcao de {desc}. Confira se o nome/numero existe no SDI.")
    opcoes.first.click()
    time.sleep(0.8)
    pg.keyboard.press("Escape")                       # fecha o menu (campos multiplos ficam abertos)
    time.sleep(0.5)


def exportar_base(pg, tela, dbg, grupo, contrato):
    dbg.passo(pg, "tela inicial do SDI")
    clicar(tela, "Pesquisa de Beneficiário", "Pesquisa de Beneficiário")
    esperar(pg, 2)
    dbg.passo(pg, "pesquisa de beneficiario")
    escolher_opcao(pg, tela, "Grupo Financeiro", grupo, rx(grupo), f"Grupo Financeiro '{grupo}'")
    esperar(pg, 1.5)
    c = re.compile(rf"(?<!\d){re.escape(str(contrato))}(?!\d)")
    escolher_opcao(pg, tela, "Contrato", str(contrato), c, f"Contrato {contrato}")
    dbg.passo(pg, "filtros preenchidos")
    clicar(tela, re.compile(r"^\s*pesquisar\s*$", re.I), "Pesquisar")
    esperar(pg, 3)
    tela.locator("table tbody tr").first.wait_for(state="visible", timeout=90000)
    dbg.passo(pg, "resultado da pesquisa")
    clicar(tela, "Exportar Base de Beneficiários", "Exportar Base de Beneficiários")
    esperar(pg, 1.5)
    dbg.passo(pg, "janela Exportar Relatorio")
    clicar(tela, re.compile(r"^\s*enviar\s*$", re.I), "Enviar")
    tela.get_by_text(rx("Relatório solicitado com sucesso")).first.wait_for(state="visible", timeout=60000)
    dbg.passo(pg, "relatorio solicitado com sucesso")
    clicar(tela, "Ir para Emissão de Relatórios", "Ir para Emissão de Relatórios")
    esperar(pg, 2)
    dbg.passo(pg, "meus relatorios")


def parse_dt(s):
    try:
        return datetime.strptime(s.strip(), "%d/%m/%Y %H:%M")
    except Exception:
        return datetime.min


def linhas_relatorios(tela):
    """Colunas: Layout | Nome do arquivo | Grupo Financeiro | Solicitado por | Data da Solicitacao |
    Data da Emissao | Status | Erro | Acoes."""
    saida = []
    rows = tela.locator("table tbody tr")
    for i in range(rows.count()):
        tr = rows.nth(i)
        cel = [" ".join(c.split()) for c in tr.locator("td").all_inner_texts()]
        if len(cel) >= 7:
            saida.append({"layout": cel[0], "arquivo": cel[1], "grupo": cel[2], "solicitante": cel[3],
                          "solicitacao": cel[4], "emissao": cel[5], "status": cel[6], "tr": tr})
    return saida


def baixar_relatorio(pg, tela, dbg, grupo, solicitante, inicio, saida_dir, timeout_s):
    limite = inicio - timedelta(minutes=2)            # tolerancia de relogio
    fim = time.time() + timeout_s
    alvo = None
    while time.time() < fim:
        cand = [l for l in linhas_relatorios(tela)
                if sem_acento(grupo) in sem_acento(l["grupo"])
                and sem_acento(solicitante) in sem_acento(l["solicitante"])
                and "beneficiario" in sem_acento(l["layout"] + l["arquivo"])
                and parse_dt(l["solicitacao"]) >= limite.replace(second=0, microsecond=0)]
        if cand:
            alvo = max(cand, key=lambda l: parse_dt(l["solicitacao"]))
            st = sem_acento(alvo["status"])
            if "sucesso" in st:
                break
            if "erro" in st or "falh" in st:
                raise RuntimeError(f"O SDI marcou o relatorio com erro: {alvo['status']}")
        try:                                           # botao 'Atualizar' da aba Meus Relatorios
            clicar(tela, "Atualizar", "Atualizar", espera=2000)
        except Exception:
            pass
        time.sleep(8)
    if not alvo or "sucesso" not in sem_acento(alvo["status"]):
        dbg.passo(pg, "timeout esperando relatorio")
        raise RuntimeError("O relatorio nao ficou 'Emitido com Sucesso' no tempo limite. Veja a aba Meus Relatorios.")
    print(f"  Relatorio: {alvo['arquivo']} | {alvo['grupo']} | {alvo['solicitante']} | {alvo['solicitacao']} | {alvo['status']}")
    dbg.passo(pg, "relatorio emitido")
    botao = alvo["tr"].locator("td").last.locator("button, a, i, svg, [role=button]").first
    with pg.expect_download(timeout=120000) as d:
        botao.click()
    dl = d.value
    nome = dl.suggested_filename or alvo["arquivo"] or f"RELATORIO_BENEFICIARIOS_{datetime.now():%Y%m%d%H%M%S}.xlsx"
    saida_dir.mkdir(parents=True, exist_ok=True)
    destino = saida_dir / nome
    dl.save_as(str(destino))
    return destino


def validar(destino, contrato):
    try:
        import openpyxl
        wb = openpyxl.load_workbook(destino, read_only=True)
        ws = wb.active
        cab = [str(c) for c in next(ws.iter_rows(values_only=True, max_row=1))]
        print("  Colunas:", ", ".join(cab[:8]), "...")
        total = 0
        contratos = set()
        ic = cab.index("Contrato") if "Contrato" in cab else None
        for r in ws.iter_rows(min_row=2, values_only=True):
            total += 1
            if ic is not None and r[ic] is not None:
                contratos.add(str(r[ic]).strip())
        print(f"  Linhas de beneficiarios: {total}")
        if contratos and contratos != {str(contrato)}:
            print(f"  ATENCAO: contratos no arquivo = {sorted(contratos)} (pedido: {contrato}).")
    except ImportError:
        print("  (instale openpyxl para validar o conteudo: pip install openpyxl)")
    except Exception as e:
        print("  (nao consegui validar o arquivo:", e, ")")


# ----------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser(description="Baixa a base de beneficiarios do SDI pela PX.")
    ap.add_argument("--login", action="store_true", help="abre o navegador para voce logar e salva a sessao")
    ap.add_argument("--grupo", help='Grupo financeiro, ex.: "Grupo Caixa CNP"')
    ap.add_argument("--contrato", help="Numero do contrato/apolice, ex.: 511312")
    ap.add_argument("--pasta", help="Pasta do cliente (a base vai para <pasta>\\Arquivo Origem)")
    ap.add_argument("--saida", help="Pasta de destino (substitui --pasta)")
    ap.add_argument("--solicitante", default="Julio Alves")
    ap.add_argument("--cred", default=str(AQUI / "credenciais.env"))
    ap.add_argument("--visivel", action="store_true")
    ap.add_argument("--discover", action="store_true")
    ap.add_argument("--timeout", type=int, default=600)
    a = ap.parse_args()

    env = ler_env(a.cred)
    px_url = env.get("ODOO_URL", PX_URL_PADRAO).rstrip("/")
    if a.login:
        login_manual(px_url)
        return
    if not (a.grupo and a.contrato and (a.pasta or a.saida)):
        ap.error("informe --grupo, --contrato e --pasta (ou --saida)")
    saida = Path(a.saida) if a.saida else Path(a.pasta) / "Arquivo Origem"

    dbg = Debug(a.discover)
    inicio = datetime.now()
    print(f"Baixando base do SDI: grupo='{a.grupo}' contrato={a.contrato}")
    with sync_playwright() as p:
        b = p.chromium.launch(headless=not a.visivel)
        kw = {"viewport": {"width": 1600, "height": 1000}, "accept_downloads": True, "locale": "pt-BR"}
        if STATE.exists():
            kw["storage_state"] = str(STATE)
        c = b.new_context(**kw)
        c.on("request", dbg.rede)
        pg = c.new_page()
        try:
            abrir_sdi(pg, px_url, env)
            tela = tela_sdi(pg)
            exportar_base(pg, tela, dbg, a.grupo, a.contrato)
            tela = tela_sdi(pg)
            destino = baixar_relatorio(pg, tela, dbg, a.grupo, a.solicitante, inicio, saida, a.timeout)
            SESSAO_DIR.mkdir(exist_ok=True)
            c.storage_state(path=str(STATE))           # renova a sessao salva
            print("\nOK. Base salva em:", destino)
            validar(destino, a.contrato)
        except Exception as e:
            dbg.passo(pg, "erro")
            print("\nERRO:", e)
            sys.exit(1)
        finally:
            dbg.salvar()
            b.close()


if __name__ == "__main__":
    main()
