# -*- coding: utf-8 -*-
"""
px_atribuir_fila.py - transfere um atendimento da PX para outra fila (botao "Atribuir para").

Caminho automatizado (mapeado do video do Julio, 11/11/2026):
  1. Login na PX -> app "Automacao Operacional" -> menu "Paineis" -> "Atendimentos Dados Operacionais e Dados Sinistro"
  2. Clica no card "Dados Operacionais - (Atendimentos Abertos)"; se o protocolo nao estiver la,
     volta e tenta o card "Dados de Sinistro - (Atendimentos Abertos)"
  3. Pesquisa o protocolo na lista e abre o atendimento (confere o "(#protocolo)" no topo)
  4. "Atribuir para" -> janela: "Fila de Atendimento" (obrigatorio) e "Usuario" (opcional)
  5. "Confirmar" -> abre o atendimento numa pagina nova e confere que "Fila de Atendimento" mudou

ALTERA DADOS NA PX. Por seguranca:
  - Sem --confirmar o script so SIMULA: abre a janela, escolhe a fila, e clica em Cancelar.
  - Escolhe a fila so quando o nome bate exatamente (sem acento/caixa) com uma opcao; se houver
    duvida (ex.: "Faturamento" x "Faturamento Small"), para e lista as opcoes vistas.
  - Se o atendimento ja estiver na fila pedida, nao faz nada.
  - Depois de Confirmar, sempre rele o atendimento numa pagina nova e decide pela fila de verdade.
    O aviso "Campos invalidos: Assunto, Solicitacao" NAO impede a troca (a PX transfere mesmo assim):
    vira "aviso_tela" no resultado, e "atribuido" depende so da fila relida.

Saida: uma linha  RESULTADO_JSON: {...}  (ASCII). Erro: "ERRO: <motivo>" e codigo 1.

Uso (manual):
    python px_atribuir_fila.py --protocolo 609487 --fila "Faturamento" [--usuario "Nome"] [--confirmar]
    python px_atribuir_fila.py --protocolos "609486,609484,609483" --fila "Faturamento" --confirmar
    (varios protocolos: entra na PX e carrega o painel uma vez so; depois vai direto na lista do card)
Opcoes: --painel operacionais|sinistro|ambos (padrao ambos), --visivel, --discover
"""
import argparse
import json
import re
import sys
import time
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sdi_baixar_base import (sync_playwright, PWTimeout, PX_URL_PADRAO, STATE, SESSAO_DIR, AQUI,  # noqa: E402
                             Debug, rx, ler_env, sessao_pede_login, passar_2fa, esperar)

CARDS = {
    "operacionais": re.compile(r"Dados Operacionais\s*-\s*\(?\s*Atendimentos Abertos", re.I),
    "sinistro": re.compile(r"Dados de Sinistro\s*-\s*\(?\s*Atendimentos Abertos", re.I),
}
RE_ITEM_PAINEL = re.compile(r"Atendimentos Dados Operacionais e Dados (de )?Sinistro|Painel Atendimentos", re.I)
RE_PAINEL = re.compile(r"Painel", re.I)          # trilha (breadcrumb) de volta ao painel
RE_ERRO = re.compile(r"Campos inv[aá]lidos|inv[aá]lid|erro|n[aã]o [eé] poss[ií]vel|obrigat[oó]ri|"
                     r"acesso negado|validation|access", re.I)
RE_IGNORAR_OPCAO = re.compile(r"^(pesquisar mais|search more|criar|create|criar e editar|start typing|comece a digitar)",
                              re.I)


def norm(s):
    s = "".join(c for c in unicodedata.normalize("NFD", s or "") if unicodedata.category(c) != "Mn")
    return " ".join(s.lower().split())


# ----------------------------------------------------------------- login / navegacao
def abrir_px(pg, px_url, env):
    """Abre a PX (tela inicial) e faz login se a sessao salva tiver expirado."""
    pg.goto(px_url + "/odoo", wait_until="domcontentloaded", timeout=90000)
    time.sleep(3)
    if sessao_pede_login(pg) or pg.get_by_text(rx("Entrar na Plataforma")).count():
        usuario, senha = env.get("SDI_USUARIO"), env.get("SDI_SENHA")
        if not (usuario and senha):
            raise RuntimeError("Sessao expirada. Rode  python sdi_baixar_base.py --login  "
                               "(ou preencha SDI_USUARIO e SDI_SENHA no credenciais.env).")
        pg.goto(px_url + "/web/login", wait_until="domcontentloaded")
        pg.fill("input[name=login]", usuario)
        pg.fill("input[name=password]", senha)
        pg.click("button[type=submit]")
        pg.wait_for_load_state("networkidle", timeout=60000)
        if "/totp" in pg.url:
            passar_2fa(pg, env)
        pg.goto(px_url + "/odoo", wait_until="domcontentloaded", timeout=90000)
        time.sleep(3)
        if sessao_pede_login(pg):
            raise RuntimeError("Login por e-mail/senha nao funcionou (senha incorreta ou 2FA). Rode --login.")


def visivel(loc):
    try:
        return loc.count() > 0 and loc.first.is_visible()
    except Exception:
        return False


def abrir_painel(pg):
    """Menu 'Paineis' -> 'Painel Atendimentos-Dados Oper...'. Aceita o menu ser link direto ou lista."""
    menu = pg.locator("header a, header button, nav a, nav button, .o_menu_sections a, .o_menu_sections button,"
                      " .o_nav_entry, .dropdown-toggle").filter(has_text=rx("Painéis"))
    fim = time.time() + 30
    while not visivel(menu) and time.time() < fim:
        # a PX abre na tela de aplicativos: o menu "Paineis" fica dentro de "Automacao Operacional"
        app = pg.locator("a.o_app, .o_app, a").filter(has_text=rx("Automação Oper"))
        if visivel(app):
            app.first.click()
            esperar(pg, 2)
        else:
            time.sleep(1)
    menu.first.wait_for(state="visible", timeout=60000)
    menu.first.click()
    time.sleep(1.5)
    item = pg.locator(".dropdown-menu a, .dropdown-item, .o-dropdown--menu a, .o-dropdown--menu .dropdown-item, a")\
             .filter(has_text=RE_ITEM_PAINEL)
    if not visivel(item):                        # menu ainda abrindo
        time.sleep(1.5)
    if visivel(item):
        item.first.click()
    fim = time.time() + 90
    while time.time() < fim:                     # o painel carrega os cards aos poucos
        if any(visivel(pg.get_by_text(r)) for r in CARDS.values()):
            esperar(pg, 2)
            return
        time.sleep(1)
    raise RuntimeError("O painel 'Painel Atendimentos-Dados Oper' nao carregou os cards de Atendimentos Abertos.")


def abrir_card(pg, chave):
    alvo = pg.get_by_text(CARDS[chave]).first
    alvo.wait_for(state="visible", timeout=60000)
    alvo.click()
    pg.locator(".o_list_view, .o_list_renderer, .o_kanban_view").first.wait_for(state="visible", timeout=60000)
    esperar(pg, 1.5)


def voltar_ao_painel(pg):
    trilha = pg.locator(".breadcrumb a, .o_breadcrumb a, ol.breadcrumb li a").filter(has_text=RE_PAINEL)
    if visivel(trilha):
        trilha.first.click()
    else:
        pg.go_back()
    fim = time.time() + 60
    while time.time() < fim:
        if any(visivel(pg.get_by_text(r)) for r in CARDS.values()):
            esperar(pg, 1)
            return
        time.sleep(1)
    raise RuntimeError("Nao consegui voltar para o painel.")


def pesquisar_protocolo(pg, protocolo):
    """Digita o protocolo na pesquisa da lista e devolve a linha cujo Protocolo e exatamente esse numero."""
    busca = pg.locator(".o_searchview_input, input.o_searchview_input").first
    busca.wait_for(state="visible", timeout=30000)
    busca.fill(protocolo)
    time.sleep(1.2)
    # a 1a sugestao da pesquisa e "Pesquisar Protocolo por: ..." (como no video); Enter aplica
    busca.press("Enter")
    esperar(pg, 2)
    linhas = pg.locator(".o_data_row")
    achadas = []
    for i in range(linhas.count()):
        lin = linhas.nth(i)
        celulas = [norm(c) for c in lin.locator("td").all_inner_texts()]
        if protocolo in celulas:
            achadas.append(lin)
    return achadas


def ler_campo_form(pg, rotulo, nome_tecnico=None):
    """Le o valor exibido de um campo do formulario (pelo name tecnico ou pelo rotulo)."""
    if nome_tecnico:
        campo = pg.locator(f".o_form_view .o_field_widget[name={nome_tecnico}]")
        if visivel(campo):
            try:
                inp = campo.first.locator("input")
                if inp.count():
                    return (inp.first.input_value() or "").strip()
            except Exception:
                pass
            return " ".join(campo.first.inner_text().split())
    return pg.evaluate("""(rot) => {
      const labels = [...document.querySelectorAll('.o_form_view label, .o_form_view .o_form_label')];
      const lab = labels.find(l => (l.innerText || '').trim().toLowerCase() === rot.toLowerCase());
      if (!lab) return '';
      const cel = lab.closest('.o_cell, td, .o_wrap_label')?.nextElementSibling
               || (lab.htmlFor && document.getElementById(lab.htmlFor)?.closest('.o_field_widget'));
      if (!cel) return '';
      const inp = cel.querySelector('input');
      return ((inp && inp.value) || cel.innerText || '').trim();
    }""", rotulo)


# ----------------------------------------------------------------- janela "Atribuir para"
def opcoes_autocomplete(pg):
    ops = pg.locator(".o-autocomplete--dropdown-menu .dropdown-item, .o-autocomplete--dropdown-item,"
                     " ul.ui-autocomplete li a, .o-autocomplete--dropdown-menu li a")
    vis = []
    for i in range(ops.count()):
        o = ops.nth(i)
        try:
            if o.is_visible():
                t = " ".join(o.inner_text().split())
                if t and not RE_IGNORAR_OPCAO.search(t):
                    vis.append((t, o))
        except Exception:
            pass
    return vis


def escolher_select(pg, janela, rotulo, sel, valor):
    """Campo de selecao nativo (<select>): escolhe a opcao cujo texto bate exatamente (sem acento/caixa)."""
    opcoes = sel.evaluate("s => [...s.options].map(o => [o.value, (o.textContent || '').trim()])")
    alvo = norm(valor)
    exatas = [(v, t) for v, t in opcoes if norm(t) == alvo]
    if len(exatas) != 1:
        parecidas = [t for v, t in opcoes if alvo and alvo in norm(t)][:15]
        if not exatas:
            raise RuntimeError(f"'{valor}' nao existe em '{rotulo}'."
                               + (f" Parecidas: {parecidas}" if parecidas else " Confira o nome da fila."))
        raise RuntimeError(f"'{valor}' bate com mais de uma opcao de '{rotulo}': {[t for _, t in exatas]}")
    sel.select_option(value=exatas[0][0])
    time.sleep(1.0)
    escolhido = sel.evaluate("s => (s.options[s.selectedIndex] || {}).textContent || ''").strip()
    if norm(escolhido) != alvo:
        raise RuntimeError(f"Tentei escolher '{valor}' em '{rotulo}', mas ficou '{escolhido}'.")
    print(f"  - {rotulo}: {escolhido}")
    return escolhido


def escolher_many2one(pg, janela, rotulo, nome_tecnico, valor):
    # 1o: lista de selecao nativa (e assim que a "Fila de Atendimento" aparece na janela, visto em 11/11/2026)
    sel = janela.locator(f".o_field_widget[name={nome_tecnico}] select")
    if not visivel(sel) and rotulo.startswith("Fila"):
        sel = janela.locator("select")
    if visivel(sel):
        return escolher_select(pg, janela, rotulo, sel.first, valor)
    campo = janela.locator(f".o_field_widget[name={nome_tecnico}] input")
    if not visivel(campo):                       # sem name conhecido: campo de busca da janela
        campo = janela.locator(".o_field_many2one input, .o_field_widget input:not([type=checkbox])")
        campo = campo.first if rotulo.startswith("Fila") else campo.last
    campo = campo.first
    campo.click()
    campo.fill("")
    campo.type(valor[:30], delay=40)
    vis = []
    for _ in range(20):
        time.sleep(0.5)
        vis = opcoes_autocomplete(pg)
        if vis:
            break
    alvo = norm(valor)
    # duas filas que so diferem em acento/caixa (ex.: "geral" e "Geral") contam como duvida: nao escolhe
    exatas = [o for t, o in vis if norm(t) == alvo]
    contem = [(t, o) for t, o in vis if alvo in norm(t)]
    if len(exatas) == 1:
        exatas[0].click()
    elif not exatas and len(contem) == 1 and len(vis) == 1:
        contem[0][1].click()
    else:
        nomes = [t for t, _ in vis][:15]
        pg.keyboard.press("Escape")
        if not vis:
            raise RuntimeError(f"Nenhuma opcao em '{rotulo}' para '{valor}'. Confira o nome da fila/usuario.")
        raise RuntimeError(f"'{valor}' nao bate exatamente com uma unica opcao de '{rotulo}'. Opcoes vistas: {nomes}")
    time.sleep(0.8)
    escolhido = (campo.input_value() or "").strip()
    print(f"  - {rotulo}: {escolhido}")
    return escolhido


def notificacoes_erro(pg):
    textos = []
    avisos = pg.locator(".o_notification, .o_notification_manager .o_notification_content, .alert-danger")
    for i in range(avisos.count()):
        try:
            a = avisos.nth(i)
            if a.is_visible():
                t = " ".join(a.inner_text().split())
                if t and RE_ERRO.search(t):
                    textos.append(t)
        except Exception:
            pass
    janela_erro = pg.locator(".modal .modal-body").filter(has_text=re.compile(r"Erro|Error|Aviso|Warning", re.I))
    if visivel(janela_erro):
        textos.append(" ".join(janela_erro.first.inner_text().split())[:400])
    return textos


def cancelar_tudo(pg):
    """Fecha a janela e descarta alteracoes nao salvas do atendimento (nada fica pela metade)."""
    for _ in range(2):
        bt = pg.locator(".modal-footer button, .modal button").filter(has_text=re.compile(r"^\s*(Cancelar|Descartar)\s*$", re.I))
        if visivel(bt):
            bt.first.click()
            time.sleep(1)
    desc = pg.locator(".o_form_button_cancel, button.o_form_button_cancel")
    if visivel(desc):
        desc.first.click()
        time.sleep(1)
        conf = pg.locator(".modal-footer button").filter(has_text=re.compile(r"^\s*(Ok|Descartar|Discard)\s*$", re.I))
        if visivel(conf):
            conf.first.click()
            time.sleep(1)


# ----------------------------------------------------------------- lote (varios protocolos numa sessao)
def ir_para_lista(pg, ctx, chave):
    """Abre a lista do card. Na 1a vez passa pelo painel e guarda o endereco da lista; nas proximas vai direto
    (o painel e a parte lenta: ~1 min para carregar os graficos)."""
    url = ctx["url_lista"].get(chave)
    if url:
        try:
            pg.goto(url, wait_until="domcontentloaded", timeout=60000)
            pg.locator(".o_list_view, .o_list_renderer").first.wait_for(state="visible", timeout=30000)
            pg.locator(".o_searchview_input").first.wait_for(state="visible", timeout=30000)
            esperar(pg, 1)
            return "atalho"
        except Exception:
            ctx["url_lista"][chave] = None           # endereco nao serviu: volta ao caminho completo
    if not any(visivel(pg.get_by_text(r)) for r in CARDS.values()):
        if ctx.get("url_painel"):
            pg.goto(ctx["url_painel"], wait_until="domcontentloaded", timeout=60000)
            fim = time.time() + 90
            while time.time() < fim and not any(visivel(pg.get_by_text(r)) for r in CARDS.values()):
                time.sleep(1)
        if not any(visivel(pg.get_by_text(r)) for r in CARDS.values()):
            abrir_painel(pg)
        ctx["url_painel"] = pg.url
    abrir_card(pg, chave)
    if pg.url != ctx.get("url_painel"):
        ctx["url_lista"][chave] = pg.url
    return "painel"


def localizar(pg, ctx, protocolo, ordem, dbg):
    for chave in ordem:
        via = ir_para_lista(pg, ctx, chave)
        achadas = pesquisar_protocolo(pg, protocolo)
        if not achadas and via == "atalho":
            # confirma pelo caminho completo antes de dizer que nao esta (o atalho pode ter outro filtro)
            ctx["url_lista"][chave] = None
            ir_para_lista(pg, ctx, chave)
            achadas = pesquisar_protocolo(pg, protocolo)
        print(f"  - card {chave}: {len(achadas)} linha(s) com o protocolo {protocolo}")
        if len(achadas) > 1:
            raise RuntimeError(f"Mais de uma linha com o protocolo {protocolo} em {chave}; nao escolhi no chute.")
        if achadas:
            dbg.passo(pg, f"lista {chave}")
            return achadas[0], chave
    raise RuntimeError(f"Atendimento {protocolo} nao encontrado entre os abertos de "
                       f"{' nem '.join('Dados ' + ('Operacionais' if x == 'operacionais' else 'de Sinistro') for x in ordem)}.")


def processar_um(pg, c, protocolo, a, dbg, ctx):
    resultado = {"protocolo": protocolo, "atribuido": False}
    try:
        ordem = ["operacionais", "sinistro"] if a.painel == "ambos" else [a.painel]
        linha, resultado["painel"] = localizar(pg, ctx, protocolo, ordem, dbg)

        # ---- abre o atendimento e confere que e o certo
        linha.locator("td.o_data_cell").first.click()
        pg.locator(".o_form_view").first.wait_for(state="visible", timeout=60000)
        esperar(pg, 1.5)
        topo = " ".join(pg.locator(".o_control_panel, .o_breadcrumb, .breadcrumb").first.inner_text().split())
        if f"#{protocolo}" not in topo and protocolo not in topo:
            raise RuntimeError(f"O atendimento aberto nao parece ser o {protocolo} (topo: '{topo[:120]}').")
        titulo = ""
        try:
            titulo = " ".join(pg.locator(".o_form_view .oe_title, .o_form_view h1").first.inner_text().split())
        except Exception:
            pass
        if not titulo:
            m = re.search(r"\(#\s*" + re.escape(protocolo) + r"\)\s*(.+?)(?:\s+A[cç][oõ]es)?$", topo)
            titulo = m.group(1).strip() if m else ""
        resultado["titulo"] = re.split(r"\s+A[cç][oõ]es\b", titulo)[0].strip()[:200]
        fila_antes = ler_campo_form(pg, "Fila de Atendimento", "team_id")
        resultado["fila_antes"] = fila_antes
        print(f"  - aberto: {resultado['titulo'][:90]} | fila atual: {fila_antes or '?'}")
        dbg.passo(pg, "atendimento")
        if fila_antes and norm(fila_antes) == norm(a.fila) and not a.usuario:
            resultado["observacao"] = "O atendimento ja esta nessa fila; nada foi alterado."
            return resultado

        # ---- Atribuir para
        botao = pg.locator(".o_form_view button, .o_statusbar_buttons button").filter(
            has_text=re.compile(r"^\s*Atribuir\s+para\s*$", re.I))
        if not visivel(botao):
            raise RuntimeError("Nao achei o botao 'Atribuir para' neste atendimento (pode estar fechado/cancelado).")
        url_form = pg.url
        botao.first.click()
        janela = pg.locator(".modal").filter(has_text=rx("Fila de Atendimento")).last
        janela.wait_for(state="visible", timeout=30000)
        time.sleep(0.8)
        dbg.passo(pg, "janela atribuir")
        resultado["fila_escolhida"] = escolher_many2one(pg, janela, "Fila de Atendimento", "team_id", a.fila)
        if a.usuario:
            resultado["usuario_escolhido"] = escolher_many2one(pg, janela, "Usuário", "user_id", a.usuario)

        if not a.confirmar:
            cancelar_tudo(pg)
            resultado["observacao"] = ("SIMULACAO: atendimento encontrado e fila escolhida na janela 'Atribuir para', "
                                       "mas cliquei em Cancelar. Para transferir de verdade, peca com confirmar=true.")
            return resultado

        ok_bt = janela.locator(".modal-footer button, button").filter(has_text=re.compile(r"^\s*Confirmar\s*$", re.I))
        ja_na_tela = set(notificacoes_erro(pg))      # avisos antigos (de outro atendimento) nao contam
        ok_bt.first.click()
        print("  - Confirmar clicado, conferindo...")
        avisos, fechou = [], False
        fim = time.time() + 30
        while time.time() < fim:
            time.sleep(0.7)
            avisos = [t for t in notificacoes_erro(pg) if t not in ja_na_tela] or avisos
            if not janela.is_visible():
                fechou = True
                break
            if avisos and time.time() > fim - 22:
                break
        dbg.passo(pg, "depois de confirmar")
        if avisos:
            # "Campos invalidos: Assunto, Solicitacao" aparece, mas a PX transfere mesmo assim (Julio, 11/11/2026)
            resultado["aviso_tela"] = "; ".join(avisos)[:400]
            print(f"  - aviso da PX: {resultado['aviso_tela']}")

        # ---- conferencia: a PX tira o atendimento da tela quando ele vai para uma fila fora da visao do usuario
        sumiu = False
        if fechou:
            fim = time.time() + 6
            while time.time() < fim:
                time.sleep(0.5)
                if pg.url != url_form or not visivel(pg.locator(".o_form_view")):
                    sumiu = True
                    break
        fila_depois = ""
        if not sumiu:
            try:
                p2 = c.new_page()
                p2.goto(url_form, wait_until="domcontentloaded", timeout=60000)
                p2.locator(".o_form_view").first.wait_for(state="visible", timeout=15000)
                esperar(p2, 1.5)
                fila_depois = ler_campo_form(p2, "Fila de Atendimento", "team_id")
                p2.close()
            except Exception:
                sumiu = True
        resultado["saiu_da_visao"] = sumiu
        resultado["fila_depois"] = fila_depois or None
        if fila_depois:
            if norm(fila_depois) != norm(resultado["fila_escolhida"]):
                raise RuntimeError(f"O atendimento NAO mudou de fila: continua em '{fila_depois}'."
                                   + (f" Aviso da PX: {resultado.get('aviso_tela')}" if avisos else ""))
        elif not fechou and not sumiu:
            raise RuntimeError("Cliquei em Confirmar, mas nao consegui confirmar a nova fila. Conferir o protocolo "
                               f"{protocolo}." + (f" Aviso da PX: {resultado.get('aviso_tela')}" if avisos else ""))
        resultado["atribuido"] = True
        if not fila_depois:
            resultado["observacao"] = ("Confirmado" + (" sem aviso" if not avisos else "") + "; o atendimento saiu da visao "
                                       "do seu usuario logo depois (fila de destino fora da visao dele), sinal de que foi "
                                       "transferido.")
        elif avisos:
            resultado["observacao"] = "Transferido, mas a PX mostrou um aviso (campos do atendimento sem preencher)."
        print(f"  - transferido: {fila_antes or '?'} -> {fila_depois or resultado['fila_escolhida']}")
        return resultado
    except Exception as e:
        dbg.passo(pg, f"erro {protocolo}")
        resultado["erro"] = str(e).splitlines()[0][:400]
        print(f"  ! {protocolo}: {resultado['erro']}")
        try:
            pg.keyboard.press("Escape")
        except Exception:
            pass
        return resultado


# ----------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Transfere atendimentos da PX para outra fila (Atribuir para)")
    ap.add_argument("--protocolo", default="", help="um numero de atendimento (coluna Protocolo), ex.: 609487")
    ap.add_argument("--protocolos", default="", help="varios, separados por virgula/espaco/linha: 609486,609484")
    ap.add_argument("--fila", required=True, help='Fila de Atendimento de destino, como aparece na lista (ex.: "Faturamento")')
    ap.add_argument("--usuario", default="", help="opcional: usuario da fila de destino")
    ap.add_argument("--painel", choices=["operacionais", "sinistro", "ambos"], default="ambos")
    ap.add_argument("--confirmar", action="store_true", help="sem isto o script so simula (clica em Cancelar)")
    ap.add_argument("--cred", default=str(AQUI / "credenciais.env"))
    ap.add_argument("--visivel", action="store_true")
    ap.add_argument("--discover", action="store_true")
    a = ap.parse_args()

    brutos = re.split(r"[\s,;]+", f"{a.protocolo} {a.protocolos}".strip())
    protocolos = []
    for x in brutos:
        x = x.strip().lstrip("#")
        if not x:
            continue
        if not re.fullmatch(r"\d{3,9}(-\d+)?", x):
            print(f"\nERRO: protocolo invalido '{x}'")
            sys.exit(1)
        if x not in protocolos:
            protocolos.append(x)
    if not protocolos:
        print("\nERRO: informe --protocolo ou --protocolos")
        sys.exit(1)
    if not a.fila.strip():
        print("\nERRO: informe a fila de destino")
        sys.exit(1)

    env = ler_env(a.cred)
    px_url = env.get("ODOO_URL", PX_URL_PADRAO).rstrip("/")
    dbg = Debug(a.discover)
    modo = "confirmar" if a.confirmar else "simulacao"
    print(f"Atribuir {len(protocolos)} atendimento(s) para a fila '{a.fila}'"
          f"{' / usuario ' + a.usuario if a.usuario else ''} | "
          f"{'CONFIRMAR' if a.confirmar else 'SIMULACAO (clica em Cancelar)'}")
    itens, inicio = [], time.time()

    with sync_playwright() as p:
        b = p.chromium.launch(headless=not a.visivel)
        kw = {"viewport": {"width": 1600, "height": 1000}, "locale": "pt-BR"}
        if STATE.exists():
            kw["storage_state"] = str(STATE)
        c = b.new_context(**kw)
        c.on("request", dbg.rede)
        pg = c.new_page()
        try:
            abrir_px(pg, px_url, env)
            abrir_painel(pg)
            dbg.passo(pg, "painel")
            ctx = {"url_painel": pg.url, "url_lista": {}}
            for n, prot in enumerate(protocolos, 1):
                t0 = time.time()
                print(f"\n[{n}/{len(protocolos)}] {prot}")
                r = processar_um(pg, c, prot, a, dbg, ctx)
                r["segundos"] = round(time.time() - t0)
                itens.append(r)
            try:
                SESSAO_DIR.mkdir(exist_ok=True)
                c.storage_state(path=str(STATE))
            except Exception as e:
                print(f"    (nao consegui salvar a sessao: {e})")
        except Exception as e:
            dbg.passo(pg, "erro")
            print("\nERRO:", e)
            print("RESULTADO_JSON: " + json.dumps({"modo": modo, "fila_pedida": a.fila.strip(), "itens": itens},
                                                  ensure_ascii=True))
            sys.exit(1)
        finally:
            dbg.salvar()
            b.close()

    for r in itens:
        r.update({"modo": modo, "fila_pedida": a.fila.strip(), "usuario_pedido": a.usuario.strip() or None})
    falhas = [r for r in itens if r.get("erro")]
    if len(itens) == 1:
        resultado = itens[0]
    else:
        resultado = {"modo": modo, "fila_pedida": a.fila.strip(), "total": len(itens),
                     "atribuidos": sum(1 for r in itens if r.get("atribuido")),
                     "ja_estavam": sum(1 for r in itens if not r.get("erro") and not r.get("atribuido")
                                       and "ja esta" in (r.get("observacao") or "")),
                     "falhas": len(falhas), "segundos_total": round(time.time() - inicio), "itens": itens}
    if falhas and len(falhas) == len(itens):
        print("\nERRO: " + ("; ".join(f"{r['protocolo']}: {r['erro']}" for r in falhas))[:900])
        print("RESULTADO_JSON: " + json.dumps(resultado, ensure_ascii=True))
        sys.exit(1)
    print("RESULTADO_JSON: " + json.dumps(resultado, ensure_ascii=True))


if __name__ == "__main__":
    main()
