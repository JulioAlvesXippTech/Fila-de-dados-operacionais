"""Regras por padrão para atendimentos do Xipp Bot na Pré-análise — validadas pelo Julio em 11/11/2026:
boletos/faturas/NF e pagamento não identificado -> Reatribuir fila (Faturamento); códigos e divulgações -> Encerrar;
relatórios da operadora -> sem sugestão fixa (Julio decide). O resto (respostas, pedidos) o Claude analisa um a um."""
import re
REGRAS = [
 ("codigo", r"c[óo]digo de (verifica|autentica|acesso|login|seguran)|codigo de autentica|seu c[óo]digo|segundo fator|token|senha|password|acesso ao sa[úu]de online",
  "Encerrar", "Baixa", "E-mail automático com código de acesso/verificação de portal.", "Encerrar — só notificação de código, sem ação para a fila."),
 ("marketing", r"boas[- ]vindas|inscri[çc][õo]es abertas|desafie|desafio |totalpass|nova op[çc][ãa]o de pagamento|conhe[çc]a os check|status mensal|atualize seus dados fiscais|queima di[áa]ria|o que facilitaria|ajude sua equipe|seu sorriso merece|black november|at[ée] \\d+% de desconto",
  "Encerrar", "Baixa", "Comunicado/divulgação da operadora ou parceiro, sem pedido.", "Encerrar — informativo, sem ação."),
 ("pagamento", r"falta de registro de pagamento|lembrete de pagamento|comunicado importante|aus[êe]ncia de identifica[çc][ãa]o de pagamento",
  "Reatribuir fila", "Alta", "Operadora avisa pagamento não identificado.", "Reatribuir para a fila de Faturamento (risco de inadimplência/cancelamento)."),
 ("cobranca", r"boleto|fatura|cobran[çc]a|nota fiscal|nota eletr[ôo]nica|informa[çc][õo]es de faturamento|faturamento vg|faturamento check|mensalidade|emiss[ãa]o nfs-e|taxa adm",
  "Reatribuir fila", "Média", "Boleto/fatura/NF enviada pela operadora.", "Reatribuir para a fila de Faturamento — não é carga de dados."),
 ("relatorio", r"relat[óo]rio|sinistralidade|maiores utilizadores|coparticipa|adicionou um novo arquivo|compartilhamento de arquivos|acompanhamento mensal",
  "Outro", "Baixa", "Relatório da operadora (sinistralidade/utilização/coparticipação) recebido automaticamente.", "Sem sugestão fixa — decidir: reatribuir para a área de Sinistro, arquivar ou encerrar."),
]
RX = [(n, re.compile(p, re.I), a, pr, pe, su) for n, p, a, pr, pe, su in REGRAS]

PEDIDO = re.compile(r"solicita[çc][ãa]o|pend[êe]ncia|urgente", re.I)   # é um pedido, não um envio automático -> Claude analisa
RESPOSTA = re.compile(r"^\s*(re|res|enc|fw|fwd)\s*:", re.I)   # conversa encaminhada/respondida -> Claude analisa


AUTOMATICO = re.compile(r"^\s*relat[óo]rio\s*:", re.I)   # "Relatório: Solicitação de Autorização ..." é envio automático


def regra(titulo, bot=True):
    """bot=False (aberto por pessoa): só a regra de código de acesso vale (ex.: "ENC: Seu código de acesso")."""
    t = titulo or ""
    if not bot:
        r = RX[0]
        return (r[0],) + r[2:] if r[1].search(t) else None
    if RX[0][1].search(t):
        r = RX[0]
        return (r[0],) + r[2:]
    if (RESPOSTA.search(t) or PEDIDO.search(t)) and not AUTOMATICO.search(t):
        return None
    for n, rx, a, pr, pe, su in RX:
        if rx.search(t):
            return n, a, pr, pe, su
    return None
