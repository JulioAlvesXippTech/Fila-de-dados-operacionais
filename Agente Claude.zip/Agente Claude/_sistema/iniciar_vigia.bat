@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=C:\Users\JulioCesardaSilvaAlv\AppData\Local\Programs\Python\Python311\python.exe"
if not exist "%PY%" set "PY=py -3"
%PY% sdi_vigia.py
echo.
echo Vigia encerrado.
pause
