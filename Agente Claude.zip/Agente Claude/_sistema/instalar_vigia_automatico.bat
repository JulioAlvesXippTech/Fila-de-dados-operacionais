@echo off
cd /d "%~dp0"
echo Instalando o vigia para iniciar junto com o Windows (sem janela)...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:APPDATA+'\Microsoft\Windows\Start Menu\Programs\Startup\SDI Vigia.lnk'); $s.TargetPath='%~dp0vigia_oculto.vbs'; $s.WorkingDirectory='%~dp0'; $s.Save()"
if errorlevel 1 (
  echo Nao consegui criar o atalho de inicializacao.
) else (
  echo Pronto. O vigia vai iniciar sozinho sempre que voce ligar o computador.
)
echo Iniciando o vigia agora...
wscript "%~dp0vigia_oculto.vbs"
echo.
echo Concluido. Pode fechar esta janela.
pause
