# -*- coding: utf-8 -*-
"""
Automação - Solicitação de Posição Cadastral (PC) no portal Bradesco Seguros
============================================================================

Reproduz o fluxo do vídeo "Solicitação de PC Bradesco":

    Login Tele Web  ->  CAPTCHA (digitado pelo usuário)  ->  terminal 3270 web
    -> 1 (SAUDE) -> usuário/senha -> SSBE -> pasta 510 (Faturamento)
    -> assunto 31 (Posição Cadastral) -> preenche Contrato / Gerar pedido=S /
       Todas Subfaturas=S / Incluir Cancelados=N -> ENTER -> "Operacao Realizada Com Sucesso"

O site é um EMULADOR 3270 WEB (TELE-WEB3270): cada "tela verde" do mainframe é
renderizada como um formulário HTML com campos de input e botões ENTER / LIMPAR /
ATTN / PA1. Por isso a automação é feita com Selenium, esperando cada tela pelo
TEXTO que aparece nela e then digitando nos campos e clicando em ENTER.

--------------------------------------------------------------------------------
IMPORTANTE - LEIA ANTES DE RODAR
--------------------------------------------------------------------------------
1. O CAPTCHA é resolvido POR VOCÊ: o script abre o navegador, para na tela do
   captcha, e pede no terminal (input) que você digite o código que está na
   imagem. Nada de IA/OCR - é manual, como você pediu.

2. Os SELETORES dos campos do terminal 3270 variam conforme a tela. Este script
   usa uma estratégia robusta: localiza "o input visível/habilitado da vez" e
   também oferece funções para você ajustar por name/id caso necessário. Onde
   for preciso calibrar, está marcado com  # >>> AJUSTE.

3. NUNCA coloque usuário/senha fixos no código. Preencha o arquivo .env ou as
   variáveis de ambiente (veja abaixo).

Instalação:
    pip install selenium python-dotenv openpyxl
    # e tenha o Chrome + chromedriver compatível no PATH
    # (Selenium 4.6+ baixa o driver sozinho via Selenium Manager)

Dois modos de uso:
    1) UM contrato:
         python solicita_pc_bradesco.py --contrato 75321
    2) LISTA (planilha Excel):
         python solicita_pc_bradesco.py --planilha contratos_exemplo.xlsx
       A planilha deve ter uma coluna 'Contrato'. O script grava, para cada
       contrato, as colunas 'Status' (Solicitado / Não autorizado / Verificar /
       Erro), 'Mensagem' e 'Data/Hora'. Salva a cada contrato (não perde
       progresso) - mantenha o arquivo FECHADO no Excel enquanto roda.

Variáveis de ambiente (ou arquivo .env na mesma pasta):
    BRADESCO_USUARIO=M527853
    BRADESCO_SENHA=sua_senha
    BRADESCO_CONTRATO=75321          # contrato padrão (pode passar por --contrato)
    BRADESCO_URL=https://wwws.bradescoseguros.com.br/TELE-WEB3270/entry

Uso:
    python solicita_pc_bradesco.py --contrato 75321
    python solicita_pc_bradesco.py --contrato 75321 --headless  (NÃO recomendado por causa do captcha)
"""

import os
import sys
import time
import argparse
import unicodedata

try:
    from dotenv import load_dotenv
    # Lê o arquivo de credenciais único da pasta _sistema (mesmo usado pelos
    # outros scripts). Se não existir, cai para o .env padrão.
    _aqui = os.path.dirname(os.path.abspath(__file__))
    _cred = os.path.join(_aqui, "credenciais.env")
    if os.path.exists(_cred):
        load_dotenv(_cred)
    else:
        load_dotenv()
except Exception:
    pass  # python-dotenv é opcional

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException


# ----------------------------------------------------------------------------
# Configuração
# ----------------------------------------------------------------------------
URL_PADRAO = os.getenv(
    "BRADESCO_URL",
    "https://wwws.bradescoseguros.com.br/TELE-WEB3270/entry",
)
USUARIO = os.getenv("BRADESCO_USUARIO", "")
SENHA = os.getenv("BRADESCO_SENHA", "")
CONTRATO_PADRAO = os.getenv("BRADESCO_CONTRATO", "")

TIMEOUT = 40  # segundos de espera máxima por cada tela


# ----------------------------------------------------------------------------
# Funções auxiliares para lidar com o terminal 3270 web
# ----------------------------------------------------------------------------
def criar_driver(headless: bool = False) -> webdriver.Chrome:
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1400,900")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    # evita o popup de "salvar senha" / tradução atrapalharem a automação
    opts.add_experimental_option("prefs", {
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False,
        "translate": {"enabled": False},
    })
    opts.add_argument("--disable-features=Translate")
    return webdriver.Chrome(options=opts)


def _texto_total(driver) -> str:
    """
    Junta o texto do documento principal E de todos os frames/iframes.
    O terminal 3270 web costuma renderizar a 'tela verde' dentro de um frame,
    por isso não basta olhar só o body principal. Ao final volta ao conteúdo
    principal para não bagunçar o contexto.
    """
    partes = []

    def coletar():
        # texto normal da página
        try:
            partes.append(driver.find_element(By.TAG_NAME, "body").text)
        except Exception:
            pass
        # IMPORTANTE: muitas telas do HATS renderizam o conteúdo DENTRO dos
        # campos de input (uma linha da tela 3270 por campo). O body.text não
        # vê isso, então coletamos também o 'value' dos campos (ignorando os
        # que só têm underlines/espaços).
        try:
            for e in driver.find_elements(By.XPATH, "//input | //textarea"):
                try:
                    v = e.get_attribute("value")
                    if v and v.strip("_ \t"):
                        partes.append(v)
                except Exception:
                    pass
        except Exception:
            pass

    try:
        driver.switch_to.default_content()
        coletar()
    except Exception:
        pass
    try:
        n = len(driver.find_elements(By.XPATH, "//iframe | //frame"))
    except Exception:
        n = 0
    for i in range(n):
        try:
            driver.switch_to.default_content()
            fr = driver.find_elements(By.XPATH, "//iframe | //frame")[i]
            driver.switch_to.frame(fr)
            coletar()
        except Exception:
            pass
    driver.switch_to.default_content()
    return "\n".join(partes)


def esperar_texto(driver, texto: str, timeout: int = TIMEOUT):
    """Espera até que `texto` apareça na página (incluindo frames), case-insensitive."""
    alvo = texto.lower()
    WebDriverWait(driver, timeout).until(
        lambda d: alvo in _texto_total(d).lower()
    )


def esperar_tela_pronta(driver, timeout: int = TIMEOUT):
    """
    Espera a tela do HATS ficar PRONTA e ESTÁVEL antes de decidir a ação.
    Como cada ENTER recarrega a página inteira, o body fica em branco por um
    instante; sem isto o navegador lê um 'branco' e acha que é tela desconhecida.
    Retorna o texto quando ele estiver não-vazio e igual em duas leituras
    seguidas (estável).
    """
    fim = time.time() + timeout
    anterior = None
    txt = ""
    while time.time() < fim:
        txt = _texto_total(driver).strip()
        if txt and txt == anterior:
            return txt
        anterior = txt
        time.sleep(0.6)
    return txt


def pagina_contem(driver, texto: str) -> bool:
    try:
        return texto.lower() in _texto_total(driver).lower()
    except Exception:
        return False


def focar_terminal(driver):
    """
    Coloca o foco no documento/frame que realmente tem os campos de entrada do
    terminal, para que digitar e clicar em ENTER funcionem mesmo quando a tela
    está dentro de um frame.
    """
    driver.switch_to.default_content()
    if inputs_editaveis(driver):
        return
    try:
        n = len(driver.find_elements(By.XPATH, "//iframe | //frame"))
    except Exception:
        n = 0
    for i in range(n):
        try:
            driver.switch_to.default_content()
            fr = driver.find_elements(By.XPATH, "//iframe | //frame")[i]
            driver.switch_to.frame(fr)
            if inputs_editaveis(driver):
                return
        except Exception:
            pass
    driver.switch_to.default_content()


def diagnostico(driver, etapa: str):
    """Mostra o que realmente carregou na tela, para depurar quando algo falha."""
    print("\n" + "!" * 60)
    print(f" DIAGNÓSTICO - falhou em: {etapa}")
    print("!" * 60)
    try:
        print(" URL atual :", driver.current_url)
    except Exception:
        pass
    try:
        print(" Título    :", driver.title)
    except Exception:
        pass
    try:
        nframes = len(driver.find_elements(By.XPATH, "//iframe | //frame"))
        print(" Frames    :", nframes)
    except Exception:
        pass
    try:
        txt = _texto_total(driver).strip()
        print(" Texto visível (primeiros 400 caracteres):")
        print("   " + (txt[:400].replace("\n", "\n   ") if txt else "(PÁGINA EM BRANCO)"))
    except Exception:
        pass
    try:
        shot = os.path.abspath("erro_tela.png")
        driver.save_screenshot(shot)
        print(" Print salvo em:", shot)
    except Exception:
        pass
    despejar_html(driver, "tela_html.txt")
    print("!" * 60 + "\n")


def inputs_editaveis(driver):
    """
    Retorna os campos editáveis visíveis da tela atual: inputs de texto, senha
    (password), tel/number e também <textarea>. Botões, hidden, checkbox/radio
    são ignorados. Mantém a ordem do DOM (usuário, senha, nova senha...).
    """
    els = driver.find_elements(By.XPATH, "//input | //textarea")
    ok = []
    for e in els:
        try:
            if not (e.is_displayed() and e.is_enabled()):
                continue
            if e.tag_name.lower() == "textarea":
                ok.append(e)
                continue
            tp = (e.get_attribute("type") or "text").lower()
            if tp in ("text", "password", "tel", "number", ""):
                ok.append(e)
        except Exception:
            continue
    return ok


def despejar_html(driver, nome="tela_html.txt"):
    """Salva o HTML do documento e de cada frame num arquivo, para depuração."""
    try:
        caminho = os.path.abspath(nome)
        partes = []
        driver.switch_to.default_content()
        partes.append("===== DOCUMENTO PRINCIPAL =====\n" +
                      driver.find_element(By.TAG_NAME, "html").get_attribute("outerHTML"))
        frames = driver.find_elements(By.XPATH, "//iframe | //frame")
        for i in range(len(frames)):
            try:
                driver.switch_to.default_content()
                fr = driver.find_elements(By.XPATH, "//iframe | //frame")[i]
                driver.switch_to.frame(fr)
                partes.append(f"\n\n===== FRAME {i} =====\n" +
                              driver.find_element(By.TAG_NAME, "html").get_attribute("outerHTML"))
            except Exception:
                pass
        driver.switch_to.default_content()
        with open(caminho, "w", encoding="utf-8") as f:
            f.write("\n".join(partes))
        print(" HTML da tela salvo em:", caminho)
    except Exception as ex:
        print(" (não consegui salvar o HTML:", ex, ")")


def primeiro_campo(driver):
    """O primeiro input editável da tela (geralmente o cursor do 3270)."""
    campos = inputs_editaveis(driver)
    if not campos:
        raise NoSuchElementException("Nenhum campo de entrada visível na tela atual.")
    return campos[0]


def campo_do_cursor(driver):
    """
    Retorna o campo onde o host (mainframe) posicionou o cursor.

    Este portal é um IBM HATS: cada campo da tela vira um <input> com
    id="in_<posicao>_<tamanho>", e há um campo oculto CURSORPOSITION com a
    posição do cursor. O campo de digitação correto (ex.: COMANDO) é aquele
    cujo id começa com "in_<CURSORPOSITION>_". Isso evita digitar no campo
    errado (como o seletor verde de 1 caractere).
    """
    # 1) tenta pela posição do cursor do host
    pos = None
    for nome in ("CURSORPOSITION", "CARETPOS"):
        try:
            el = driver.find_element(By.NAME, nome)
            pos = (el.get_attribute("value") or "").strip()
            if pos:
                break
        except Exception:
            pass
    if pos:
        els = driver.find_elements(By.CSS_SELECTOR, f"input[id^='in_{pos}_']")
        els = [e for e in els if e.is_displayed() and e.is_enabled()]
        if els:
            return els[0]
    # 2) fallback: maior campo de texto da tela (normalmente o de comando)
    campos = [e for e in inputs_editaveis(driver)
              if (e.get_attribute("type") or "text").lower() == "text"]
    if campos:
        return max(campos, key=lambda e: int(e.get_attribute("maxlength") or 1))
    # 3) último recurso: primeiro editável
    return primeiro_campo(driver)


def escrever_campo_terminal(campo, valor, driver=None, limpar_tudo=False):
    """
    Escreve num campo do terminal (HATS) que vem preenchido com underlines ('_')
    e tem maxlength = tamanho do campo. Como o campo já está "cheio" de '_',
    é preciso posicionar no início, apagar os primeiros '_' e sobrescrever,
    preservando o tamanho (igual ao que se faz manualmente). Se os keystrokes
    não surtirem efeito, força o valor via JavaScript mantendo o tamanho.

    limpar_tudo=True: apaga o conteúdo inteiro do campo antes de escrever (usado
    quando a linha tem uma mensagem e queremos só o comando, ex.: SSBE).
    """
    valor = str(valor)
    try:
        campo.click()
    except Exception:
        pass

    if limpar_tudo:
        try:
            campo.send_keys(Keys.CONTROL, "a")
            campo.send_keys(Keys.DELETE)
        except Exception:
            pass
        try:
            campo.clear()
        except Exception:
            pass
        try:
            campo.send_keys(valor)
        except Exception:
            pass
        try:
            if valor not in (campo.get_attribute("value") or "") and driver is not None:
                driver.execute_script(
                    "arguments[0].value = arguments[1];"
                    "if (typeof arguments[0].onchange === 'function') { arguments[0].onchange(); }",
                    campo, valor,
                )
        except Exception:
            pass
        return campo

    try:
        campo.send_keys(Keys.HOME)          # início do campo
    except Exception:
        pass
    for _ in range(len(valor)):             # apaga N underlines à frente
        try:
            campo.send_keys(Keys.DELETE)
        except Exception:
            break
    try:
        campo.send_keys(valor)              # digita o valor no início
    except Exception:
        pass

    # Verifica o resultado; se não entrou, força via JS preservando o tamanho.
    try:
        atual = campo.get_attribute("value") or ""
        if valor not in atual and driver is not None:
            ml = int(campo.get_attribute("maxlength") or len(valor))
            novo = (valor + "_" * ml)[:ml] if ml >= len(valor) else valor
            driver.execute_script(
                "arguments[0].value = arguments[1];"
                "if (typeof arguments[0].onchange === 'function') { arguments[0].onchange(); }",
                campo, novo,
            )
    except Exception:
        pass
    return campo


def digitar_no_primeiro(driver, valor: str, limpar: bool = True):
    """Digita no campo do cursor do host (o campo de comando/código da tela)."""
    focar_terminal(driver)
    campo = campo_do_cursor(driver)
    return escrever_campo_terminal(campo, valor, driver=driver)


def clicar_enter(driver):
    """
    Clica no botão ENTER do terminal. No 3270 web ele costuma ser um
    <input type=button value=ENTER> ou <button>ENTER</button>. Se não achar,
    envia a tecla ENTER no campo ativo como fallback.
    """
    # No HATS o botão ENTER tem name="[enter]" e value="ENTER " (com espaço).
    seletores = [
        "//input[@name='[enter]']",
        "//input[(@type='button' or @type='submit') and normalize-space(@value)='ENTER']",
        "//button[normalize-space()='ENTER']",
        "//a[normalize-space()='ENTER']",
    ]
    for xp in seletores:
        els = driver.find_elements(By.XPATH, xp)
        els = [e for e in els if e.is_displayed() and e.is_enabled()]
        if els:
            els[0].click()
            return True
    # fallback HATS: chama a função de submit do próprio portal
    try:
        driver.execute_script("if (typeof ms === 'function') { ms('[enter]','HATSForm'); }")
        return True
    except Exception:
        pass
    # último recurso: tecla ENTER no elemento ativo
    try:
        driver.switch_to.active_element.send_keys(Keys.ENTER)
        return True
    except Exception:
        return False


def clicar_botao_por_valor(driver, valor: str) -> bool:
    """Clica em qualquer botão do terminal pelo texto/value (OK, submit, LIMPAR...)."""
    xp = (f"//input[(@type='button' or @type='submit') and normalize-space(@value)='{valor}'] | "
          f"//button[normalize-space()='{valor}']")
    els = [e for e in driver.find_elements(By.XPATH, xp) if e.is_displayed()]
    if els:
        els[0].click()
        return True
    return False


def enviar_pf(driver, numero: int):
    """
    Envia uma tecla de função PFn (ex.: PF3=Fim). No HATS existe o botão/ْcomando
    [pfN]; tentamos chamar a função ms('[pfN]') e, se não der, a tecla FN.
    """
    try:
        driver.execute_script(
            f"if (typeof ms === 'function') {{ ms('[pf{numero}]','HATSForm'); }}"
        )
        return
    except Exception:
        pass
    try:
        driver.switch_to.active_element.send_keys(getattr(Keys, f"F{numero}"))
    except Exception:
        pass


def preencher_campo_por_label(driver, label: str, valor: str, limpar_tudo: bool = False):
    """
    Em telas onde há vários campos (ex.: 'Contrato', 'Gerar pedido', etc.) tenta
    achar o input logo após o rótulo. Estratégia genérica para tabelas/linhas de
    terminal. Se não encontrar, levanta erro para você calibrar.   # >>> AJUSTE
    """
    # tenta: input cujo elemento-rótulo precedente contém o texto
    xp = (f"//*[contains(normalize-space(.), '{label}')]"
          f"/following::input[@type='text' or @type='password' or not(@type)][1]")
    els = [e for e in driver.find_elements(By.XPATH, xp) if e.is_displayed() and e.is_enabled()]
    if not els:
        raise NoSuchElementException(f"Não encontrei o campo do rótulo '{label}'.")
    return escrever_campo_terminal(els[0], valor, driver=driver, limpar_tudo=limpar_tudo)


def pausa(seg: float = 1.2):
    time.sleep(seg)


# ----------------------------------------------------------------------------
# Passo do CAPTCHA (resolvido pelo usuário)
# ----------------------------------------------------------------------------
def resolver_captcha_manual(driver):
    """
    Detecta a tela de captcha ('What code is in the image?' / 'código'), mostra
    a imagem para o usuário (salva um print) e pede o código no terminal.
    """
    if not (pagina_contem(driver, "code is in the image")
            or pagina_contem(driver, "codigo")
            or pagina_contem(driver, "captcha")):
        return  # não há captcha nesta tela

    print("\n" + "=" * 60)
    print(" CAPTCHA detectado - intervenção manual necessária")
    print("=" * 60)

    # salva um screenshot para facilitar (caso a janela esteja atrás)
    try:
        shot = os.path.abspath("captcha_bradesco.png")
        driver.save_screenshot(shot)
        print(f" Um print da tela foi salvo em: {shot}")
    except Exception:
        pass

    print(" Olhe a imagem do captcha no navegador que abriu")
    print(" e digite abaixo exatamente o código mostrado (respeite maiúsc./minúsc.).")
    codigo = input(" >> Código do captcha: ").strip()

    # digita no campo do captcha e envia (botão 'submit')
    digitar_no_primeiro(driver, codigo)
    if not clicar_botao_por_valor(driver, "submit"):
        clicar_enter(driver)
    pausa(2)


def _norm(s: str) -> str:
    """Normaliza texto: remove acentos e deixa minúsculo, para casar telas."""
    s = unicodedata.normalize("NFKD", s or "")
    return "".join(c for c in s if not unicodedata.combining(c)).lower()


class TelaDesconhecida(Exception):
    pass


def navegar_ate_pedido(driver, usuario, senha, max_telas=30):
    """
    Navegador ADAPTATIVO do terminal 3270. Em vez de assumir uma ordem fixa de
    telas, lê o texto da tela atual a cada passo e decide a ação, até chegar na
    tela 'Pedido de Posicao Cadastral'. Assim lida com as variações do portal
    (com/sem tela de seleção, 'usuário já logado', menu de rotinas, etc.).
    """
    login_feito = False
    ultima_assinatura = None
    repetidas = 0

    for passo in range(max_telas):
        bruto = esperar_tela_pronta(driver)   # espera a tela ficar pronta/estável
        focar_terminal(driver)                # foca no doc/frame com os campos
        t = _norm(bruto)

        # chegamos ao destino?
        if "pedido de posicao cadastral" in t:
            print("     -> Tela de Pedido de Posição Cadastral encontrada.")
            return

        # detecta telas sem progresso (evita loop infinito)
        assinatura = t[:200]
        if assinatura == ultima_assinatura:
            repetidas += 1
        else:
            repetidas = 0
            ultima_assinatura = assinatura
        if repetidas >= 2:
            raise TelaDesconhecida("A tela não mudou após a ação (possível campo/botão diferente).")

        # erro de transação do mainframe
        if "not recognized" in t or "nao reconhec" in t or "não reconhec" in _norm(bruto):
            raise TelaDesconhecida("O mainframe respondeu 'transação não reconhecida'.")

        # ---- decisão por conteúdo da tela ----
        if "selecao de aplicacoes" in t:
            print("     tela: Seleção de Aplicações -> 1 (SAUDE)")
            digitar_no_primeiro(driver, "1"); clicar_enter(driver)

        elif "nova senha" in t or ("digite" in t and "usuario" in t and "senha" in t):
            # Tela de login. Aparece 2x: no mainframe (USUARIO/SENHA/NOVA SENHA)
            # e depois no sistema SISA ("DIGITE O USUARIO E SENHA"), com o mesmo
            # usuário e senha. O detector de 'tela não mudou' evita loop.
            print("     tela: Login -> usuário e senha")
            focar_terminal(driver)
            campos = inputs_editaveis(driver)
            if len(campos) >= 2:
                escrever_campo_terminal(campos[0], usuario, driver=driver)
                escrever_campo_terminal(campos[1], senha, driver=driver)
                # NOVA SENHA (campos[2]) fica em branco de propósito
            else:
                raise TelaDesconhecida("Tela de login não tem os 2 campos esperados.")
            clicar_enter(driver)
            login_feito = True

        elif "ja esta logado" in t or "tecle" in t and "enter" in t and "menu de rotinas" not in t:
            print("     tela: aviso 'usuário já logado' -> ENTER")
            clicar_enter(driver)

        elif ("application data not available" in t or "cms1334" in t
              or "refresh the screen" in t):
            # Tela quase em branco com a mensagem 'Application data not available':
            # a linha do topo contém a mensagem; limpamos e escrevemos SSBE.
            print("     tela: Aplicação (Application data) -> SSBE")
            focar_terminal(driver)
            campo = campo_do_cursor(driver)
            escrever_campo_terminal(campo, "SSBE", driver=driver, limpar_tudo=True)
            clicar_enter(driver)

        elif "menu de rotinas" in t:
            print("     tela: Menu de Rotinas -> SSBE")
            digitar_no_primeiro(driver, "SSBE"); clicar_enter(driver)

        elif "sign-on is complete" in t:
            print("     tela: Sign-on completo -> SSBE")
            digitar_no_primeiro(driver, "SSBE"); clicar_enter(driver)

        elif ("menu de pastas" in t or "codigo da pasta" in t
              or ("pasta" in t and "faturamento" in t)):
            # Tela da pasta (título pode ser 'Menu de Pastas' ou
            # 'Favor informar o codigo da pasta') -> 510 (Faturamento)
            print("     tela: Pasta -> 510 (Faturamento)")
            digitar_no_primeiro(driver, "510"); clicar_enter(driver)

        elif ("menu assuntos" in t or "codigo do assunto" in t
              or ("assunto" in t and "posicao cadastral" in t)):
            # Tela do assunto (título pode ser 'Menu Assuntos' ou
            # 'informar o codigo do assunto') -> 31 (Posição Cadastral)
            print("     tela: Assunto -> 31 (Posição Cadastral)")
            digitar_no_primeiro(driver, "31"); clicar_enter(driver)

        else:
            raise TelaDesconhecida("Tela não reconhecida pelo navegador.")

        pausa(1.6)

    raise TelaDesconhecida(f"Não cheguei ao pedido após {max_telas} telas.")


# ----------------------------------------------------------------------------
# Preenchimento do Pedido (SIS58M1) e leitura do resultado
# ----------------------------------------------------------------------------
def ler_mensagem_resultado(driver):
    """
    Lê a mensagem no topo da tela de Pedido após o ENTER e classifica o status:
      - 'Solicitado'      -> 'Operacao Realizada Com Sucesso'
      - 'Não autorizado'  -> 'Usuario Nao Autorizado'
      - 'Verificar'       -> qualquer outra mensagem (devolve o texto)
    Retorna (status, mensagem).
    """
    txt = esperar_tela_pronta(driver)
    tn = _norm(txt)
    if "nao autorizado" in tn:
        return "Não autorizado", "Usuario Nao Autorizado"
    if "operacao realizada com sucesso" in tn or "realizada com sucesso" in tn:
        return "Solicitado", "Operação Realizada Com Sucesso"
    # outra mensagem: devolve a primeira linha significativa da tela
    linha = ""
    for ln in txt.splitlines():
        s = ln.strip()
        if s and "bradesco" not in s.lower() and "sistema" not in s.lower():
            linha = s
            break
    return "Verificar", (linha[:150] or "Mensagem não identificada")


def reabrir_pedido_via_menu(driver):
    """
    Volta do Pedido para o Menu de Assuntos usando F2 (PF2 'Menu') e reabre o
    Pedido de Posição Cadastral (assunto 31). Isso dá um formulário LIMPO e
    é o jeito correto de 'resetar' a tela entre um contrato e outro
    (equivale ao F2 que se faz manualmente).
    """
    enviar_pf(driver, 2)                 # F2 = PF2 (Menu)
    pausa(1.2)
    esperar_texto(driver, "assunto", timeout=20)   # 'Menu Assuntos' ou 'codigo do assunto'
    digitar_no_primeiro(driver, "31")    # reabre Posição Cadastral
    clicar_enter(driver)
    esperar_texto(driver, "Pedido de Posicao Cadastral", timeout=20)


def processar_pedido_form(driver, contrato, gerar="S", todas_subfaturas="S",
                          incluir_cancelados="N"):
    """
    Preenche o formulário 'Pedido de Posicao Cadastral' (SIS58M1) para UM
    contrato e submete, retornando (status, mensagem). Assume que a tela do
    pedido já está aberta; ao final a tela permanece no formulário, pronta
    para o próximo contrato.
    """
    # garante que estamos na tela do pedido
    esperar_texto(driver, "Pedido de Posicao Cadastral", timeout=20)
    focar_terminal(driver)

    # Campos na ordem da tela (HATS ordena os inputs pela posição no 3270):
    #   [0]=Contrato  [1]=Gerar pedido  [2]=Excluir pedido
    #   [3]=Todas Subfaturas  [4]=Incluir Cancelados
    campos = inputs_editaveis(driver)
    if len(campos) < 5:
        # fallback: tenta pelos rótulos
        try:
            preencher_campo_por_label(driver, "Contrato", contrato, limpar_tudo=True)
            preencher_campo_por_label(driver, "Gerar pedido", gerar, limpar_tudo=True)
            preencher_campo_por_label(driver, "Todas Subfaturas", todas_subfaturas, limpar_tudo=True)
            preencher_campo_por_label(driver, "Incluir Cancelados", incluir_cancelados, limpar_tudo=True)
        except NoSuchElementException:
            raise TelaDesconhecida(
                f"Formulário do pedido com {len(campos)} campos (esperava 5).")
    else:
        escrever_campo_terminal(campos[0], contrato, driver=driver, limpar_tudo=True)
        escrever_campo_terminal(campos[1], gerar, driver=driver, limpar_tudo=True)
        # campos[2] = Excluir pedido -> deixa em branco
        escrever_campo_terminal(campos[3], todas_subfaturas, driver=driver, limpar_tudo=True)
        escrever_campo_terminal(campos[4], incluir_cancelados, driver=driver, limpar_tudo=True)

    # Submete (ENTER). Pode haver uma confirmação: "Tecle <ENTER> Para Confirmar".
    clicar_enter(driver)
    pausa(1.3)
    txt = esperar_tela_pronta(driver)
    if "confirmar" in _norm(txt):
        clicar_enter(driver)
        pausa(1.3)

    return ler_mensagem_resultado(driver)


# ----------------------------------------------------------------------------
# Planilha Excel (lista de contratos + status)
# ----------------------------------------------------------------------------
def _mapear_colunas(ws):
    """Descobre as colunas pelo cabeçalho (linha 1). Default: A/B/C/D."""
    cabec = {}
    for c in range(1, (ws.max_column or 1) + 1):
        v = ws.cell(1, c).value
        if v:
            cabec[_norm(str(v))] = c

    def achar(chave, padrao):
        for k, idx in cabec.items():
            if chave in k:
                return idx
        return padrao

    return {
        "contrato": achar("contrato", 1),
        "status":   achar("status", 2),
        "mensagem": achar("mensagem", 3),
        "data":     achar("data", 4),
    }


def _contrato_texto(valor):
    """Converte o valor da célula em texto de contrato (remove .0 de números)."""
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def processar_planilha(driver, caminho):
    """
    Lê a planilha de contratos, processa cada um e grava o status/mensagem/data
    ao lado. Salva a cada contrato para não perder o progresso.
    """
    import openpyxl
    from datetime import datetime

    if not os.path.exists(caminho):
        print("ERRO: planilha não encontrada:", caminho)
        return

    wb = openpyxl.load_workbook(caminho)
    ws = wb.active
    col = _mapear_colunas(ws)

    # coleta os contratos (a partir da linha 2)
    linhas = []
    for r in range(2, (ws.max_row or 1) + 1):
        contrato = _contrato_texto(ws.cell(r, col["contrato"]).value)
        if contrato:
            linhas.append((r, contrato))

    if not linhas:
        print("A planilha não tem contratos na coluna 'Contrato'.")
        return

    print(f"\n>>> {len(linhas)} contrato(s) para processar.\n")
    resumo = {"Solicitado": 0, "Não autorizado": 0, "Verificar": 0, "Erro": 0}

    for n, (r, contrato) in enumerate(linhas, 1):
        print(f"[{n}/{len(linhas)}] Contrato {contrato}...", end=" ")
        try:
            # A partir do 2º contrato, volta ao menu (F2) e reabre o Pedido,
            # garantindo um formulário limpo para cada contrato.
            if n > 1:
                reabrir_pedido_via_menu(driver)
            status, msg = processar_pedido_form(driver, contrato)
        except (TimeoutException, TelaDesconhecida) as e:
            status, msg = "Erro", f"Falha ao processar: {e}"
            # tenta recuperar voltando ao menu para não travar os próximos
            try:
                reabrir_pedido_via_menu(driver)
            except Exception:
                pass
        except Exception as e:  # noqa
            status, msg = "Erro", f"Erro inesperado: {e}"

        ws.cell(r, col["status"]).value = status
        ws.cell(r, col["mensagem"]).value = msg
        ws.cell(r, col["data"]).value = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        try:
            wb.save(caminho)   # salva progresso a cada contrato
        except PermissionError:
            print("\n  ⚠️  Não consegui salvar a planilha (feche o Excel e ela será salva no próximo).")
        resumo[status] = resumo.get(status, 0) + 1
        print("->", status)

    print("\n================ RESUMO ================")
    for k, v in resumo.items():
        if v:
            print(f"  {k}: {v}")
    print("  Planilha atualizada:", os.path.abspath(caminho))
    print("=======================================")


# ----------------------------------------------------------------------------
# Fluxo principal
# ----------------------------------------------------------------------------
def executar(contrato=None, planilha=None, headless=False):
    if not USUARIO or not SENHA:
        print("ERRO: defina BRADESCO_USUARIO e BRADESCO_SENHA (variáveis de ambiente ou credenciais.env).")
        sys.exit(1)
    if not planilha and not contrato:
        print("ERRO: informe --contrato NUM  ou  --planilha arquivo.xlsx")
        sys.exit(1)

    driver = criar_driver(headless=headless)
    try:
        # ---- 1) Abrir Login Tele Web ----
        print("[1] Abrindo Login Tele Web...")
        driver.get(URL_PADRAO)
        esperar_texto(driver, "Usu")                       # rótulo "Usuário :"
        digitar_no_primeiro(driver, USUARIO)
        if not clicar_botao_por_valor(driver, "OK"):
            clicar_enter(driver)
        pausa(2)

        # ---- 2) CAPTCHA (manual) ----
        print("[2] Verificando CAPTCHA...")
        try:
            esperar_texto(driver, "code is in the image", timeout=15)
        except TimeoutException:
            pass
        resolver_captcha_manual(driver)

        # ---- 3) Navegação adaptativa até o Pedido ----
        print("[3] Navegando pelo terminal até o Pedido de Posição Cadastral...")
        navegar_ate_pedido(driver, USUARIO, SENHA)

        # ---- 4) Processa um contrato OU a planilha ----
        if planilha:
            print("[4] Processando a planilha de contratos...")
            processar_planilha(driver, planilha)
        else:
            print("[4] Processando o contrato", contrato, "...")
            status, msg = processar_pedido_form(driver, contrato)
            print(f"\n>>> Contrato {contrato}: {status} ({msg})")
            try:
                driver.save_screenshot(os.path.abspath(f"resultado_pc_{contrato}.png"))
            except Exception:
                pass

        input("\nConcluído. Pressione ENTER para fechar o navegador...")

    except (TimeoutException, TelaDesconhecida) as e:
        if isinstance(e, TelaDesconhecida):
            print("\n>> Navegador parou:", e)
        diagnostico(driver, "esperando/entendendo uma tela do portal")
        print("Dicas comuns:")
        print(" - Página EM BRANCO/erro de conexão: pode exigir a VPN corporativa.")
        print(" - Carregou outra tela: me diga o texto acima que eu ajusto o passo.")
        input("\nNavegador deixado aberto para você conferir. Pressione ENTER para fechar...")
    finally:
        try:
            driver.quit()
        except Exception:
            pass


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Solicitação de Posição Cadastral - Bradesco Seguros")
    p.add_argument("--contrato", default=CONTRATO_PADRAO,
                   help="Número de UM contrato (padrão: BRADESCO_CONTRATO do ambiente)")
    p.add_argument("--planilha", default=None,
                   help="Caminho de um .xlsx com a lista de contratos (coluna 'Contrato'). "
                        "Quando informado, ignora --contrato e processa a lista inteira.")
    p.add_argument("--headless", action="store_true",
                   help="Roda sem janela (NÃO recomendado: o captcha é manual)")
    args = p.parse_args()

    # Decide a planilha automaticamente quando não vier por --planilha:
    #   1) variável BRADESCO_PLANILHA  2) arquivo 'contratos.xlsx' na pasta do script
    planilha = args.planilha or os.getenv("BRADESCO_PLANILHA")
    if not planilha:
        padrao = os.path.join(os.path.dirname(os.path.abspath(__file__)), "contratos.xlsx")
        if os.path.exists(padrao):
            planilha = padrao

    if planilha:
        print("Modo LISTA -> planilha:", planilha)
    else:
        print("Modo CONTRATO ÚNICO ->", args.contrato or "(nenhum contrato informado)")
        print("  (para rodar uma lista, crie um 'contratos.xlsx' na pasta "
              "ou use --planilha arquivo.xlsx)")

    executar(contrato=args.contrato, planilha=planilha, headless=args.headless)


if __name__ == "__main__":
    main()
